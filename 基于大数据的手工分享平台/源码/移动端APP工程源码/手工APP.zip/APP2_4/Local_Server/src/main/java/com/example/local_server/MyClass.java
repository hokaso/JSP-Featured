package com.example.local_server;

public class MyClass {
}
