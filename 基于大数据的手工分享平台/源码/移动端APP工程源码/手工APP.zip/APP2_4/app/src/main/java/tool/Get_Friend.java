package tool;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.manual.Chat.Chat;
import com.example.manual.R;

import java.sql.Connection;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Get_Friend extends Thread{

    private Handler handler;
    private String u_id;
    private String t_id;

    //h负责传输数据
    //在数据库中搜索涉及u（u_id)的聊天记录
    public Get_Friend(Handler h, String u) {
        this.handler = h;
        this.u_id = u;
    }

    @Override
    public void run() {
        System.out.println("******************Here is Get_Friend *************************");
        Statement stmt=null;
        Connection conn=null;
        try {
            //1.注册驱动程序，2.获取连接对象
            conn = JDBCutils.getConnection();
            //3.创建Statement
            stmt = conn.createStatement();
            //4.准备sql
            String sql = "select * from message where u_id = '"+u_id+"' or t_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            ResultSet rs = stmt.executeQuery(sql);


            ArrayList<ConcurrentHashMap<String, Object>> listitem = new ArrayList<>();

            Set hashSet = new HashSet<HashMap<String,String>>();
            //获取各种动态类型的数据
            while(rs.next()) {
                hashSet.add(rs.getString("u_id"));
                hashSet.add(rs.getString("t_id"));
            }
            hashSet.remove(u_id); //消除搜索到的自己的ID
            Iterator it001 = hashSet.iterator();
            while(it001.hasNext()) {
                ConcurrentHashMap<String, Object> CHmap = new ConcurrentHashMap<>();
                CHmap.put("icon", R.mipmap.image01);
                CHmap.put("t_id", it001.next());
                listitem.add(CHmap);
            }
            Bundle bundle = new Bundle();
            Message message = new Message();
            bundle.putSerializable("listitem", listitem);
            message.what=0x002;
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
