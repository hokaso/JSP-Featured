package com.example.manual.Community.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.Mine.activity.UserHomePage;
import com.example.manual.R;

import java.util.ArrayList;
import java.util.List;

import entity.CustomerComment;

public class CommentAdapter extends BaseAdapter {

    List<CustomerComment> data = new ArrayList<CustomerComment>();
    CustomerComment customerComment;
    private Context context;
    private ImageLoad imageLoad;

    public CommentAdapter() {
    }

    public CommentAdapter(Context context) {
        this.context = context;
        imageLoad = new ImageLoad(context);
    }


    public CommentAdapter(List<CustomerComment> data, Context context) {
        this.data = data;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = View.inflate(context, R.layout.community_comment_item, null);
        }
        customerComment = data.get(position);
        final String u_id = customerComment.getU_id();
        ImageView headpic = convertView.findViewById(R.id.headpic);
        TextView name = convertView.findViewById(R.id.name);
        TextView publishtime = convertView.findViewById(R.id.publishtime);
        TextView comment = convertView.findViewById(R.id.comment);
        name.setText(customerComment.getName());
        publishtime.setText(customerComment.getTime());
        comment.setText(customerComment.getContent());

        //头像点击事件，跳到用户的首页
        headpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(context, UserHomePage.class);
                String t_id = customerComment.getU_id();
                System.out.println(t_id+","+u_id);
                intent.putExtra("u_id",u_id);
                context.startActivity(intent);
            }
        });
        imageLoad.loadImage(headpic,context.getString(R.string.server_projectpath)+customerComment.getHeadPicPath());
        return convertView;
    }
}
