package com.example.manual.Mall.adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.GoodsCommentEntity;
import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.Bean.OrderItemEntity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.R;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import entity.Customer;
import tool.FormatUtil;

public class CommentForGoodsAdapter extends BaseAdapter {

    private List<OrderItemEntity> items;
    private Context context;
    private ImageLoad imageLoad;
    private String order_id;
    private static List<GoodsCommentEntity> comments;
    private int count = 0;

    public CommentForGoodsAdapter(String order_id, List<OrderItemEntity> items, Context context) {
        this.items = items;
        this.context = context;
        this.order_id = order_id;
        imageLoad = new ImageLoad(context);
        comments = new ArrayList<GoodsCommentEntity>();
        initComments(items);
    }

    private void initComments(List<OrderItemEntity> items) {
        for (OrderItemEntity item : items) {
            GoodsCommentEntity comment = new GoodsCommentEntity();
            comment.setGoods(item.getGoods());
            comment.setSpecs(item.getSpecs());
            comment.setCustomer(getCustomer());
            comment.setGoods_comment_id(FormatUtil.createUUID());
            comment.setOrder_id(order_id);
            comments.add(comment);
        }
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_comment2order, null);
            convertView.setTag(position + "");
            convertView = setView(position, convertView);
        } else {
            String pos = (String) convertView.getTag();
            position = Integer.parseInt(pos);
            // convertView = setView(position, convertView);
        }

        return convertView;
    }

    private View setView(int position, View convertView) {
        //convertView = View.inflate(context, R.layout.mall_item_comment2order, null);
        ImageView iv_specs_img = convertView.findViewById(R.id.iv_specs_img);
        TextView tv_specs = convertView.findViewById(R.id.tv_specs);
        TextView tv_goods_describe = convertView.findViewById(R.id.tv_goods_describe);
        EditText et_comment2goods = convertView.findViewById(R.id.et_comment2goods);

        OrderItemEntity orderItem = items.get(position);
        GoodsEntity goods = orderItem.getGoods();

        String imgPath = context.getResources().getString(R.string.server_projectpath)
                + items.get(position).getSpecs().getSpecs_img();
        imageLoad.loadImage(iv_specs_img, imgPath);
        //tv_goods_name.setText(goods.getGoods_name());
        tv_goods_describe.setText(goods.getGoods_describe());
        tv_specs.setText(orderItem.getSpecs().getSpecs_attrs());
        // 设置et_comment2goods事件
        setEt_comment2goods(et_comment2goods, position);
        return convertView;
    }

    private void setEt_comment2goods(final EditText et_comment2goods, final int position) {
        et_comment2goods.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus == false) {
                    String content = et_comment2goods.getText().toString();
                    Toast.makeText(context, content, Toast.LENGTH_SHORT).show();
                    if (content != null) {
                        if (!content.trim().equals("")) {
                            (comments.get(position)).setGoods_comment_content(content);
                        }
                    }
                }
            }
        });
    }


    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = context.getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);
        //Log.e("customerJson----", customerJson);
        Customer customer = new Gson().fromJson(customerJson, Customer.class);
        return customer;
    }

    public static List<GoodsCommentEntity> getComments() {
        return comments;
    }

    public static void setComments(List<GoodsCommentEntity> comments) {
        CommentForGoodsAdapter.comments = comments;
    }
}
