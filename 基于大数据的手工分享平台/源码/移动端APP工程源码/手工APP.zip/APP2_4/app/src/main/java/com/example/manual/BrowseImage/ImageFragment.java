package com.example.manual.BrowseImage;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.manual.R;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

/**
 * 单张显示图片
 */
public class ImageFragment extends Fragment {
	private String mImageUrl;

	public PhotoView getmImageView() {
		return mImageView;
	}

	private PhotoView mImageView;
	private ProgressBar progressBar;
	public static Fragment newInstance(String url) {
		ImageFragment fragment = new ImageFragment();
		Bundle args = new Bundle();
		args.putString("url",url);
		fragment.setArguments(args);
		return fragment;
	}

	@Override
	public void onCreate(@Nullable Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		mImageUrl = getArguments() != null ? getArguments().getString("url"):null;

		DisplayImageOptions defaultOptions = new DisplayImageOptions.Builder() //
				.showImageForEmptyUri(R.drawable.ic_launcher) //
				.showImageOnFail(R.drawable.ic_launcher) //
				.cacheInMemory(true) //
				.cacheOnDisk(true) //
				.build();//

		ImageLoaderConfiguration config = new ImageLoaderConfiguration//
				.Builder(getContext())//
				.defaultDisplayImageOptions(defaultOptions)//
				.discCacheSize(50 * 1024 * 1024)//
				.discCacheFileCount(100)// 缓存一百张图片
				.writeDebugLogs()//
				.build();//
		ImageLoader.getInstance().init(config);

	}

	@Nullable
	@Override
	public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.image_detail_fragment,container,false);
		mImageView = (PhotoView) view.findViewById(R.id.image);
		mImageView.enable();
		progressBar = (ProgressBar) view.findViewById(R.id.loading);
		return view;
	}


	@Override
	public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);
	}

	@Override
	public void onActivityCreated(@Nullable Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		DisplayImageOptions options = new DisplayImageOptions.Builder()//
				.cacheInMemory(true) // 内存缓存
				.cacheOnDisk(true) // sdcard缓存
				.bitmapConfig(Bitmap.Config.RGB_565)// 设置最低配置
				.build();//

		ImageLoader.getInstance()
				.displayImage(mImageUrl,mImageView,options,new SimpleImageLoadingListener(){
			public void onLoadingStarted(String imageUri, View view) {
				progressBar.setVisibility(View.VISIBLE);
			}

			public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
				String message = null;
				switch (failReason.getType()){
					case IO_ERROR:
						message = "下载错误";
						break;
					case DECODING_ERROR:
						message = "图片无法显示";
						break;
					case NETWORK_DENIED:
						message = "网络有问题，无法下载";
						break;
					case OUT_OF_MEMORY:
						message = "图片太大无法显示";
						break;
					case UNKNOWN:
						message = "未知的错误";
						break;
				}
				Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
				progressBar.setVisibility(View.GONE);

			}

			public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
				DisplayMetrics dm = new DisplayMetrics();
				getActivity().getWindowManager().getDefaultDisplay().getMetrics(dm);
				int screenWidth = dm.widthPixels;
				int newHeight =screenWidth*loadedImage.getHeight()/loadedImage.getWidth();
				Bitmap bitmap = ImageUtils.zoomImg(loadedImage,screenWidth,newHeight);
				mImageView.setImageBitmap(bitmap);
				progressBar.setVisibility(View.GONE);
				mImageView.setVisibility(View.VISIBLE);
			}

		});
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
	}


}
