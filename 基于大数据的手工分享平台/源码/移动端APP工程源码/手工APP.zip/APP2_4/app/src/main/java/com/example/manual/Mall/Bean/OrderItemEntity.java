package com.example.manual.Mall.Bean;

import java.io.Serializable;

public class OrderItemEntity implements Serializable {

	private String order_item_id;
	private double item_price;
	private int order_item_count;
	private GoodsSpecs specs;
	private GoodsEntity goods;
	private OrderEntity order;

	public String getOrder_item_id() {
		return order_item_id;
	}

	public void setOrder_item_id(String order_item_id) {
		this.order_item_id = order_item_id;
	}

	public double getItem_price() {
		return item_price;
	}

	public void setItem_price(double item_price) {
		this.item_price = item_price;
	}

	public int getOrder_item_count() {
		return order_item_count;
	}

	public void setOrder_item_count(int order_item_count) {
		this.order_item_count = order_item_count;
	}

	public GoodsSpecs getSpecs() {
		return specs;
	}

	public void setSpecs(GoodsSpecs specs) {
		this.specs = specs;
	}

	public GoodsEntity getGoods() {
		return goods;
	}

	public void setGoods(GoodsEntity goods) {
		this.goods = goods;
	}

	public OrderEntity getOrder() {
		return order;
	}

	public void setOrder(OrderEntity order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "OrderItemEntity [order_item_id=" + order_item_id + ", item_price=" + item_price + ", order_item_count="
				+ order_item_count + ", specs=" + specs + ", goods=" + goods + "]";
	}

}
