package com.example.manual.Mall.Bean;

import entity.Customer;

public class MallCollection {

	private String mall_collection_id;
	private GoodsEntity goods;
	private Customer customer;
	private String u_id;

	public String getMall_collection_id() {
		return mall_collection_id;
	}

	public void setMall_collection_id(String mall_collection_id) {
		this.mall_collection_id = mall_collection_id;
	}

	public GoodsEntity getGoods() {
		return goods;
	}

	public void setGoods(GoodsEntity goods) {
		this.goods = goods;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	@Override
	public String toString() {
		return "MallCollection [mall_collection_id=" + mall_collection_id + ", goods=" + goods + ", customer="
				+ customer + ", u_id=" + u_id + "]";
	}

}
