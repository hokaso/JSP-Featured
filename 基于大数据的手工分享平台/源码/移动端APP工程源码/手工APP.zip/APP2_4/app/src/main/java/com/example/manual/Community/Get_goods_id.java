package com.example.manual.Community;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import tool.JDBCutils;

public class Get_goods_id extends Thread{

    private Handler handler;
    private String d_id;

    public Get_goods_id(Handler h, String d_id) {
        this.handler = h;
        this.d_id = d_id;
    }

    @Override
    public void run() {
        Statement stmt=null;
        Connection conn=null;
        try {
            //1.注册驱动程序，2.获取连接对象
            conn = JDBCutils.getConnection();
            //3.创建Statement
            stmt = conn.createStatement();
            //4.准备sql
            String sql = "SELECT goods_id FROM DYNAMIC WHERE d_id = "+d_id;
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            ResultSet rs = stmt.executeQuery(sql);

            String goods_id = null;
            Bundle bundle = new Bundle();
            while(rs.next()) {
                if(rs.getString("goods_id").length() > 0) {
                    Log.i("Length", String.valueOf(rs.getString("goods_id").length()));
                    goods_id = rs.getString("goods_id");
                }
                bundle.putString("goods_id", goods_id);
            }
            Message message = new Message();
            message.what=444;
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
