package com.example.manual.Community;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TabHost;

import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import entity.Dynamic;
import entity.Customer;
import tool.GetDataThread;


public class Community_all extends AppCompatActivity implements TabHost.OnTabChangeListener, AdapterView.OnItemClickListener {
    String introduction = null;
    String type = null;//存储当前的选项卡的类型
    String category = null;//记录当前所在的社区
    private List<Map<String, Object>> listitem=new ArrayList<Map<String, Object>>();


    //接收子线程返回回来的数据
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            //0最新回复，1最新发布，2热门
            ListView listView = null;
            switch (msg.what){
                case 0:
                    type = "latestresp";
                    listView = findViewById(R.id.lastestresponse);
                    break;
                case 1:
                    type = "latestpub";
                    listView = findViewById(R.id.lastestpublish);
                    break;
                case 2:
                    type = "host";
                    listView = findViewById(R.id.host);
                    break;
                    default:
                        break;
            }
            Bundle bundle = msg.getData();
            List<Map<String,Object>> listitem = (List<Map<String, Object>>) bundle.getSerializable("listitem");
            SimpleAdapter adapter=new SimpleAdapter(getApplicationContext(), listitem, R.layout.community_all_main,
                    new String[]{"name", "title","total_comment","total_like","release_date"}, new int[]{R.id.username, R.id.title,R.id.comment,R.id.like,R.id.time});
            listView.setAdapter(adapter);

        }
    };
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.community_all);
        //点击发布文章监听事件
        ImageView imageView = findViewById(R.id.headpic);
        imageView.bringToFront();
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("customer",MODE_PRIVATE);
                String customerJson = sharedPreferences.getString("customerJson","");
                Log.i("js",customerJson);
                Gson gson = new Gson();
                Customer customer = gson.fromJson(customerJson, Customer.class);
                if(customer !=null){
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("customer", (Serializable) customer);
                    bundle.putString("category",category);
                    bundle.putString("type",type);
                    intent.putExtra("b",bundle);
                    intent.setClass(Community_all.this,Community_publish.class);
                    startActivity(intent);
                }else{

                }


            }
        });
        ActionBar actionBar = getSupportActionBar();
        Intent intent = getIntent();
        //从intent取出bundle
        Bundle bundle = intent.getBundleExtra("title");
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        category = bundle.getString("egtitle");
        actionBar.setTitle(bundle.getString("name")+"社区");
        //设置选项卡导航栏
        TabHost tabhost = findViewById(R.id.tabhost);
        tabhost.setup();
        //添加选项
        tabhost.addTab(tabhost.newTabSpec("latestresp")
                .setIndicator("最新回复")
        .setContent(R.id.lastestresponse)
        );
        //添加选项
        tabhost.addTab(tabhost.newTabSpec("latestpublish")
                .setIndicator("最新发布")
                .setContent(R.id.lastestpublish)
        );
        //添加选项
        tabhost.addTab(tabhost.newTabSpec("host")
                .setIndicator("热门")
                .setContent(R.id.host)
        );
        //为三个listview设置监听器
        ListView listView1 = findViewById(R.id.lastestresponse);
        listView1.setOnItemClickListener(this);
        ListView listView2 = findViewById(R.id.lastestpublish);
        listView2.setOnItemClickListener(this);
        ListView listView3 = findViewById(R.id.host);
        listView3.setOnItemClickListener(this);
        tabhost.setOnTabChangedListener(this);
        //第一次显示最新回复的页面数据
        GetDataThread getDataThread = new GetDataThread(handler,"latestresp",category);
        getDataThread.start();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.community_topmenu,menu);
        final MenuItem item = menu.findItem(R.id.search);
        SearchView mSearchView = (SearchView) MenuItemCompat.getActionView(item);
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {  @Override
        public boolean onQueryTextSubmit(String query) {
            /* doSearch();*/
            GetDataThread getDataThread = new GetDataThread(handler, type,category);
            getDataThread.setTitle(query);
            getDataThread.start();
            return false;
        }
            @Override
            public boolean onQueryTextChange(String newText) {

               /* doSearch();*/
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            case R.id.search:

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    //切换选项卡时，更新数据
    public void onTabChanged(String tabId){
        GetDataThread getDataThread = null;
        if(tabId.equals("latestresp")){
            Log.i("sss","1111");
            getDataThread = new GetDataThread(handler,"latestresp",category);

        }
        if(tabId.equals("latestpublish")){
            Log.i("112","嘎嘎嘎");
            getDataThread = new GetDataThread(handler,"latestpub",category);

        }
        if(tabId.equals("host")){
            Log.i("44","aa");
            getDataThread = new GetDataThread(handler,"host",category);
        }
        getDataThread.start();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Map<String, Object> map= (Map<String, Object>) parent.getItemAtPosition(position);
        String name=map.get("name").toString();
        String title=map.get("title").toString();
        String time = map.get("release_date").toString();
        String content = map.get("content").toString();
        String u_id = map.get("u_id").toString();
        String d_id = map.get("d_id").toString();
        String headpic = map.get("headPicPath").toString();
        /*Double d1 = new Double((Double)map.get("total_like"));*/
        int total_like = Integer.parseInt(map.get("total_like").toString());
      /*  Double d2 = new Double((Double)map.get("total_comment"));*/
        int total_comment = Integer.parseInt(map.get("total_comment").toString());
        Log.i("sssssss",total_like+","+total_comment);
       /* Customer customer = new Customer();
        customer.setName(name);
        customer.setU_id(u_id);*/
        Dynamic cd = new Dynamic();
        cd.setTitle(title);
        cd.setD_id(d_id);
        cd.setContent(content);
        cd.setRelease_date(time);
       /* cd.setType(type);*/
        cd.setCategory(category);
        cd.setTotal_like(total_like);
        cd.setTotal_comment(total_comment);
        Bundle bundle =new Bundle();
        bundle.putString("u_id",u_id);
        bundle.putString("hostName",name);
        bundle.putString("hostHeadPic",headpic);
        bundle.putSerializable("dynamic",cd);
        //存放到历史记录
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String str = sharedPreferences.getString("customerJson","");
        Gson gson = new Gson();
        Customer customer = gson.fromJson(str,Customer.class);
        SharedPreferences history = getSharedPreferences(customer.getU_id(), Context.MODE_PRIVATE);
        String his = history.getString("historyList","");
        List<String> historyList = gson.fromJson(his,new TypeToken<List<String>>() {
        }.getType());
        if(historyList==null){
            historyList = new ArrayList<>();
        }
        //不存在，才加进去
        if(!historyList.contains(cd.getD_id())){
            historyList.add(cd.getD_id());
        }
        his = gson.toJson(historyList);
        SharedPreferences.Editor edit = history.edit();
        edit.putString("historyList",his);
        edit.commit();
        System.out.println(his);

        Intent intent = new Intent();
        intent.setClass(this,Community_fullActivity.class);
        intent.putExtra("data",bundle);
        startActivity(intent);

    }
}
