package com.example.manual.Mall.avtivity;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.OrderEntity;
import com.example.manual.Mall.Bean.OrderItemEntity;
import com.example.manual.Mall.adapter.OrderItemAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.R;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.List;

public class MallOrderDetailActivity extends AppCompatActivity {

    private TextView tv_name;
    private TextView tv_phone;
    private TextView tv_address;
    private TextView tv_createtime;
    private TextView tv_paytime;
    private TextView tv_total;
    private ListView lv_order_item;
    private Button btn_goods_comment;

    private OrderItemAdapter adapter;
    private OrderEntity order;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 100:
                    Bundle bundle = msg.getData();
                    order = (OrderEntity) bundle.getSerializable("order");
                    List<OrderItemEntity> itemList = order.getItemList();
                    if (order != null) {
                        setView();
                    }
                    adapter = new OrderItemAdapter(itemList, MallOrderDetailActivity.this);
                    lv_order_item.setAdapter(adapter);

                    if (order != null) {
                        String state = order.getOrder_state();
                        if (order.getOrder_state().equals(OrderEntity.STATE_SIGNED)) {
                            if (order.getOrder_is_commented() == 0) {
                                btn_goods_comment.setVisibility(View.VISIBLE);
                                turnToComment();
                            }
                        } else {
                            btn_goods_comment.setVisibility(View.GONE);
                        }
                    }
                    break;
                case 59:
                    Toast.makeText(MallOrderDetailActivity.this, "加载失败", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_order_detail);

        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("订单详细");

        Bundle bundle = getIntent().getExtras();
        String order_id = bundle.getString("order_id");
        initView();
        getOrderFromServer(order_id);
    }

    /**
     * 前往评价页面
     */
    private void turnToComment() {
        btn_goods_comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bu = new Bundle();
                if (order != null) {
                    bu.putSerializable("order", order);
                    Intent intent = new Intent(MallOrderDetailActivity.this, MallCommentForOrderActivity.class);
                    intent.putExtras(bu);
                    startActivity(intent);
                }
            }
        });
    }

    /**
     * 给视图设置值
     */
    private void setView() {
        tv_name.setText(order.getOrder_consigneeName());
        tv_address.setText(order.getOrder_consigneeAddress());
        tv_phone.setText(order.getOrder_consigneePhone());
        tv_total.setText("￥" + order.getOrder_totalPrice());
        tv_createtime.setText(order.getOrder_create_time());
        // String payTime = order.getOrder_paytime();
        if (order.getOrder_state().equals(OrderEntity.STATE_UNPAID)) {
            tv_paytime.setText("尚未付款");
        } else {
            tv_paytime.setText(order.getOrder_paytime());
        }
    }

    /**
     * 加载数据
     * @param order_id
     */
    private void getOrderFromServer(final String order_id) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath) +
                        "findOrderDetail.action?order_id=" + order_id;
                /*String path = "http://10.86.2.15:8080/ssm01/" +
                        "findOrderDetail.action?order_id=" + order_id;*/
                try {
                    String json = GetDataFromService.resquestJson(path);
                    if (json == null) {
                        handler.sendEmptyMessage(59);
                        return;
                    } else {
                        Bundle b = new Bundle();
                        OrderEntity orderEntity = new Gson().fromJson(json, OrderEntity.class);
                        b.putSerializable("order", orderEntity);
                        Message message = new Message();
                        message.setData(b);
                        message.what = 100;
                        handler.sendMessage(message);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * 初始化视图
     */
    private void initView() {
        tv_name = findViewById(R.id.tv_name);
        tv_phone = findViewById(R.id.tv_phone);
        tv_address = findViewById(R.id.tv_address);
        tv_createtime = findViewById(R.id.tv_createtime);
        tv_paytime = findViewById(R.id.tv_paytime);
        tv_total = findViewById(R.id.tv_total);
        lv_order_item = findViewById(R.id.lv_order_item);
        btn_goods_comment = findViewById(R.id.btn_goods_comment);
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
