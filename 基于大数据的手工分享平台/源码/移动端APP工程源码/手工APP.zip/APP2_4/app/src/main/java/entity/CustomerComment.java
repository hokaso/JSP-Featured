package entity;

import java.util.List;

import entity.Customer;
import entity.Dynamic;

public class CustomerComment {

    private String u_id;
    private String name;
    private String headPicPath;
    private String phonenumber;
    private String password;
    private String address;
    private String gender;
    private String location;
    private String signature;
    private List<Dynamic> dynamicList;//登陆时存放一部分
    private List<Customer> followList;//登陆时存放一部分
    private List<Customer> fanList;//登陆时存放一部分

    //comment
    private String c_id;
    private String d_id;
    private String content;
    private String time;

    public String getC_id() {
        return c_id;
    }

    public void setC_id(String c_id) {
        this.c_id = c_id;
    }

    public String getD_id() {
        return d_id;
    }

    public void setD_id(String d_id) {
        this.d_id = d_id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    public String getU_id() {
        return u_id;
    }

    public void setU_id(String u_id) {
        this.u_id = u_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHeadPicPath() {
        return headPicPath;
    }

    public void setHeadPicPath(String headPicPath) {
        this.headPicPath = headPicPath;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public List<Dynamic> getDynamicList() {
        return dynamicList;
    }

    public void setDynamicList(List<Dynamic> dynamicList) {
        this.dynamicList = dynamicList;
    }

    public List<Customer> getFollowList() {
        return followList;
    }

    public void setFollowList(List<Customer> followList) {
        this.followList = followList;
    }

    public List<Customer> getFanList() {
        return fanList;
    }

    public void setFanList(List<Customer> fanList) {
        this.fanList = fanList;
    }

}
