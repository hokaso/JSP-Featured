package com.example.manual.Mine.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.R;
import com.google.gson.Gson;

import entity.Customer;

public class MyModifyPwdActivity extends AppCompatActivity {

    private EditText et_oldpwd;
    private EditText et_newpwd;
    private EditText et_repwd;
    private Button btn_modify;

    private final int UPLOAD_SUCCESS = 200;
    private final int UPLOAD_ERROR = 500;

    private Customer customer;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case UPLOAD_SUCCESS:
                    Toast.makeText(MyModifyPwdActivity.this, "修改成功", Toast.LENGTH_SHORT).show();
                    saveSharedPreferences();
                    finish();
                    break;
                case UPLOAD_ERROR:
                    Toast.makeText(MyModifyPwdActivity.this, "修改失败，请重试", Toast.LENGTH_SHORT).show();
                    break;
            }
        }

        /**
         * 保存到本地
         */
        private void saveSharedPreferences() {
            SharedPreferences sp = getSharedPreferences("customer", MODE_PRIVATE);
            String customerJson = new Gson().toJson(customer);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("customerJson", customerJson);
            editor.commit();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_modify_pwd);

        ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setTitle("修改密码");
        supportActionBar.setDisplayHomeAsUpEnabled(true);

        customer = getCustomer();
        initView();
        if (customer == null) {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return;
        }

        btn_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getNewInfo(customer);
            }
        });

    }

    private void getNewInfo(Customer customer) {
        String oldpwd = et_oldpwd.getText().toString();
        String newpwd = et_newpwd.getText().toString();
        String repwd = et_repwd.getText().toString();

        Customer newInfo = new Customer();
        newInfo.setU_id(customer.getU_id());
        if (oldpwd != null && !oldpwd.trim().equals("")) {
            if (!oldpwd.equals(customer.getPassword())) {
                Toast.makeText(MyModifyPwdActivity.this, "原密码错误", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MyModifyPwdActivity.this, "请输入原密码", Toast.LENGTH_SHORT).show();
            return;
        }
        if (newpwd != null && !newpwd.trim().equals("")) {
            if (repwd != null && !repwd.trim().equals("")) {
                if (!repwd.equals(newpwd)) {
                    Toast.makeText(MyModifyPwdActivity.this, "两次密码输入不正确", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    newInfo.setPassword(newpwd);
                }
            } else {
                Toast.makeText(MyModifyPwdActivity.this, "请输入\"确认密码\"", Toast.LENGTH_SHORT).show();
                return;
            }
        } else {
            Toast.makeText(MyModifyPwdActivity.this, "请输入\"新密码\"", Toast.LENGTH_SHORT).show();
            return;
        }

        saveDataToServer(newInfo);
    }

    /**
     * 将数据保存到服务器
     * @param newInfo
     */
    private void saveDataToServer(Customer newInfo) {
        final String json = new Gson().toJson(newInfo);

        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath)
                        + "updateCustomerPwd.action";
                //String path = "http://10.86.2.15:8080/ssm01/updateCustomerPwd.action";
                SaveDataToServer.sendJsonToServer(json, path, handler);
            }
        }).start();
    }

    /**
     * 初始化视图
     */
    private void initView() {
        et_oldpwd = findViewById(R.id.et_oldpwd);
        et_newpwd = findViewById(R.id.et_newpwd);
        et_repwd = findViewById(R.id.et_repwd);
        btn_modify = findViewById(R.id.btn_modify);
    }

    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);

        //Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            case R.id.search:

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
