package com.example.manual;

import android.support.v4.app.Fragment;

public class MyActivity extends Fragment {



}
