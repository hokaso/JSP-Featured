package com.example.manual.Mall.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.manual.Mall.Bean.CartItemEntity;
import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.Bean.GoodsSpecs;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.util.List;

public class OrderConfirmAdapter  extends BaseAdapter {

    private List<CartItemEntity> itemList = null;
    private Context context;
    private ImageLoad imageLoad;

    public OrderConfirmAdapter(List<CartItemEntity> itemList, Context context) {
        this.itemList = itemList;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_orders, null);
        }

        ImageView iv_goodsPic = convertView.findViewById(R.id.iv_goodsPic);
        TextView tv_goods_name = convertView.findViewById(R.id.tv_goods_name);
        TextView tv_goods_describe = convertView.findViewById(R.id.tv_goods_describe);
        TextView tv_goods_price = convertView.findViewById(R.id.tv_goods_price);
        TextView tv_goods_specs = convertView.findViewById(R.id.tv_goods_specs);
        TextView tv_count = convertView.findViewById(R.id.tv_count);

        CartItemEntity item = itemList.get(position);
        GoodsSpecs specs = item.getSpecs();
        GoodsEntity goods = item.getGoods();

        String imgPath = context.getResources().getString(R.string.server_projectpath)
                + item.getSpecs().getSpecs_img();
        imageLoad.loadImage(iv_goodsPic, imgPath);
        tv_count.setText("数量: " + item.getCart_item_count()+ "");
        tv_goods_name.setText(goods.getGoods_name());
        tv_goods_describe.setText(goods.getGoods_describe());
        tv_goods_price.setText("￥" + specs.getSpecs_price());
        tv_goods_specs.setText(specs.getSpecs_attrs());

        return convertView;
    }
}
