package com.example.manual.Mall.netUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetDataFromService {

    public GetDataFromService() {
    }

    /**
     * 给定请求路径，返回json串
     * @param path
     * @return
     * @throws IOException
     */
    public static String resquestJson(String path) throws IOException {
        String responseJson = null;
        URL url = new URL(path);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        connection.connect();
        //发请求并读取服务器返回的数据
        int responseCode = connection.getResponseCode();

        if(responseCode==200) {
            InputStream is = connection.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len = -1;
            while ((len = is.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }
            baos.close();
            is.close();
            connection.disconnect();

            responseJson = baos.toString();
        } else {
            //也可以抛出运行时异常
        }
        return responseJson;
    }
}
