package entity;

public class Follow_Fan {

    private String u_id;
    private String fan_id;

    public String getU_id() {
        return u_id;
    }

    public void setU_id(String u_id) {
        this.u_id = u_id;
    }

    public String getFan_id() {
        return fan_id;
    }

    public void setFan_id(String fan_id) {
        this.fan_id = fan_id;
    }
}
