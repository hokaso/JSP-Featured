package com.example.manual.Mine.GetDataThread;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.example.manual.Mall.netUtil.GetDataFromService;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class GetFollow_FanThread extends Thread {

    private Handler handler;

    Connection connection = null;
    String path ;
    /* 传入两个参数，第一个是用于通信的handler，第二个是动态类型 */
    public GetFollow_FanThread(Handler h, String path) {
        this.handler = h;
        this.path = path;
    }

    @Override
    public void run() {
        try {
            String data = GetDataFromService.resquestJson(path);
            Log.i("ssss",data);
            Message message = handler.obtainMessage();
            message.what=222;
            Bundle bundle = new Bundle();
            bundle.putString("follow_fan",data);
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}