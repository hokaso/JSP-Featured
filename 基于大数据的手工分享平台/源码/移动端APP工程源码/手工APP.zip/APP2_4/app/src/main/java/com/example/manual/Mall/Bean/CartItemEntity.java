package com.example.manual.Mall.Bean;

public class CartItemEntity {

	private String cart_item_id;
	private Integer cart_item_count;
	private GoodsEntity goods;
	private CartEntity cart;
	private GoodsSpecs specs;
	
	public CartItemEntity(String cart_item_id, Integer cart_item_count, GoodsEntity goods, CartEntity cart,
			GoodsSpecs specs) {
		super();
		this.cart_item_id = cart_item_id;
		this.cart_item_count = cart_item_count;
		this.goods = goods;
		this.cart = cart;
		this.specs = specs;
	}
	public CartItemEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCart_item_id() {
		return cart_item_id;
	}
	public void setCart_item_id(String cart_item_id) {
		this.cart_item_id = cart_item_id;
	}
	public Integer getCart_item_count() {
		return cart_item_count;
	}
	public void setCart_item_count(Integer cart_item_count) {
		this.cart_item_count = cart_item_count;
	}
	public GoodsEntity getGoods() {
		return goods;
	}
	public void setGoods(GoodsEntity goods) {
		this.goods = goods;
	}
	public CartEntity getCart() {
		return cart;
	}
	public void setCart(CartEntity cart) {
		this.cart = cart;
	}
	public GoodsSpecs getSpecs() {
		return specs;
	}
	public void setSpecs(GoodsSpecs specs) {
		this.specs = specs;
	}
	@Override
	public String toString() {
		return "CartItemEntity [cart_item_id=" + cart_item_id + ", cart_item_count=" + cart_item_count + ", goods="
				+ goods + ", cart=" + cart + ", specs=" + specs + "]";
	}
}
