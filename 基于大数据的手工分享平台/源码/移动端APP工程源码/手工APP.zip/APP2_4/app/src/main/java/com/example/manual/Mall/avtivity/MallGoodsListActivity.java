package com.example.manual.Mall.avtivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.adapter.GoodsAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.List;

public class MallGoodsListActivity extends AppCompatActivity {

    private List<GoodsEntity> goodsList;
    private ListView mall_goods_listview;
    private GoodsAdapter adapter;
    private final int LOAD_SUCCESS = 1;
    private final int LOAD_ERROR = 0;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) { switch (msg.what) {
                case LOAD_SUCCESS:
                    adapter = new GoodsAdapter(goodsList, MallGoodsListActivity.this);
                    mall_goods_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            Bundle bundle = new Bundle();
                            // 获取商品id
                            GoodsEntity goods = goodsList.get(position);
                            bundle.putSerializable("goods", goods);
                            bundle.putString("goods_id", goods.getGoods_id());
                            Intent intent = new Intent(MallGoodsListActivity.this, MallGoodsDetailActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }
                    });
                    mall_goods_listview.setAdapter(adapter);
                    break;
                case LOAD_ERROR:
                    Toast.makeText(MallGoodsListActivity.this, "加载失败", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_goods_list);

        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("商品");

        Bundle bundle = getIntent().getExtras();
        String channel_name = bundle.getString("channel_name");
        final int category = bundle.getInt("channel_id");
        boolean isChannel = bundle.getBoolean("isChannel");
        String search = bundle.getString("search");

        mall_goods_listview = findViewById(R.id.mall_goods_listview);

        getDataFromServer(category, isChannel, search);
    }

    private void getDataFromServer(final int category, final boolean isChannel, final String search) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String path;
                    if (isChannel == true) {
                        path = getResources().getString(R.string.server_projectpath) +
                                "findGoodsByCategory.action?category=" + category;
                        /*path = "http://10.86.2.15:8080/ssm01/" +
                                "findGoodsByCategory.action?category=" + category;*/
                    } else {
                        path = getResources().getString(R.string.server_projectpath) +
                                "findGoodsBySearchBar.action?search=" + search;
                        /*path = "http://10.86.2.15:8080/ssm01/" +
                                "findGoodsBySearchBar.action?search=" + search;*/
                    }
                    String responseJosn = GetDataFromService.resquestJson(path);
                    goodsList = new Gson().fromJson(responseJosn, new TypeToken<List<GoodsEntity>>(){}.getType());
                    handler.sendEmptyMessage(LOAD_SUCCESS);
                } catch (Exception e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(LOAD_ERROR);
                }
            }
        }).start();
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
