package com.example.manual.Community;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.manual.R;

import java.text.SimpleDateFormat;
import java.util.Date;

import entity.Dynamic;
import entity.Customer;
import tool.SaveDynamicThread;

public class Community_publish extends AppCompatActivity {
    Customer customer;
    String type;
    String category;
    Dynamic cd;
    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){

        @Override
        public void handleMessage(Message msg) {
            //发布成功
            if(msg.what==111){
                Intent intent = new Intent();
                Bundle bundle = new Bundle();
                bundle.putSerializable("dynamic",cd);
                bundle.putSerializable("customer",customer);
                bundle.putString("u_id",customer.getU_id());
                bundle.putString("hostName",customer.getName());
                bundle.putString("hostHeadPic",customer.getHeadPicPath());
                intent.putExtra("data",bundle);

                intent.setClass(Community_publish.this,Community_fullActivity.class);
                startActivity(intent);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.community_publish);
        getSupportActionBar().hide();
        TextView tv = findViewById(R.id.publish);

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                EditText et1 = findViewById(R.id.title);
                EditText et2 = findViewById(R.id.content);
                String title = et1.getText().toString();
                String content = et2.getText().toString();
                //获取传过来的bundle
                Bundle bundle = getIntent().getBundleExtra("b");
                customer = (Customer) bundle.getSerializable("customer");
                type = bundle.getString("type");
                category = bundle.getString("category");
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String date = sdf.format(new Date());
                String d_id = System.currentTimeMillis()+"";
                Log.i("date",date.toString());
                //封装成实体
                cd = new Dynamic();
                cd.setContent(content);
                cd.setD_id(d_id);
                cd.setU_id(customer.getU_id());
                cd.setRelease_date(date);
                cd.setTitle(title);
                cd.setCategory(category);
                cd.setTotal_like(0);
                cd.setTotal_comment(0);
                //保存实体
                new SaveDynamicThread(cd,handler).start();
            }
        });

    }
}
