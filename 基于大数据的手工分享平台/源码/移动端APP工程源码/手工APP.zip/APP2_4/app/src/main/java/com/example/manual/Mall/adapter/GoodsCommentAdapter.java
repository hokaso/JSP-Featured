package com.example.manual.Mall.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.manual.Mall.Bean.GoodsCommentEntity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.util.List;

public class GoodsCommentAdapter extends BaseAdapter {

    private List<GoodsCommentEntity> data;
    private Context context;
    private ImageLoad imageLoad;

    public GoodsCommentAdapter (List<GoodsCommentEntity> data, Context context) {
        this.data = data;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_goods_comment, null);
        }

        GoodsCommentEntity comment = data.get(position);

        ImageView iv_user_head = convertView.findViewById(R.id.iv_user_head);
        TextView tv_username = convertView.findViewById(R.id.tv_username);
        TextView tv_comment_time = convertView.findViewById(R.id.tv_comment_time);
        TextView tv_comment_content = convertView.findViewById(R.id.tv_comment_content);
        TextView tv_specs = convertView.findViewById(R.id.tv_specs);

        tv_username.setText(comment.getCustomer().getName());
        tv_comment_time.setText(comment.getGoods_comment_time());

        //Log.e("content", "------###-----" + comment.getGoods_comment_content());
        tv_specs.setText(comment.getSpecs().getSpecs_attrs());
        tv_comment_content.setText(comment.getGoods_comment_content());
        String imagePath = context.getResources().getString(R.string.server_projectpath) + comment.getCustomer().getHeadPicPath();
        // 动态加载图片
        imageLoad.loadImage(iv_user_head, imagePath);

        return convertView;
    }
}
