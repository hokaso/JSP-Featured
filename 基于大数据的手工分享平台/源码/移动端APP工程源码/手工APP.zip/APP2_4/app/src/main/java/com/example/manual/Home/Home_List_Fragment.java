package com.example.manual.Home;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.manual.Community.Community_fullActivity;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import entity.Customer;
import entity.Dynamic;


public class Home_List_Fragment extends Fragment {

    private String u_id;//自己的ID

    //通过Get_Home更新聊天列表
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            ListView listView = null;
            switch (msg.what){
                case 0x003:
                    if(getActivity() == null) break;
                    else {
                        listView = getActivity().findViewById(R.id.home_list);
                        Bundle bundle = msg.getData();
                        List<ConcurrentHashMap<String, Object>> listitem =
                                (List<ConcurrentHashMap<String, Object>>) bundle.getSerializable("listitem");
                        SimpleAdapter adapter=new SimpleAdapter(getContext(), listitem, R.layout.home_list_fragment_item,
                                new String[]{"username", "title","count","release_date"}, new int[]{R.id.username, R.id.title,R.id.count,R.id.time});
                        listView.setAdapter(adapter);
                    }
                    break;
                default:
                    break;
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        //获取自己的ID
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson","");
        Gson gson = new Gson();
        Customer customer = gson.fromJson(customerJson, Customer.class);
        u_id = customer.getU_id(); //赋值自己的ID


        //启动一个子线程，刷新一次Home推荐列表
        Get_Home gh = new Get_Home(handler, u_id);
        gh.start();


        View view = inflater.inflate(R.layout.home_list_fragment,null);
        ListView listView=view.findViewById(R.id.home_list);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Map<String, Object> map= (Map<String, Object>) parent.getItemAtPosition(position);
                String name=map.get("username").toString();
                String title=map.get("title").toString();
                String time = map.get("release_date").toString();
                String content = map.get("content").toString();
                String u_id = map.get("u_id").toString();
                String d_id = map.get("d_id").toString();
                String headpic = map.get("headpic").toString();
            /*    String type = map.get("type").toString();*/
                String category = map.get("category").toString();
                int total_like = (int)map.get("total_like");
                int total_comment = (int) map.get("total_comment");
                /* Customer customer = new Customer();
                customer.setName(name);
                customer.setU_id(u_id);*/
                Dynamic cd = new Dynamic();
                cd.setTotal_like(total_like);
                cd.setTotal_comment(total_comment);
                cd.setTitle(title);
                cd.setD_id(d_id);
                cd.setContent(content);
                cd.setRelease_date(time);
               /* cd.setType(type);*/
                cd.setCategory(category);
                Bundle bundle =new Bundle();
                bundle.putString("u_id",u_id);
                bundle.putString("hostName",name);
                bundle.putString("hostHeadPic",headpic);
                bundle.putSerializable("dynamic",cd);


                //存放到历史记录
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("customer", Context.MODE_PRIVATE);
                String str = sharedPreferences.getString("customerJson","");
                Gson gson = new Gson();
                Customer customer = gson.fromJson(str,Customer.class);
                SharedPreferences history = getActivity().getSharedPreferences(customer.getU_id(), Context.MODE_PRIVATE);
                String his = history.getString("historyList","");
                List<String> historyList = gson.fromJson(his,new TypeToken<List<String>>() {
                }.getType());
                if(historyList==null){
                    historyList = new ArrayList<>();
                }
                //不存在，才加进去
                if(!historyList.contains(cd.getD_id())){
                    historyList.add(cd.getD_id());
                }
                his = gson.toJson(historyList);
                SharedPreferences.Editor edit = history.edit();
                edit.putString("historyList",his);
                edit.apply();
                edit.commit();
                System.out.println(his);

                Intent intent = new Intent();
                intent.setClass(getContext(),Community_fullActivity.class);
                intent.putExtra("data",bundle);
                startActivity(intent);

            }
        });

        return view;

    }
}
