package com.example.manual.Mall.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.manual.Mall.Bean.OrderEntity;
import com.example.manual.Mall.avtivity.MallOrderDetailActivity;
import com.example.manual.Mall.avtivity.MallOrderPayActivity;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.List;

import entity.Customer;

public class OrderListAdapter extends BaseAdapter {

    private Context context;
    private List<OrderEntity> orders;
    private String json;
    private Handler handler;
    private Customer customer;

    public OrderListAdapter(Context context, List<OrderEntity> orders, Handler handler, Customer customer) {
        this.context = context;
        this.orders = orders;
        this.handler = handler;
        this.customer = customer;
    }

    public OrderListAdapter(Context context, String json, Handler handler, Customer customer) {
        this.context = context;
        this.json = json;
        this.handler = handler;
        this.customer = customer;
        orders = new Gson().fromJson(json, new TypeToken<List<OrderEntity>>(){}.getType());
    }

    @Override
    public int getCount() {
        return orders.size();
    }

    @Override
    public Object getItem(int position) {
        return orders.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_orderitem, null);
        }
        TextView tv_ordertime = convertView.findViewById(R.id.tv_ordertime);
        TextView tv_total_money = convertView.findViewById(R.id.tv_total_money);
        TextView tv_order_state = convertView.findViewById(R.id.tv_order_state);
        RelativeLayout rl_time_money_state = convertView.findViewById(R.id.rl_time_money_state);
        Button btn_pay = convertView.findViewById(R.id.btn_pay);
        Button btn_cancel = convertView.findViewById(R.id.btn_cancel);
        Button btn_signed = convertView.findViewById(R.id.btn_signed);
        Button btn_delete = convertView.findViewById(R.id.btn_delete);
        Button btn_refund = convertView.findViewById(R.id.btn_refund);

        OrderEntity order = orders.get(position);
        tv_total_money.setText("金额: " + order.getOrder_totalPrice());

        String sate = order.getOrder_state();
        tv_order_state.setText(sate);

        if (sate.equals(OrderEntity.STATE_UNPAID)) {// 未付款
            tv_ordertime.setText("创建时间: " + order.getOrder_create_time());
            btn_pay.setVisibility(View.VISIBLE);
            btn_cancel.setVisibility(View.VISIBLE);
            btn_refund.setVisibility(View.GONE);
            btn_signed.setVisibility(View.GONE);
            btn_delete.setVisibility(View.GONE);
        } else if (sate.equals(OrderEntity.STATE_UNDELIVER)) {// 未发货
            tv_ordertime.setText("付款时间: " + order.getOrder_paytime());
            btn_pay.setVisibility(View.GONE);
            btn_cancel.setVisibility(View.GONE);
            btn_refund.setVisibility(View.VISIBLE);
            btn_signed.setVisibility(View.GONE);
            btn_delete.setVisibility(View.GONE);
        } else if (sate.equals(OrderEntity.STATE_DELIVERED)) {// 已发货
            tv_ordertime.setText("付款时间: " + order.getOrder_paytime());
            btn_pay.setVisibility(View.GONE);
            btn_cancel.setVisibility(View.GONE);
            btn_refund.setVisibility(View.GONE);
            btn_signed.setVisibility(View.VISIBLE);
            btn_delete.setVisibility(View.GONE);
        } else {// 已签收
            if (order.getOrder_paytime() == null) {
                tv_ordertime.setText("付款时间: 未进行付款");
            } else {
                tv_ordertime.setText("付款时间: " + order.getOrder_paytime());
            }
            btn_pay.setVisibility(View.GONE);
            btn_cancel.setVisibility(View.GONE);
            btn_signed.setVisibility(View.GONE);
            btn_refund.setVisibility(View.GONE);
            btn_delete.setVisibility(View.VISIBLE);
        }

        // “付款”监听
        setBtn_pay(btn_pay, position, order);

        // “取消订单”监听
        setBtn_cancelAndSigned(btn_cancel, OrderEntity.STATE_REFUND, order);

        // “确认签收”监听
        setBtn_cancelAndSigned(btn_signed, OrderEntity.STATE_SIGNED, order);

        // “删除订单”监听
        // setBtn_delete(btn_delete, order.getOrder_id());
        setBtn_delete(btn_delete, order, position);

        // “申请退款”监听
        // setBtn_refund(btn_refund, order.getOrder_id(), customer.getU_id(), OrderEntity.STATE_REFUND);
        setBtn_refund(btn_refund, order, customer.getU_id(), OrderEntity.STATE_REFUND);

        setRl_time_money_state(rl_time_money_state, order.getOrder_id());

        return convertView;
    }

    /**
     * 跳转至订单详细页面
     * @param rl_time_money_state
     * @param order_id
     */
    private void setRl_time_money_state(RelativeLayout rl_time_money_state, final String order_id) {
        rl_time_money_state.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                bundle.putString("order_id", order_id);
                Intent intent = new Intent(context, MallOrderDetailActivity.class);
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });
    }

    /**
     * “申请退款”监听
     * @param btn_refund
     * @param u_id
     */
    private void setBtn_refund(Button btn_refund, final OrderEntity order, final String u_id, final String sate) {
        btn_refund.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refundOrder(order.getOrder_id(), u_id, sate);
                order.setOrder_state(sate);
            }
        });
    }
    /*private void setBtn_refund(Button btn_refund, final String order_id, final String u_id, final String sate) {
        btn_refund.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refundOrder(order_id, u_id, sate);
            }
        });
    }*/

    /**
     * 申请退款
     * @param order_id
     * @param u_id
     * @param sate
     */
    private void refundOrder(String order_id, String u_id, String sate) {
        final String path = context.getResources().getString(R.string.server_projectpath) +
            "refundOrder.action?order_id=" + order_id + "&u_id=" + u_id;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String res = GetDataFromService.resquestJson(path);
                    if (res.equals("success")) {
                        handler.sendEmptyMessage(100);
                    } else {
                        handler.sendEmptyMessage(99);
                    }
                } catch (IOException e) {
                    handler.sendEmptyMessage(59);
                    e.printStackTrace();
                }
            }
        }).start();
    }
    /*private void refundOrder(String order_id, String u_id, String sate) {
        //final String path = context.getResources().getString(R.string.server_projectpath) +
                //"refundOrder.action?order_id=" + order_id + "&u_id=" + u_id;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String res = GetDataFromService.resquestJson(path);
                    if (res.equals("success")) {
                        handler.sendEmptyMessage(100);
                    } else {
                        handler.sendEmptyMessage(99);
                    }
                } catch (IOException e) {
                    handler.sendEmptyMessage(59);
                    e.printStackTrace();
                }
            }
        }).start();
    }*/

    /**
     * “删除订单”监听
     * @param btn_delete
     */
    private void setBtn_delete(Button btn_delete, final OrderEntity order, final int position) {
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteOrder(order.getOrder_id());
                orders.remove(position);
            }
        });
    }
    /*private void setBtn_delete(Button btn_delete, final String order_id) {
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteOrder(order_id);

            }
        });
    }*/

    /**
     * “取消订单”和“确认签收”监听
     * @param btn
     * @param state
     */
    private void setBtn_cancelAndSigned(Button btn, final String state, final OrderEntity order) {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateOrderState(order.getOrder_id(), state);
                order.setOrder_state(state);
            }
        });
    }

    /**
     * “付款”监听
     * @param btn_pay
     * @param position
     */
    private void setBtn_pay(Button btn_pay, final int position, final OrderEntity order) {
        btn_pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle();
                double total = order.getOrder_totalPrice();
                String order_id = order.getOrder_id();
                bundle.putDouble("total", total);
                bundle.putString("order_id", order_id);
                Intent intent = new Intent(context, MallOrderPayActivity.class);
                intent.putExtras(bundle);
                context.startActivity(intent);
                Bundle bMesg = new Bundle();
                bMesg.putInt("position", position);
                Message message = new Message();
                message.what = 22;
                message.setData(bMesg);
                handler.sendMessage(message);
            }
        });
    }

    /**
     * “删除订单”
     */
    private void deleteOrder(String order_id) {
        final String path = context.getResources().getString(R.string.server_projectpath) +
                "deleteOrder.action?order_id=" + order_id;
        /*final String path = "http://10.86.2.15:8080/ssm01/" +
                "deleteOrder.action?order_id=" + order_id;*/

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String res = GetDataFromService.resquestJson(path);
                    if (res.equals("success")) {
                        handler.sendEmptyMessage(100);
                    } else {
                        handler.sendEmptyMessage(99);
                    }
                } catch (IOException e) {
                    handler.sendEmptyMessage(59);
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * 更新订单状态
     * @param order_id
     * @param state
     */
    private void updateOrderState(String order_id, String state) {
        final String path = context.getResources().getString(R.string.server_projectpath) +
                "updateOrderState.action?order_id=" + order_id + "&order_state=" + state;
       /* final String path = "http://10.86.2.15:8080/ssm01/" +
                "updateOrderState.action?order_id=" + order_id + "&order_state=" + state;*/
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String res = GetDataFromService.resquestJson(path);
                    if (res.equals("success")) {
                        handler.sendEmptyMessage(100);
                    } else {
                        handler.sendEmptyMessage(99);
                    }
                } catch (IOException e) {
                    handler.sendEmptyMessage(59);
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
