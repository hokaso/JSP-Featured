package tool;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static tool.JDBCutils.*;

public class GetCommentThread extends Thread {

    Handler handler;
    String d_id;
    public GetCommentThread(Handler handler,String d_id){
        this.handler = handler;
        this.d_id = d_id;
    }

    @Override
    public void run() {

        try{
            Connection connection = getConnection();
            String sql ="select * from comment,customer where comment.d_id ='"+d_id+"' and comment.u_id = customer.u_id order by time";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            int i = 0;
            String[] username = new String[128];
            String[] head = new String[128];
            String[] time = new String[128];
            String[] comment = new String[128];
            Log.i("mmm",sql);
            ArrayList<Map<String, Object>> listitem = new ArrayList<Map<String, Object>>();
            while(resultSet.next()){
                username[i] = resultSet.getString("name");
                head[i] = resultSet.getString("head");
                time[i] = resultSet.getString("time");
                comment[i] = resultSet.getString("content");
                Log.i("mmm",comment[i]);
                Map<String, Object> map = new HashMap<String, Object>();
                map.put("username", username[i]);
                map.put("head", head[i]);
                map.put("time", time[i]);
                map.put("content" , comment[i]);
                i++;
                listitem.add(map);
            }
            //添加一个空的，以便下拉时能全部显示
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("username", "");
            map.put("head", "");
            map.put("time", "");
            map.put("content" , "");
            listitem.add(map);
            Bundle bundle = new Bundle();
            Message message=new Message();
            bundle.putSerializable("listitem",listitem);
            message.setData(bundle);
            handler.sendMessage(message);

        }catch (Exception e){
            e.printStackTrace();
        }


    }
}
