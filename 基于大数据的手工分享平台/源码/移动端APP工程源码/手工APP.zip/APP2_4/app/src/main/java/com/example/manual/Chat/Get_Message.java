package com.example.manual.Chat;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import java.sql.Connection;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import tool.JDBCutils;

public class Get_Message extends Thread{

    private Handler handler;
    private String u_id;
    private String t_id;

    public Get_Message(Handler h, String u, String t) {
        this.handler = h;
        this.u_id = u;
        this.t_id = t;
    }

    @Override
    public void run() {
        Statement stmt=null;
        Connection conn=null;
        try {
            //1.注册驱动程序，2.获取连接对象
            conn = JDBCutils.getConnection();
            //3.创建Statement
            stmt = conn.createStatement();
            //4.准备sql
            String sql = "select * from message where u_id ='"+u_id+"' and t_id='"+t_id+"' or " +
                    "t_id ='"+u_id+"' and u_id='"+t_id+"' "+"order by message_id";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            ResultSet rs = stmt.executeQuery(sql);

            int i=0;
            String[] message_id_set = new String[1000000];
            String[] u_id_set = new String[1000000];
            String[] t_id_set = new String[1000000];
            String[] time_set = new String[1000000];
            String[] context_set = new String[1000000];
            ArrayList<ConcurrentHashMap<String, Object>> listitem = new ArrayList<ConcurrentHashMap<String, Object>>();

            //获取各种动态类型的数据
            while(rs.next()) {
                message_id_set[i] = rs.getString("message_id");
                u_id_set[i] = rs.getString("u_id");
                t_id_set[i] = rs.getString("t_id");
                time_set[i] = rs.getString("time");
                context_set[i] = rs.getString("context");
                System.out.println("message_id_set[i] = "+message_id_set[i]);

                ConcurrentHashMap<String, Object> CHmap = new ConcurrentHashMap<String, Object>();
                CHmap.put("message_id", message_id_set[i]);
                CHmap.put("u_id", u_id_set[i]);
                CHmap.put("t_id", t_id_set[i]);
                CHmap.put("time", time_set[i]);
                CHmap.put("context", context_set[i]);
                listitem.add(CHmap);
                i++;
            }
            Bundle bundle = new Bundle();
            Message message = new Message();
            bundle.putSerializable("listitem", listitem);
            message.what=0x001;
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
