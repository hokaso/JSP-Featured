package com.example.manual.Mall.netUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class SaveDataToServer {

    private static int UPLOAD_SUCCESS = 200;
    private static int UPLOAD_ERROR = 500;

    public SaveDataToServer() {
    }

    /**
     * 将json串发送到服务器,需要在分线程中使用
     * @param json  经对象转化的json串
     * @param path  请求路径
     */
    public static void sendJsonToServer(String json, String path, Handler handler) {
        try {
            URL url = new URL(path);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.connect();
            OutputStream outputStream = urlConnection.getOutputStream();
            outputStream.write(json.getBytes("utf-8"));

            outputStream.flush();
            /*int code = connection.getResponseCode();    // 获取请求码*/
            int code = urlConnection.getResponseCode();
            Log.e("code", "-------------------111111111111111----------" + json);
            InputStream is = urlConnection.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len = -1;
            while ((len = is.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }
            String result = baos.toString();
            // Log.e("code", "-------------------222222222----------" + result);
            if(result.equals("success")){
                handler.sendEmptyMessage(UPLOAD_SUCCESS);     // 回传请求码
            } else {
                Message message = new Message();
                Bundle bundle = new Bundle();
                bundle.putString("error_msg", result);
                message.what = UPLOAD_ERROR;
                message.setData(bundle);
                handler.sendMessage(message);
            }
            outputStream.close();   // 关闭流
            urlConnection.disconnect();    // 关闭连接
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
