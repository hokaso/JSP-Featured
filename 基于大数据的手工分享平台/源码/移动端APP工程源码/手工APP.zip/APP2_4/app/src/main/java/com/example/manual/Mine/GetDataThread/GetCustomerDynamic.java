package com.example.manual.Mine.GetDataThread;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entity.Customer;
import entity.Dynamic;
import tool.JDBCutils;

public class GetCustomerDynamic extends Thread {
    private Handler handler;

    Connection connection = null;
    String u_id ;
    String thisu_id;
    /* 传入两个参数，第一个是用于通信的handler，第二个是动态类型 */
    public GetCustomerDynamic(Handler h, String u_id,String thisu_id) {
        this.handler = h;
        this.u_id = u_id;
        this.thisu_id = thisu_id;
    }
    @Override
    public void run() {

        try {

            connection = JDBCutils.getConnection();
            //先找出用户对象的信息
            String sql ="select * from customer where u_id='"+u_id+"'";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            Customer customer = new Customer();
            while(resultSet.next()){
                System.out.println(resultSet.getString("headPicPath"));
                customer.setName(resultSet.getString("name"));
                customer.setHeadPicPath(resultSet.getString("headPicPath"));
                customer.setPhonenumber(resultSet.getString("phonenumber"));
                customer.setAddress(resultSet.getString("password"));
                customer.setGender(resultSet.getString("gender"));
                customer.setLocation(resultSet.getString("location"));
                customer.setSignature(resultSet.getString("signature"));
            }
            //获取动态
            String sql2 ="select * from dynamic where u_id='"+u_id+"' order by release_date desc";
            PreparedStatement preparedStatement2 = connection.prepareStatement(sql2);
            ResultSet resultSet2 = preparedStatement2.executeQuery();
            ArrayList<Dynamic> list = new ArrayList<>();
            while(resultSet2.next()){
                Dynamic dynamic = new Dynamic();
                dynamic.setD_id(resultSet2.getString("d_id"));
                dynamic.setU_id(resultSet2.getString("u_id"));
                dynamic.setTitle(resultSet2.getString("title"));
                dynamic.setContent(resultSet2.getString("content"));
                dynamic.setRelease_date(resultSet2.getString("release_date"));
                dynamic.setCategory(resultSet2.getString("category"));
                dynamic.setTotal_like(resultSet2.getInt("total_like"));
                dynamic.setTotal_comment(resultSet2.getInt("total_comment"));
                list.add(dynamic);
            }
            //获取关注人数
            String sql3 ="select count(*) from follow_fan where fan_id='"+u_id+"'";
            PreparedStatement preparedStatement3 = connection.prepareStatement(sql3);
            ResultSet resultSet3 = preparedStatement3.executeQuery();
            resultSet3.next();
            int followCount = resultSet3.getInt(1);
            String sql4 ="select count(*) from follow_fan where fan_id='"+u_id+"'";
            PreparedStatement preparedStatement4 = connection.prepareStatement(sql4);
            ResultSet resultSet4 = preparedStatement4.executeQuery();
            resultSet4.next();
            int fanCount = resultSet4.getInt(1);

            //查询数据库，获取是否已关注该用户
            String sql5 ="select count(*) from follow_fan where fan_id='"+u_id+"' and u_id='"+thisu_id+"'";
            PreparedStatement preparedStatement5 = connection.prepareStatement(sql5);
            ResultSet resultSet5 = preparedStatement5.executeQuery();
            resultSet5.next();
            int flag = resultSet5.getInt(1);


            Message message = handler.obtainMessage();
            Bundle bundle = new Bundle();
            bundle.putSerializable("customer",customer);
            bundle.putSerializable("dynamicList",list);
            bundle.putInt("followCount",followCount);
            bundle.putInt("fanCount",fanCount);
            bundle.putInt("flag",flag);
            Log.i("sfafasfasssssssssssssss",followCount+","+fanCount);
            message.setData(bundle);
            message.what=111;
            handler.sendMessage(message);


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
