package com.example.manual.Mine.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.manual.MainActivity;
import com.example.manual.R;
import com.google.gson.Gson;

import entity.Customer;
import tool.LoginThread;

public class LoginActivity extends AppCompatActivity {

    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @SuppressLint("CommitPrefEdits")
        @Override
        public void handleMessage(Message message){

            switch (message.what){
                case 111:
                    Bundle data = message.getData();
                    Customer customer = (Customer) data.getSerializable("customer");
                    //创建一个customer.xml存储数据，并设置为私人模式
                    SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);

                   //对象转为json串，方便存进sp中
                    Gson gson = new Gson();
                    String s = gson.toJson(customer);
                    SharedPreferences.Editor edit = sharedPreferences.edit();
                    edit.putString("customerJson",s);
                    edit.commit();
                    Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent();
                    intent.setClass(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    break;
                case 000:
                    //登录失败
                    Toast.makeText(getApplicationContext(),"账号密码错误",Toast.LENGTH_SHORT).show();
                    break;
            }

        }

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        setContentView(R.layout.myself_login);

        if(check()){
            Intent intent = new Intent();
            intent.setClass(LoginActivity.this,MainActivity.class);
            startActivity(intent);
        }
        //登录监听
        Button login = findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText et1 = findViewById(R.id.username);
                EditText et2 = findViewById(R.id.password);
                String username = et1.getText().toString();
                String password = et2.getText().toString();

                Customer customer = new Customer();
                customer.setPhonenumber(username);
                customer.setPassword(password);
                Thread thread = new LoginThread(customer,handler);
                thread.start();

            }
        });
        //注册监听
        Button register = findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 Intent intent = new Intent();
                 intent.setClass(LoginActivity.this, RegisterActivity.class);
                 startActivity(intent);
            }
        });


    }
    //检查登录状态
    public boolean check(){
        SharedPreferences sharedPreferences = getSharedPreferences("customer",MODE_PRIVATE);
        SharedPreferences.Editor edit = sharedPreferences.edit();
        edit.clear();
        edit.apply();
        String customerJson = sharedPreferences.getString("customerJson","");
        Log.i("ss",customerJson);
        if(customerJson.equals("")){
            return false;
        }else{
            return true;
        }

    }

}
