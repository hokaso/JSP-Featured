package com.example.manual.Mine.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.util.ArrayList;
import java.util.List;

import entity.Customer;
import entity.Dynamic;

public class DynamicAdapter extends BaseAdapter {

    List<Dynamic> data = new ArrayList<Dynamic>();
    private Context context;

    public DynamicAdapter() {
    }

    public DynamicAdapter(Context context) {
        this.context = context;

    }

    public DynamicAdapter(List<Dynamic> data, Context context) {
        this.data = data;
        this.context = context;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = View.inflate(context, R.layout.myself_mydynamic_item, null);
        }

        //获取当前对象
        Dynamic dynamic = data.get(position);

        // 获取子view
        TextView time = convertView.findViewById(R.id.time);
        TextView title = convertView.findViewById(R.id.title);
        time.setText(dynamic.getRelease_date());
        title.setText(dynamic.getTitle());
        TextView count = convertView.findViewById(R.id.count);
        count.setText("点赞："+dynamic.getTotal_like()+" 评论："+dynamic.getTotal_comment());

        return convertView;
    }
}
