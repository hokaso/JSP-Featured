package com.example.manual.Mall.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.CartItemEntity;
import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.Bean.GoodsSpecs;
import com.example.manual.Mall.avtivity.MallGoodsDetailActivity;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import android.os.Handler;

public class CartAdapter extends BaseAdapter {

    private static List<CartItemEntity> itemList = null;
    private Context context;
    private ImageLoad imageLoad;
    private Map<Integer,Boolean> checkBoxMap=new HashMap<>();
    private Handler handler;
    private int trueCount = 0;
    private SparseBooleanArray isSelected;

    public CartAdapter(List<CartItemEntity> itemList, Context context) {
        this.itemList = itemList;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    public CartAdapter(List<CartItemEntity> itemList, Context context, Handler handler) {
        this.itemList = itemList;
        this.context = context;
        this.handler = handler;
        imageLoad = new ImageLoad(context);
        isSelected = new SparseBooleanArray();
        initSparseBooleanArray();
    }

    /**
     * 初始化数据
     */
    private void initSparseBooleanArray() {
        for (int i = 0; i < itemList.size(); i++) {
            getIsSelected().put(i, false);
        }
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_cart, null);
        }

        CartItemEntity item = itemList.get(position);
        CheckBox checkbox = convertView.findViewById(R.id.checkbox);
        ImageView iv_goodsPic = convertView.findViewById(R.id.iv_goodsPic);
        TextView tv_goods_name = convertView.findViewById(R.id.tv_goods_name);
        TextView tv_goods_describe = convertView.findViewById(R.id.tv_goods_describe);
        TextView tv_goods_price = convertView.findViewById(R.id.tv_goods_price);
        TextView tv_tips_state = convertView.findViewById(R.id.tv_tips_state);
        TextView tv_goods_specs = convertView.findViewById(R.id.tv_goods_specs);

        TextView tv_count = convertView.findViewById(R.id.tv_count);
        ImageView btn_add = convertView.findViewById(R.id.btn_add);
        ImageView btn_sub = convertView.findViewById(R.id.btn_sub);
        if (item.getGoods().getGoods_state() == 1) {
            tv_tips_state.setVisibility(View.GONE);
        } else {
            tv_tips_state.setVisibility(View.VISIBLE);
        }

        GoodsSpecs specs = item.getSpecs();
        GoodsEntity goods = item.getGoods();
        tv_count.setText(item.getCart_item_count()+ "");
        tv_goods_name.setText(goods.getGoods_name());
        tv_goods_describe.setText(goods.getGoods_describe());
        tv_goods_price.setText("￥" + specs.getSpecs_price());
        tv_goods_specs.setText(specs.getSpecs_attrs());
        String imgPath = context.getResources().getString(R.string.server_projectpath)
                + item.getSpecs().getSpecs_img();
        imageLoad.loadImage(iv_goodsPic, imgPath);

        checkbox.setChecked(isSelected.get(position));
        // 设置checkbox视图监听事件以及给checkBoxMap赋值
        setCheckbox(checkbox, position);

        // 设置“加、减按键”监听
        setBtn_add_sub(btn_add, position, tv_count, checkbox);
        setBtn_add_sub(btn_sub, position, tv_count, checkbox);

        LinearLayout ll_name = convertView.findViewById(R.id.ll_name);
        ll_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                turnToGoodDetail(position);
            }
        });

        iv_goodsPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                turnToGoodDetail(position);
            }
        });

        return convertView;
    }

    /**
     * 跳转至商品详细页面
     * @param position
     */
    private void turnToGoodDetail(int position) {
        GoodsEntity goods = itemList.get(position).getGoods();
        Bundle gb = new Bundle();
        gb.putSerializable("goods", (Serializable) goods);
        gb.putString("goods_id", goods.getGoods_id());
        Intent intent = new Intent(context, MallGoodsDetailActivity.class);
        intent.putExtras(gb);
        context.startActivity(intent);
    }

    /**
     * 删除已选中的item
     * @param items
     * @param nos
     */
    public void deleteArray(List<CartItemEntity> items, List<Integer> nos) {
        // Log.e("flag-----", "2112121221");
        itemList.removeAll(items);
        for (Integer i : nos) {
            checkBoxMap.remove(i);
            isSelected.delete(i);
        }
        calCheckedItem();
        this.notifyDataSetChanged();
    }

    /**
     * 设置“加、减”监听
     * @param btnAddSub
     * @param position
     * @param tv_count
     */
    private void setBtn_add_sub(final ImageView btnAddSub, final int position, final TextView tv_count, final CheckBox checkbox) {
        final GoodsSpecs specs = itemList.get(position).getSpecs();
        final GoodsEntity goods = itemList.get(position).getGoods();

        btnAddSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.btn_add :
                        if (goods.getGoods_state() == 0) {
                            Toast.makeText(context, "操作失败，商品已下载", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            setAddSub(1, position, tv_count);
                            if (checkbox.isChecked()) {
                                handler.sendEmptyMessage(10086);
                            }
                        }
                        break;
                    case R.id.btn_sub:
                        if (goods.getGoods_state() == 0) {
                            Toast.makeText(context, "操作失败，商品已下载", Toast.LENGTH_SHORT).show();
                            return;
                        } else {
                            setAddSub(-1, position, tv_count);
                            if (checkbox.isChecked()) {
                                handler.sendEmptyMessage(10086);
                            }
                        }
                        break;
                }
            }

        });
    }

    /**
     * 设置“加、减按键”监听实现
     * @param i
     * @param position
     * @param tv_count
     */
    private void setAddSub(final int i, final int position, final TextView tv_count) {
        final CartItemEntity item = itemList.get(position);
        final int count = Integer.parseInt(tv_count.getText().toString());
        GoodsSpecs specs = item.getSpecs();
        final Handler han = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                switch (msg.what) {
                    case 100:
                        Toast.makeText(context, "操作失败，商品已下载", Toast.LENGTH_SHORT).show();
                        break;
                    case 200:
                        Toast.makeText(context, "操作失败，已经达到库存最大值", Toast.LENGTH_SHORT).show();
                    case 300:
                        tv_count.setText((count + i) + "");
                        item.setCart_item_count(count + i);
                        break;
                }
            }
        };

        if (count + i > specs.getSpecs_stock()) {
            Toast.makeText(context, "操作失败，已经达到库存最大值", Toast.LENGTH_LONG).show();
            return;
        }
        if (count + i < 1) {
            Toast.makeText(context, "不能再减啦！", Toast.LENGTH_SHORT).show();
            return;
        }
        item.setCart_item_count(count + i);
        // 联网请求
        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = context.getResources().getString(R.string.server_projectpath) +
                        "changeCartItemCount.action?cart_item_id=" + item.getCart_item_id() +
                        "&cart_item_count=" + item.getCart_item_count();
                /*String path = "http://10.86.2.15:8080/ssm01/" +
                        "changeCartItemCount.action?cart_item_id=" + item.getCart_item_id() +
                        "&cart_item_count=" + item.getCart_item_count();*/
                try {
                    String result = GetDataFromService.resquestJson(path);
                    Message m = new Message();
                    if (result != null) {
                        if (result.equals("stop_sell")) {
                            m.what = 100;
                            return;
                        }
                        if (result.equals("max_stock")) {
                            //Toast.makeText(context, "操作失败，已经达到库存最大值", Toast.LENGTH_SHORT).show();
                            m.what = 200;
                            return;
                        }
                        m.what = 300;
                        Bundle b = new Bundle();
                        b.putInt("position", position);
                        m.setData(b);
                        han.sendMessage(m);
                    }
                } catch (IOException e) {
                    //Toast.makeText(context, "操作失败", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * 设置checkbox视图监听事件以及给checkBoxMap赋值
     * @param checkbox
     * @param position
     */
    private void setCheckbox(final CheckBox checkbox, final int position) {
        checkbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkbox.isChecked()){
                    checkBoxMap.put(position,true);
                    trueCount ++;
                }else {
                    checkBoxMap.remove(position);
                    if(trueCount > 0) {
                        trueCount --;
                    }
                }
                calCheckedItem();
            }
        });

        if(checkBoxMap!=null&&checkBoxMap.containsKey(position)){
            checkbox.setChecked(true);
        }else {
            checkbox.setChecked(false);
        }
    }

    /**
     * 计算已选中的item
     */
    private void calCheckedItem() {
        BigDecimal total = new BigDecimal("0");
        for (int i : checkBoxMap.keySet()
        ) {
            CartItemEntity item = itemList.get(i);
            BigDecimal count = new BigDecimal(item.getCart_item_count() + "");
            BigDecimal price = new BigDecimal(item.getSpecs().getSpecs_price() + "");
            BigDecimal subTotal = count.multiply(price);
            total = total.add(subTotal);
        }
        double money = Double.parseDouble(total.toString());
        //Toast.makeText(context, money+"", Toast.LENGTH_SHORT).show();
        boolean allSelected = false;
        if (trueCount == itemList.size()) {
            allSelected = true;
        }
        Bundle bundle = new Bundle();
        bundle.putDouble("total", money);
        bundle.putBoolean("allSelected", allSelected);
        Message message = new Message();
        message.setData(bundle);
        message.what = 1;
        handler.sendMessage(message);
    }

    //////////////////////getter and setter方法///////////////////////////////
    public Map<Integer, Boolean> getCheckBoxMap() {
        return checkBoxMap;
    }

    public void setCheckBoxMap(Map<Integer, Boolean> checkBoxMap) {
        this.checkBoxMap = checkBoxMap;
    }

    public static List<CartItemEntity> getItemList() {
        return itemList;
    }

    public void setItemList(List<CartItemEntity> itemList) {
        this.itemList = itemList;
    }

    public SparseBooleanArray getIsSelected() {
        return isSelected;
    }

    public void setIsSelected(SparseBooleanArray isSelected) {
        this.isSelected = isSelected;
    }
}
