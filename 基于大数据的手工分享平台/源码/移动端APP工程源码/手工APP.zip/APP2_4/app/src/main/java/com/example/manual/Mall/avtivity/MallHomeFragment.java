package com.example.manual.Mall.avtivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SimpleAdapter;

import com.example.manual.Mall.Bean.Mall_Channel_Name;
import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.R;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entity.Customer;

public class MallHomeFragment extends Fragment implements View.OnClickListener {
    private Button btn_search;
    private EditText et_about_goods;
    private ImageButton collection;
    private ImageButton cart;
    private ImageButton order;
    private LinearLayout ll_collection;
    private LinearLayout ll_cart;
    private LinearLayout ll_order;
    private GridView channle_gridView;
    private List<Map<String, Object>> gridListItems;
    Customer customer;
    /**频道（分类）名称*/
    private String[] channel_names = {Mall_Channel_Name.NAME_WEAVE, Mall_Channel_Name.NAME_PAPER,
            Mall_Channel_Name.NAME_ORNAMENTS, Mall_Channel_Name.NAME_LEATHER,
            Mall_Channel_Name.NAME_FABRIC, Mall_Channel_Name.NAME_EMBROIDERY };

    /**频道图标*/
    private int[] channel_icons = {R.drawable.a1, R.drawable.a2, R.drawable.a3, R.drawable.a4, R.drawable.a5, R.drawable.a6};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_mall_home, null);
        initView(view);

        // 实例化gride
        initGridListItems();

        SimpleAdapter channelAdapter = new SimpleAdapter(getActivity(), gridListItems,
                R.layout.mall_item_channel,
                new String[]{"channel_icon", "channel_name"},
                new int[]{R.id.iv_channel_icon, R.id.tv_channel_name});

        channle_gridView.setAdapter(channelAdapter);
        channle_gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Toast.makeText(MallHomeActivity.this, channel_names[position] + position, Toast.LENGTH_SHORT).show();
                Bundle bundle = new Bundle();
                bundle.putString("channel_name", channel_names[position]);
                bundle.putBoolean("isChannel", true);
                // 传递想对应的频道（分类）id
                bundle.putInt("channel_id", position+1);
                Intent intent = new Intent(getActivity(), MallGoodsListActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.collection:// 收藏监听
                turnToCollection();
                break;
            case R.id.cart:// 购物车监听
                turnToCart();
                break;
            case R.id.order:// 订单监听
                turnToMyOrder();
                break;
            case R.id.btn_search:
                turnToGoodsList();
                break;
        }
    }

    /**
     * 商品列表
     */
    private void turnToGoodsList() {
        String search = et_about_goods.getText().toString();
        Bundle bundle = new Bundle();
        bundle.putBoolean("isChannel", false);
        bundle.putString("search", search);
        Intent intent = new Intent(getActivity(), MallGoodsListActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    private void turnToMyOrder() {
        if(customer != null) {
            Intent orderIntent = new Intent(getActivity(), MallOrderActivity.class);
            startActivity(orderIntent);
        } else {
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
        }
    }

    /**
     * 前往购物车
     */
    private void turnToCart() {
        if(customer != null) {
            Bundle bundle = new Bundle();
            bundle.putSerializable("customer", customer);
            Intent intent = new Intent(getActivity(), MallCartActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
        } else {
            Intent login = new Intent(getContext(), LoginActivity.class);
            startActivity(login);
        }
    }

    /**
     * 前往收藏夹
     */
    private void turnToCollection() {
        if(customer != null) {
            Bundle bundle = new Bundle();
            bundle.putSerializable("customer", customer);
            Intent intent = new Intent(getActivity(), MallCollectionActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
        } else {
            Intent login = new Intent(getContext(), LoginActivity.class);
            startActivity(login);
        }
    }

    /**
     * 初始化视图
     */
    private void initView(View view) {

        btn_search = view.findViewById(R.id.btn_search);
        et_about_goods = view.findViewById(R.id.et_about_goods);

        channle_gridView = view.findViewById(R.id.gv_channel);
        customer = getCustomer();
        collection = view.findViewById(R.id.collection);
        cart = view.findViewById(R.id.cart);
        order = view.findViewById(R.id.order);
        collection.setOnClickListener(this);
        order.setOnClickListener(this);
        cart.setOnClickListener(this);
        btn_search.setOnClickListener(this);

        /*ll_collection = view.findViewById(R.id.ll_collection);
        ll_cart = view.findViewById(R.id.ll_cart);
        ll_order = view.findViewById(R.id.ll_order);
        ll_collection.setOnClickListener(this);
        ll_cart.setOnClickListener(this);
        ll_order.setOnClickListener(this);*/
    }
    /**
     * 获取用户
     * @return
     */
    private Customer getCustomer(){
        SharedPreferences sharedPreferences = getContext().getSharedPreferences("customer", getContext().MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);

        // Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            return null;
        }
    }

    /**
     * 初始化gridListItems
     */
    private void initGridListItems() {
        gridListItems = new ArrayList<Map<String, Object>>();
        for(int i = 0; i< channel_icons.length; i++) {
            Map<String, Object> listItem = new HashMap<String, Object>();
            listItem.put("channel_icon", channel_icons[i]);
            listItem.put("channel_name", channel_names[i]);
            gridListItems.add(listItem);
        }
    }
}
