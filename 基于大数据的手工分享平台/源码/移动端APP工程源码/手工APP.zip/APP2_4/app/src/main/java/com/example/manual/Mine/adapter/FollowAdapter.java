package com.example.manual.Mine.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import entity.Customer;

public class FollowAdapter extends BaseAdapter {

    List<Customer> data = new ArrayList<Customer>();
    private Context context;
    private ImageLoad imageLoad;

    public FollowAdapter() {
    }

    public FollowAdapter(Context context) {
        this.context = context;
        imageLoad = new ImageLoad(context);
    }


    public FollowAdapter(List<Customer> data, Context context) {
        this.data = data;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = View.inflate(context, R.layout.myself_myfollow_detail_item, null);
        }

        //获取当前对象
        Customer customer = data.get(position);

        // 获取子view
        ImageView headpic = convertView.findViewById(R.id.headpic);
        TextView name = convertView.findViewById(R.id.name);
        Button isFollow = convertView.findViewById(R.id.isFollow);

        name.setText(customer.getName());
        String imagePath = context.getResources().getString(R.string.server_projectpath)+customer.getHeadPicPath();
        // 动态加载图片
        imageLoad.loadImage(headpic,imagePath);
        //取消关注操作，重新关注操作
        isFollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        //跳转到关注人的主页
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        return convertView;
    }
}
