package com.example.manual.Mall.avtivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.CartItemEntity;
import com.example.manual.Mall.Bean.OrderEntity;
import com.example.manual.Mall.Bean.OrderItemEntity;
import com.example.manual.Mall.adapter.OrderConfirmAdapter;
import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import entity.Customer;
import tool.FormatUtil;

public class MallConfirmOrderActivity extends AppCompatActivity  implements View.OnClickListener {

    private TextView tv_consigneeName;
    private TextView tv_consigneePhone;
    private TextView tv_consigneeAddress;
    private ListView lv_confirm_order;
    private RelativeLayout rl_consigneeInfo;
    private TextView tv_total;
    private Button btn_orderConfirm;
    private EditText et_message;

    private Customer customer;
    private OrderConfirmAdapter adapter;
    private List<CartItemEntity> itemList;
    private final int UPLOAD_SUCCESS = 200;
    private final int UPLOAD_ERROR = 500;
    private double total = 0;
    private BigDecimal btotal = new BigDecimal("0");
    private String order_id;
    private OrderEntity order;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case UPLOAD_SUCCESS:
                    Bundle bundle = new Bundle();
                    bundle.putDouble("total", total);
                    bundle.putString("order_id", order_id);
                    Intent intent = new Intent(MallConfirmOrderActivity.this, MallOrderPayActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    finish();
                    break;
                case UPLOAD_ERROR:
                    Bundle bu = msg.getData();
                    Toast.makeText(MallConfirmOrderActivity.this, bu.getString("error_msg"), Toast.LENGTH_SHORT).show();
                    break;

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_confirm_order);
        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("确认订单");
        customer = getCustomer();   // 获取当前用户
        initView(); // 初始化视图，并设置值

        Bundle bundle = getIntent().getExtras();
        setView(bundle);    // 给视图赋值
    }

    /**
     * 给视图设置值
     * @param bundle
     */
    private void setView(Bundle bundle) {
        tv_consigneeName.setText(customer.getName());
        tv_consigneePhone.setText(customer.getPhonenumber());
        tv_consigneeAddress.setText(customer.getOrder_consigneeAddress());

        String cartItemListJson = bundle.getString("cartItemListJson");
        itemList = new Gson().fromJson(cartItemListJson, new TypeToken<List<CartItemEntity>>(){}.getType());
        adapter = new OrderConfirmAdapter(itemList, this);
        lv_confirm_order.setAdapter(adapter);

        double total = 0;
        btotal = new BigDecimal("0");
        for (CartItemEntity item : itemList) {
            // total += item.getCart_item_count() * item.getSpecs().getSpecs_price();
            BigDecimal bcount = new BigDecimal(item.getCart_item_count() + "");
            BigDecimal price = new BigDecimal(item.getSpecs().getSpecs_price() + "");
            BigDecimal bsubTotal = bcount.multiply(price);
            btotal = btotal.add(bsubTotal);
        }
        tv_total.setText("" + btotal);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.rl_consigneeInfo:     // 收货信息
                turnToModify(); // 前往修改页面
                break;
            case R.id.btn_orderConfirm:       // 提交订单
                confirmForServer();
                break;
        }
    }

    /**
     * 前往收货信息修改页面
     */
    private void turnToModify() {
        String consigneeName = tv_consigneeName.getText().toString();
        String consigneePhone = tv_consigneePhone.getText().toString();
        String consigneeAddress = tv_consigneeAddress.getText().toString();
        Bundle bu = new Bundle();
        bu.putString("consigneeName", consigneeName);
        bu.putString("consigneePhone", consigneePhone);
        bu.putString("consigneeAddress", consigneeAddress);
        Intent intent = new Intent(MallConfirmOrderActivity.this, MallModifyConsigneeInfoActivity.class);
        intent.putExtras(bu);
        int requestCode = 2;
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 2 && resultCode == 3) {
            Bundle bu = data.getExtras();
            tv_consigneeName.setText(bu.getString("consigneeName"));
            tv_consigneePhone.setText(bu.getString("consigneePhone"));
            tv_consigneeAddress.setText(bu.getString("consigneePhone"));
        }
    }

    /**
     * 保存到服务器
     */
    private void confirmForServer() {
        order = new OrderEntity();
        List<OrderItemEntity> list = new ArrayList<OrderItemEntity>();

        btotal = new BigDecimal("0");
        for (CartItemEntity cartItem : itemList) {
            OrderItemEntity orderItem = new OrderItemEntity();
            int count = cartItem.getCart_item_count();
            orderItem.setGoods(cartItem.getGoods());
            orderItem.setSpecs(cartItem.getSpecs());
            orderItem.setOrder_item_count(count);
            double subTotal = count*cartItem.getSpecs().getSpecs_price();
            orderItem.setItem_price(subTotal);
            /*
            将购物车条目的id传给订单条目，目的是在下单之后，购物车中的条目进行删除
             */
            orderItem.setOrder_item_id(cartItem.getCart_item_id());
            list.add(orderItem);
            total += subTotal;

            BigDecimal bcount = new BigDecimal(count + "");
            BigDecimal price = new BigDecimal(cartItem.getSpecs().getSpecs_price() + "");
            BigDecimal bsubTotal = bcount.multiply(price);
            btotal = btotal.add(bsubTotal);
        }
        total = Double.parseDouble(btotal.toString());
        // 给OrderEntity对象并赋值
        order = initAndValueOrder(order, total, list);

        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath) +
                    "confirmOrder.action";
                /*String path = "http://10.86.2.15:8080/ssm01/" + "confirmOrder.action";*/
                String json = new Gson().toJson(order);
                /*String path = "http://10.86.2.15:8080/ssm01/confirmOrder.action";*/
                SaveDataToServer.sendJsonToServer(json, path, handler);
            }
        }).start();

    }

    /**
     * 给OrderEntity对象并赋值
     * @param order
     * @param total
     * @param list
     * @return
     */
    private OrderEntity initAndValueOrder(OrderEntity order, double total, List<OrderItemEntity> list) {
        order.setOrder_consigneeAddress(tv_consigneeAddress.getText().toString());
        order.setOrder_consigneeName(tv_consigneeName.getText().toString());
        order.setOrder_consigneePhone(tv_consigneePhone.getText().toString());
        order.setOrder_message(et_message.getText().toString());

        order.setCustomer(customer);
        order.setOrder_totalPrice(total);
        order.setItemList(list);
        order_id = FormatUtil.createUUID();
        order.setOrder_id(order_id);
        order.setOrder_delete(1);
        order.setOrder_state(OrderEntity.STATE_UNPAID);
        return order;
    }


    /**
     * 初始化视图，并设置值
     */
    private void initView() {
        tv_consigneeName = findViewById(R.id.tv_consigneeName);
        tv_consigneePhone = findViewById(R.id.tv_consigneePhone);
        tv_consigneeAddress = findViewById(R.id.tv_consigneeAddress);
        lv_confirm_order = findViewById(R.id.lv_confirm_order);
        rl_consigneeInfo = findViewById(R.id.rl_consigneeInfo);
        et_message = findViewById(R.id.et_message);
        tv_total = findViewById(R.id.tv_total);
        btn_orderConfirm = findViewById(R.id.btn_orderConfirm);
        btn_orderConfirm.setOnClickListener(this);
        rl_consigneeInfo.setOnClickListener(this);
    }

    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);
        //Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return null;
        }
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
