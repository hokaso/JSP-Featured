package com.example.manual.Mine;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.Mine.activity.MyDynamicActivity;
import com.example.manual.Mine.activity.MyFanActivity;
import com.example.manual.Mine.activity.MyFollowActivity;
import com.example.manual.Mine.activity.MyInfoActivity;
import com.example.manual.R;
import com.google.gson.Gson;

import java.io.FileNotFoundException;

import entity.Customer;

import com.example.manual.Mine.GetDataThread.GetFollow_FanThread;
import tool.Save_PictureThread;

public class MyFragment extends Fragment implements View.OnClickListener {
    View view;
    Customer customer;
    ImageView headpic;
    LinearLayout ll_userinfo;
    @SuppressLint("HandlerLeak")
    Handler mhandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==111){
                Bundle data = msg.getData();
                String picpath = data.getString("picpath");
                customer.setHeadPicPath(picpath);
                //重新保存到sp中
                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("customer",Context.MODE_PRIVATE);
                //对象转为json串，方便存进sp中
                Gson gson = new Gson();
                String s = gson.toJson(customer);
                SharedPreferences.Editor edit = sharedPreferences.edit();
                edit.putString("customerJson",s);
                edit.commit();
            }
            if(msg.what==222){
                Bundle bundle = msg.getData();
                String data = bundle.getString("follow_fan");
                Log.e("str",data);
                String[] str = data.split(",");
                TextView dynamic = view.findViewById(R.id.dynamic);
                TextView follow = view.findViewById(R.id.follow);
                TextView fans = view.findViewById(R.id.location);
                dynamic.setText(str[0]);
                follow.setText(str[1]);
                fans.setText(str[2]);
            }
        }
    };
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.myself,null);
        /*未登录的话，进入登录功能*/
        TextView tv = view.findViewById(R.id.textName);
        ll_userinfo = view.findViewById(R.id.ll_userinfo);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson","");
        Gson gson = new Gson();
        customer = gson.fromJson(customerJson,Customer.class);
        //未登录，则跳到登录页面
        if(customerJson.equals("")){
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getContext(), LoginActivity.class);
                    startActivity(intent);
                }
            });

        }else{
            tv.setText(customer.getName());
            /*设置进入个人信息页面的监听器*/
            ll_userinfo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   Intent intent = new Intent();
                   intent.setClass(getActivity(), MyInfoActivity.class);
                   startActivity(intent);
                }
            });
        }
        //设置头像
        headpic = view.findViewById(R.id.headpic);
        //设置图片路径
        String headPicPath = "http://"+getResources().getString(R.string.server_tomcatip)+"/ssm01/"+customer.getHeadPicPath();
        ImageLoad imageLoad = new ImageLoad(getContext());
        imageLoad.loadImage(headpic,headPicPath);
        headpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPhoto();
            }
        });

        //获取粉丝，关注，动态数量
        String path = getString((R.string.server_projectpath))+"findFollow_Fan.action?u_id="+customer.getU_id();
        try {
            GetFollow_FanThread getFollow_fanThread = new GetFollow_FanThread(mhandler,path);
            getFollow_fanThread.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
        //查看具体的动态，关注，粉丝详细
        ImageButton dynamic_detail = view.findViewById(R.id.dynamic_detail);
        ImageButton follow_detail = view.findViewById(R.id.follow_detail);
        ImageButton fan_detail = view.findViewById(R.id.fan_detail);
        dynamic_detail.setOnClickListener(this);
        follow_detail.setOnClickListener(this);
        fan_detail.setOnClickListener(this);

        return view;
    }
    /*获取系统图库*/
    private void getPhoto(){
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                "image/*");
        startActivityForResult(intent, 111);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        System.out.println(requestCode+","+resultCode);
        if (111 == requestCode) {
            if (data != null) {
                //获取数据
                //获取内容解析者对象
                try {
                    Bitmap mBitmap = BitmapFactory.decodeStream(
                            getContext().getContentResolver().openInputStream(data.getData()));
                    headpic.setImageBitmap(mBitmap);
                    new Save_PictureThread(mhandler,mBitmap,getContext(),"customer",customer.getU_id()).start();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()){
            case R.id.dynamic_detail:
                intent = new Intent();
                intent.setClass(getContext(), MyDynamicActivity.class);
                intent.putExtra("u_id",customer.getU_id());
                startActivity(intent);
                break;
            case R.id.follow_detail:
                intent = new Intent();
                intent.setClass(getContext(),MyFollowActivity.class);
                intent.putExtra("u_id",customer.getU_id());
                startActivity(intent);
                break;
            case R.id.fan_detail:
                intent = new Intent();
                intent.setClass(getContext(), MyFanActivity.class);
                intent.putExtra("u_id",customer.getU_id());
                startActivity(intent);
                break;
            default:
                break;
        }

    }
}
