package com.example.manual.Mine.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Chat.Chat;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.Mine.GetDataThread.GetCustomerDynamic;
import com.example.manual.Mine.GetDataThread.NoResultThread;
import com.example.manual.Mine.adapter.DynamicAdapter;
import com.example.manual.R;
import com.google.gson.Gson;

import java.util.ArrayList;

import entity.Customer;
import entity.Dynamic;

public class UserHomePage extends AppCompatActivity {

    Customer customer;
    ArrayList<Dynamic> dynamicList;
    Customer thisCustomer;
    Button follow ;
    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==111){
                Bundle data = msg.getData();
                customer = (Customer) data.getSerializable("customer");
                dynamicList = (ArrayList<Dynamic>) data.getSerializable("dynamicList");
                ImageView headpic = findViewById(R.id.headpic);
                TextView name = findViewById(R.id.name);
                TextView signature = findViewById(R.id.signature);
                TextView guanzhu1 = findViewById(R.id.guanzhu);
                TextView fan = findViewById(R.id.fan);
                TextView location = findViewById(R.id.location);
                if(data.getInt("flag",0)==1){
                    follow.setText("已关注");
                }else{
                    follow.setText("关注");
                }
                ImageLoad imageLoad = new ImageLoad(getApplicationContext());
                imageLoad.loadImage(headpic,customer.getHeadPicPath());
                name.setText(customer.getName());
                signature.setText(customer.getSignature());
                guanzhu1.setText("关注 "+data.getInt("followCount"));
                fan.setText("粉丝 "+data.getInt("fanCount")+"");
                location.setText("所在地："+customer.getLocation());
                ListView listView = findViewById(R.id.dynamicList);
                DynamicAdapter dynamicAdapter = new DynamicAdapter(dynamicList,getApplicationContext());
                listView.setAdapter(dynamicAdapter);
                setListViewHeightBasedOnChildren(listView);

            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myself_user_homepage);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("");
        final String u_id = getIntent().getStringExtra("u_id");
        System.out.println("u_id:"+u_id);
        Button chat = findViewById(R.id.chat);
        follow = findViewById(R.id.follow);
        thisCustomer = new Customer();
        SharedPreferences sp = getSharedPreferences("customer",MODE_PRIVATE);
        String customerJson = sp.getString("customerJson", "");
        Gson gson = new Gson();
        thisCustomer = gson.fromJson(customerJson,Customer.class);
        chat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println(u_id);
                Intent intent = new Intent(getApplicationContext(), Chat.class);
                Bundle bundle=new Bundle();
                bundle.putCharSequence("t_id",u_id);
                intent.putExtras(bundle);
                startActivity(intent); //启动Activity
            }
        });

        follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(follow.getText().equals("关注")){
                    String sql ="insert into follow_fan values('"+thisCustomer.getU_id()+"','"+u_id+"')";
                    System.out.println(sql);
                    follow.setText("已关注");
                    Toast.makeText(getApplicationContext(),"已成功关注",Toast.LENGTH_LONG).show();
                    NoResultThread noResultThread = new NoResultThread(sql);
                    noResultThread.start();
                }else{
                    String sql ="delete from follow_fan where u_id='"+thisCustomer.getU_id()+"' and fan_id='"+u_id+"'";
                    System.out.println(sql);
                    follow.setText("关注");
                    Toast.makeText(getApplicationContext(),"已取消关注",Toast.LENGTH_LONG).show();
                    NoResultThread noResultThread = new NoResultThread(sql);
                    noResultThread.start();
                }

            }
        });

        GetCustomerDynamic getCustomerDynamic = new GetCustomerDynamic(handler,u_id,thisCustomer.getU_id());
        getCustomerDynamic.start();

    }
    public void setListViewHeightBasedOnChildren(ListView listView) {
        // 获取ListView对应的Adapter
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
            Log.e("hhhhhh",totalHeight+"");
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }
}
