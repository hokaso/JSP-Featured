package com.example.manual.Mine.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.R;
import com.google.gson.Gson;

import entity.Customer;

public class MyInfoModifyActivity extends AppCompatActivity {

    private EditText et_name;
    private EditText et_location;
    private EditText et_phone;
    private EditText et_signatrue;
    private EditText et_consigneeAddress;
    private Button btn_modify;
    private Customer customer;

    private final int UPLOAD_SUCCESS = 200;
    private final int UPLOAD_ERROR = 500;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case UPLOAD_SUCCESS:
                    Toast.makeText(MyInfoModifyActivity.this, "修改成功", Toast.LENGTH_SHORT).show();
                    saveSharedPreferences();
                    finish();
                    break;
                case UPLOAD_ERROR:
                    Toast.makeText(MyInfoModifyActivity.this, "修改失败，请重试", Toast.LENGTH_SHORT).show();
                    break;
            }
        }

        /**
         * 保存到本地
         */
        private void saveSharedPreferences() {
            SharedPreferences sp = getSharedPreferences("customer", MODE_PRIVATE);
            String customerJson = new Gson().toJson(customer);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("customerJson", customerJson);
            editor.commit();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_info_modify);

        // String coverPicPath = (String) bundle.get("goods_coverPic");
        final ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("修改信息");
        customer = getCustomer();
        initView();

        if (customer != null) {
            setView(customer);
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return;
        }

        btn_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getModifiedInfo(customer);
            }
        });
    }

    private void getModifiedInfo(Customer customer) {
        String name = et_name.getText().toString();
        String phone = et_phone.getText().toString();
        String location = et_location.getText().toString();
        String signatrue = et_signatrue.getText().toString();
        String consigneeAddress = et_consigneeAddress.getText().toString();

        Customer newInfo = new Customer();
        newInfo.setU_id(customer.getU_id());
        if (name != null && !name.trim().equals("")) {
            newInfo.setName(name);
            customer.setName(name);
        } else {
            Toast.makeText(this, "姓名不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        if (phone != null && !phone.trim().equals("")) {
            newInfo.setPhonenumber(phone);
            customer.setPhonenumber(phone);
        } else {
            Toast.makeText(this, "请填写手机号", Toast.LENGTH_SHORT).show();
            return;
        }

        if (location != null && !location.trim().equals("")) {
            newInfo.setLocation(location);
            customer.setLocation(location);
        } else {
            Toast.makeText(this, "请填写地区", Toast.LENGTH_SHORT).show();
            return;
        }

        if (signatrue != null && !signatrue.trim().equals("")) {
            newInfo.setSignature(signatrue);
            customer.setSignature(signatrue);
        } else {
            newInfo.setSignature("");
        }

        if (consigneeAddress != null && !consigneeAddress.trim().equals("")) {
            newInfo.setOrder_consigneeAddress(consigneeAddress);
            customer.setOrder_consigneeAddress(consigneeAddress);
        } else {
            Toast.makeText(this, "请填写收货地址", Toast.LENGTH_SHORT).show();
            return;
        }

        saveDataToServer(newInfo);
    }

    /**
     * 将数据保存到服务器
     * @param newInfo
     */
    private void saveDataToServer(Customer newInfo) {
        final String json = new Gson().toJson(newInfo);

        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath)
                        + "updateCustomerInfo.action";
                //String path = "http://10.86.2.15:8080/ssm01/updateCustomerInfo.action";
                SaveDataToServer.sendJsonToServer(json, path, handler);
            }
        }).start();
    }

    /**
     * 设置视图
     * @param customer
     */
    private void setView(Customer customer) {
        et_name.setText(customer.getName());
        et_phone.setText(customer.getPhonenumber());
        et_location.setText(customer.getLocation());
        et_signatrue.setText(customer.getSignature());
        et_consigneeAddress.setText(customer.getOrder_consigneeAddress());
    }

    /**
     * 初始化视图
     */
    private void initView() {
        et_name = findViewById(R.id.et_name);
        et_location = findViewById(R.id.et_location);
        et_phone = findViewById(R.id.et_phone);
        et_signatrue = findViewById(R.id.et_signatrue);
        et_consigneeAddress = findViewById(R.id.et_consigneeAddress);
        btn_modify = findViewById(R.id.btn_modify);
    }

    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);

        //Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return null;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
