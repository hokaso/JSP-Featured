package com.example.manual.Mall.avtivity;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.manual.R;

public class GoodsCommentDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods_comment_detail);
        Bundle bundle = getIntent().getExtras();

        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("商品评论");
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
