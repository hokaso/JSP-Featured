package tool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCutils {

    private static Connection conn;

    public static Connection getConnection() throws ClassNotFoundException, SQLException {
           /* ds.setDriverClass("com.mysql.jdbc.Driver");
            ds.setJdbcUrl("jdbc:mysql://47.102.155.206:3306/manual_app");
            ds.setUser("root");
            ds.setPassword("password");*/
           Class.forName("com.mysql.jdbc.Driver");
           conn = DriverManager.getConnection("jdbc:mysql://47.102.155.206:3306/manual_app?useSSL=true&characterEncoding=UTF-8",
                   "root","password");
        return conn;
    }
}
