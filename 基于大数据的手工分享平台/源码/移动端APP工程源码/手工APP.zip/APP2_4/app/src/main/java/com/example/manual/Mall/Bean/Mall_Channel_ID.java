package com.example.manual.Mall.Bean;

public class Mall_Channel_ID {

    /**编织*/
    public static int ID_WEAVE = 1;
    /**纸艺*/
    public static int ID_PAPER = 2;
    /**饰品*/
    public static int ID_ORNAMENTS = 3;
    /**皮艺*/
    public static int ID_LEATHER = 4;
    /**布艺*/
    public static int ID_FABRIC = 5;
    /**刺绣*/
    public static int ID_EMBROIDERY = 6;


    /**雕刻*/
    //public static int ID_CARVING = 7;
    /**模型*/
    //public static int ID_MODEL = 8;
    /**玉石*/
   // public static int ID_JADE = 9;
    /**印染*/
   // public static int ID_PRINT_DYEING = 10;
    /**陶瓷*/
    //public static int ID_CERAMICS = 11;
    /**其他*/
    //public static int ID_OTHER = 12;
}
