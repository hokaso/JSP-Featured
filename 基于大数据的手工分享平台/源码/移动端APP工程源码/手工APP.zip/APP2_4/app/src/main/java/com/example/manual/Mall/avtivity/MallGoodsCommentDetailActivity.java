package com.example.manual.Mall.avtivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.BrowseImage.ImagePagerActivity;
import com.example.manual.Mall.Bean.GoodsCommentEntity;
import com.example.manual.Mall.Bean.GoodsCommentImageEntity;
import com.example.manual.Mall.adapter.GoodsCommentImageAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MallGoodsCommentDetailActivity extends AppCompatActivity {

    private GridView gv_comment_image;
    private ImageView user_head;
    private TextView username;
    private TextView comment_time;
    private TextView comment_content;
    private TextView tv_specs;

    private String goods_comment_id;
    private GoodsCommentEntity commentEntity;
    private List<GoodsCommentImageEntity> comm_imgs;
    private GoodsCommentImageAdapter adapter;
    private ImageLoad imageLoad;
    private List<String> imageUrls;

    private final int LOAD_SUCCESS = 1;
    private final int LOAD_ERROR = 0;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case LOAD_ERROR:
                    Toast.makeText(MallGoodsCommentDetailActivity.this, "图片加载失败", Toast.LENGTH_SHORT).show();
                    gv_comment_image.setVisibility(View.GONE);
                    break;
                case LOAD_SUCCESS:
                    Bundle bundle = msg.getData();
                    comm_imgs = (List<GoodsCommentImageEntity>) bundle.getSerializable("comm_imgs");
                    break;
            }
            imageLoad.loadImage(user_head, commentEntity.getCustomer().getHeadPicPath());

            /*if (comm_imgs != null) {
                adapter = new GoodsCommentImageAdapter(comm_imgs, MallGoodsCommentDetailActivity.this);
                //gv_comment_image.setAdapter(adapter);
                imageUrls = new ArrayList<String>();
                for (GoodsCommentImageEntity comm : comm_imgs) {
                    String imgPath = getResources().getString(R.string.server_projectpath) + comm.getImg_path();
                    imageUrls.add(imgPath);
                }
            }*/
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods_comment_detail);
        Bundle bundle = getIntent().getExtras();
        imageLoad = new ImageLoad(MallGoodsCommentDetailActivity.this);
        commentEntity = (GoodsCommentEntity) bundle.getSerializable("commentEntity");
        goods_comment_id = commentEntity.getGoods_comment_id();

        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("商品评论");
        initAndSetView();
        //getBitmaps(goods_comment_id);
        getBitmapUrls(goods_comment_id);

        // 给item设置监听
        /*gv_comment_image.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                imageBrower(position, (ArrayList<String>) imageUrls);
            }
        });*/
    }

    /**
     * 获取点击的图片并显示
     * @param position
     * @param urls2
     */
    /*protected void imageBrower(int position, ArrayList<String> urls2) {
        Intent intent = new Intent(MallGoodsCommentDetailActivity.this, ImagePagerActivity.class);
        // 图片url,为了演示这里使用常量，一般从数据库中或网络中获取

        intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_URLS, urls2);
        intent.putExtra(ImagePagerActivity.EXTRA_IMAGE_INDEX, position);
        startActivity(intent);
    }*/

    /**
     * 获取记录图片信息的对象
     * @param goods_comment_id
     */
    private void getBitmapUrls(final String goods_comment_id) {
        // 开启线程，请求服务器，获取数据
        new Thread(){
            @Override
            public void run() {
                Message message = null;
                try {
                    List<GoodsCommentImageEntity> imgs = new ArrayList<GoodsCommentImageEntity>();
                    String path = getResources().getString(R.string.server_projectpath) +
                            "loadGoodsCommentImage.action?goods_comment_id=" + goods_comment_id;
                    //String path = "http://47.102.155.206:8080/ssm01/loadGoodsCommentImage.action?goods_comment_id=" + goods_comment_id;
                    String responseJson = GetDataFromService.resquestJson(path);
                    // 获取对象
                    imgs =  new Gson().fromJson(responseJson, new TypeToken<List<GoodsCommentImageEntity>>(){}.getType());
                    message = new Message();
                    message.what = LOAD_SUCCESS;

                    Bundle bp = new Bundle();
                    bp.putSerializable("comm_imgs", (Serializable) imgs);
                    message.setData(bp);
                    handler.sendMessage(message);
                } catch (IOException e) {
                    message.what = LOAD_ERROR;
                    handler.sendMessage(message);
                    e.printStackTrace();
                }
            }
        }.start();
    }

    /**
     * 初始化视图并赋值
     */
    private void initAndSetView() {
        // 初始化视图
        //gv_comment_image = findViewById(R.id.gv_comment_image);
        user_head = findViewById(R.id.user_head);
        username = findViewById(R.id.username);
        comment_time = findViewById(R.id.comment_time);
        comment_content = findViewById(R.id.comment_content);
        tv_specs = findViewById(R.id.tv_specs);
        // 给视图赋值
        username.setText(commentEntity.getCustomer().getName());
        comment_time.setText(commentEntity.getGoods_comment_time());
        comment_content.setText(commentEntity.getGoods_comment_content());
        tv_specs.setText(commentEntity.getSpecs().getSpecs_attrs());
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
