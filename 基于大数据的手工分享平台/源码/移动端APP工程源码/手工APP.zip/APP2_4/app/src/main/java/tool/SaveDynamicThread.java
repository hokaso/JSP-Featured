package tool;

import android.os.Handler;
import android.os.Message;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Dynamic;
import entity.Customer;

public class SaveDynamicThread extends Thread {
    private Dynamic dynamic;
    Connection connection = null;
    Customer customer = null;
    Handler handler = null;
    public SaveDynamicThread(Dynamic dynamic, Handler handler){
        this.dynamic = dynamic;
        this.handler = handler;
    }
    @Override
    public void run() {
        try {
            connection = JDBCutils.getConnection();
            String sql = "insert into dynamic values (?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, dynamic.getD_id());
            preparedStatement.setString(2, dynamic.getU_id());
            preparedStatement.setString(3, dynamic.getTitle());
            preparedStatement.setString(4, dynamic.getContent());
            preparedStatement.setString(5, dynamic.getRelease_date());
            preparedStatement.setString(6, dynamic.getCategory());
            preparedStatement.setInt(7, 0);
            preparedStatement.setInt(8, 0);
            preparedStatement.setString(9, "");
            preparedStatement.setInt(10, 0);
            preparedStatement.setInt(11, 0);
            preparedStatement.executeUpdate();
            Message message = new Message();
            message.what = 111;
            handler.sendMessage(message);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
