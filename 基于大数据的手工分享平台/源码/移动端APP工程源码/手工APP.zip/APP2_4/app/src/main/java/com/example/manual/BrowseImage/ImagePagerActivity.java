package com.example.manual.BrowseImage;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.manual.R;

import java.util.ArrayList;
import java.util.List;

public class ImagePagerActivity extends FragmentActivity {
    private static final String STATE_POSITION = "STATE_POSITION";
    public static final String EXTRA_IMAGE_INDEX = "image_index";
    public static final String EXTRA_IMAGE_URLS = "image_urls";
    private ArrayList<Fragment> fragmentArrayList;/* =new ArrayList<Fragment>();*/

    private CusViewPager mPager;
    private int pagerPosition;
    private TextView indicator;
    private List<View> imageViewList;
    ArrayList<String> urls;
    int screenWidth;
    int screenHeight;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_detail_pager);

        // 获取进入图片的序号
        pagerPosition = getIntent().getIntExtra(EXTRA_IMAGE_INDEX, 0);

        urls = getIntent().getStringArrayListExtra(EXTRA_IMAGE_URLS);

        fragmentArrayList =new ArrayList<Fragment>(urls.size());

        mPager = (CusViewPager) findViewById(R.id.pager);
        ImagePagerAdapter imagePagerAdapter = new ImagePagerAdapter(getSupportFragmentManager(),urls);
        mPager.setAdapter(imagePagerAdapter);

        indicator = (TextView) findViewById(R.id.indicator);

        // 显示图片标号和图片总数->  2/6
        //CharSequence text = getString(R.string.viewpager_indicator, pagerPosition + 1, mPager.getAdapter().getCount());
        //indicator.setText(text);
        mPager.setCurrentItem(pagerPosition);

        // 更新下标
        mPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }
            @Override
            public void onPageScrollStateChanged(int state) {
            }
            @Override
            public void onPageSelected(int position) {
                //CharSequence text = getString(R.string.viewpager_indicator, position + 1, mPager.getAdapter().getCount());
                //indicator.setText(text);
//                ((PhotoView)imageViewList.get(position).findViewById(R.id.image)).reset();// 切换还原图片大小
                //Log.e("ppp", "++++++++++*************" + position + "*********++++++++++++++");
                /*if(position < urls.size()-1) {
                    //position = urls.size()-2;

                }*/
                ImageFragment imageFragment = (ImageFragment) fragmentArrayList.get(position);
                imageFragment.getmImageView().reset();    //切换还原图片大小
            }

        });
        if (savedInstanceState != null) {
            pagerPosition = savedInstanceState.getInt(STATE_POSITION);
        }
    }

    private class ImagePagerAdapter extends FragmentStatePagerAdapter {

        private ArrayList<String> fileList;
        public ImagePagerAdapter(FragmentManager fm, ArrayList<String> fileList) {
            super(fm);
            this.fileList = fileList;
        }

        @Override
        public void startUpdate(ViewGroup container) {
            super.startUpdate(container);
        }

        @Override
        public Fragment getItem(int position) {
            String url = fileList.get(position);
            ImageFragment imageFragment = (ImageFragment) ImageFragment.newInstance(url);
            for (int i = 0; i< urls.size(); i++) {
                fragmentArrayList.add(imageFragment);
            }

            fragmentArrayList.add(imageFragment);
            return imageFragment;
        }

        @Override
        public int getCount() {
            return fileList == null ? 0 : fileList.size();
        }
    }
}
