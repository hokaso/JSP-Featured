package com.example.manual.Community;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.manual.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommunityFragment extends Fragment {

    //各个社区的介绍
    //等有了数据库，可以上数据库查
    String fabric = "布艺社区是一个非常受欢迎的社区++++++++....00";
    String leather = "皮艺社区是一个非常受欢迎的社区++++++++....00";
    String paper = "纸艺社区是一个非常受欢迎的社区++++++++....00";
    String weave = "编织社区是一个非常受欢迎的社区++++++++....00";
    String ornaments = "饰品社区是一个非常受欢迎的社区++++++++....00";
    String embroidery = "刺绣社区是一个非常受欢迎的社区++++++++....00";


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.community,null);
        //图片资源数组
        int[] imageid=new int[] {R.mipmap.fabric,R.mipmap.leather,R.mipmap.paper,
                R.mipmap.weave,R.mipmap.ornaments,R.mipmap.embroidery};

        String[] title=new String[] {"布艺", "皮艺", "纸艺",
                "编织", "饰品", "刺绣" };
        //英文title数组
        String[] egtitle=new String[] {"fabric", "leather", "paper",
                "weave", "ornaments", "embroidery" };
        
        String[] introduction= new String[]{fabric,leather ,paper,
                weave ,ornaments,embroidery
        };
        List<Map<String, Object>> listitem=new ArrayList<Map<String, Object>>();
        for(int i=0; i<imageid.length; i++) {
            Map<String, Object> map=new HashMap<String, Object>();
            map.put("image", imageid[i]);
            map.put("name", title[i]);
            map.put("egtitle",egtitle[i]);
            map.put("introduction",introduction[i]);
            listitem.add(map);
        }

        SimpleAdapter adapter=new SimpleAdapter(getActivity(), listitem, R.layout.community_main,
                new String[]{"name", "image","introduction"}, new int[]{R.id.title, R.id.image,R.id.introduction});

        ListView listView=view.findViewById(R.id.listview);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Map<String, Object> map= (Map<String, Object>) parent.getItemAtPosition(position);
                String name=map.get("name").toString();
                String egtitle = map.get("egtitle").toString();

                Bundle bundle =new Bundle();
                bundle.putString("name",name);
                bundle.putString("egtitle",egtitle);
                Intent intent = new Intent();
                intent.setClass(getActivity(),Community_all.class);
                intent.putExtra("title",bundle);
                startActivity(intent);

            }
        });
        return view;

    }
}
