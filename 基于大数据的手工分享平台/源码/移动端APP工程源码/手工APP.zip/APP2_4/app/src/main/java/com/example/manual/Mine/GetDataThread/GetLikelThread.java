package com.example.manual.Mine.GetDataThread;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.manual.Mall.netUtil.GetDataFromService;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import tool.JDBCutils;

public class GetLikelThread extends Thread {

    private Handler handler;
    private String d_id;
    private String u_id;
    Connection connection = null;
    public GetLikelThread(Handler h,String d_id,String u_id) {
        this.handler = h;
        this.d_id=d_id;
        this.u_id=u_id;
    }

    @Override
    public void run() {
        try {
            String sql = "select count(*) from liked where d_id ='"+d_id+"' and u_id='"+u_id+"'";
            Connection connection = JDBCutils.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            ResultSet resultSet = preparedStatement.executeQuery();
            resultSet.next();
            int count = Integer.parseInt(resultSet.getString(1));
            Message message = handler.obtainMessage();
            Bundle bundle = new Bundle();
            bundle.putInt("count",count);
            message.setData(bundle);
            message.what=333;
            handler.sendMessage(message);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}