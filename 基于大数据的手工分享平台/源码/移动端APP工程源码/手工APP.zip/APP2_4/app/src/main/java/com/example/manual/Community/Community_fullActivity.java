package com.example.manual.Community;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Community.Adapter.CommentAdapter;
import com.example.manual.Community.MyThread.GetCommentThread;
import com.example.manual.Mall.avtivity.MallGoodsDetailActivity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.Mine.GetDataThread.GetLikelThread;
import com.example.manual.Mine.activity.UserHomePage;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.zhuang.likeviewlibrary.LikeView;

import java.text.SimpleDateFormat;
import java.util.List;

import entity.Comment;
import entity.Customer;
import entity.CustomerComment;
import entity.Dynamic;
import tool.MysqlUtil;
import tool.SaveCommentThread;

public class Community_fullActivity extends AppCompatActivity {
    Customer customer;
    Dynamic cd;
    EditText etcomment;
    ListView commentListView;
    LikeView like;
    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {

            if(msg.what==111) {
                Bundle data = msg.getData();
                String json = data.getString("comment");
                List<CustomerComment> commentList = new Gson().fromJson(json, new TypeToken<List<CustomerComment>>() {
                }.getType());
                CommentAdapter commentAdapter = new CommentAdapter(commentList, Community_fullActivity.this);
                commentListView = findViewById(R.id.commentList);
                commentListView.setAdapter(commentAdapter);
                setListViewHeightBasedOnChildren(commentListView);
            }else if(msg.what==222){
                String path = getString(R.string.server_projectpath)+"selectCommentByD_id.action?d_id="+cd.getD_id();
                GetCommentThread getCommentThread = new GetCommentThread(handler,path);
                getCommentThread.start();
            }else if(msg.what==333){
                Bundle data = msg.getData();
                int count = data.getInt("count");

                if(count==0){
                    like.setLikeCount(cd.getTotal_like()+1);
                    String sql = "update dynamic set total_like = total_like+1 where d_id='"+cd.getD_id()+"'";
                    MysqlUtil mysqlUtil = new MysqlUtil(sql);
                    mysqlUtil.excute();
                    like.callOnClick();
                }else{

                }
            }else if(msg.what==444) {
                /**
                 * 这里小心用Log调试，如果返回为null，会报错闪退
                 */
                System.out.println("*****************In 444");
                Bundle data = msg.getData();
                cd.setGoods_id(data.getString("goods_id"));
                Context context = getApplicationContext();
                CharSequence text = null;
                int duration = Toast.LENGTH_SHORT;
                Toast toast = null;;
                if(cd.getGoods_id() == null) {
                    text = "抱歉，本动态无对应商品!";
                    toast = Toast.makeText(context, text, duration);
                    toast.show();
                } else {
                    text = "正在进入商城!";
                    toast = Toast.makeText(context, text, duration);
                    toast.show();
                    Log.i("cd.getGoods_id() ", cd.getGoods_id());
                    Bundle bundle = new Bundle();
                    bundle.putString("goods_id", cd.getGoods_id());
//                    Intent intent = new Intent(Community_fullActivity.this, MallGoodsDetailActivity.class);
                    Intent intent = new Intent();
                    intent.setClass(Community_fullActivity.this, MallGoodsDetailActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.community_full);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("");

        SharedPreferences sp = getSharedPreferences("customer",MODE_PRIVATE);
        String customerJson = sp.getString("customerJson","");
        Gson gson = new Gson();
        customer = gson.fromJson(customerJson,Customer.class);

        Bundle bundle = getIntent().getBundleExtra("data");
        String hostName =  bundle.getString("hostName");
        String hostHeadPic = bundle.getString("hostHeadPic");
        final String hostU_id = bundle.getString("u_id");
        ImageView headpic = findViewById(R.id.headpic);
        headpic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(Community_fullActivity.this, UserHomePage.class);
                intent.putExtra("u_id",hostU_id);
                startActivity(intent);
            }
        });
        ImageLoad imageLoad = new ImageLoad(this);
        imageLoad.loadImage(headpic,getString(R.string.server_projectpath)+hostHeadPic);

        cd = (Dynamic) bundle.getSerializable("dynamic");
        TextView textView1 = findViewById(R.id.title);
        TextView textView2 = findViewById(R.id.name);
        TextView textView3 = findViewById(R.id.publishtime);
        TextView textView4 = findViewById(R.id.content);
        textView1.setText(cd.getTitle());
        textView2.setText(hostName);
        textView3.setText(cd.getRelease_date());
        textView4.setText(cd.getContent());
        //首次进入，加载评论
        String path = getString(R.string.server_projectpath)+"selectCommentByD_id.action?d_id="+cd.getD_id();
        GetCommentThread getCommentThread = new GetCommentThread(handler,path);
        getCommentThread.start();


        //发表评论
        Button send = findViewById(R.id.sendcomment);
        etcomment = findViewById(R.id.etcomment);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String content = etcomment.getText().toString();
                etcomment.setText("");
                Comment comment = new Comment();
                comment.setC_id(System.currentTimeMillis()+""+Math.random()*10);
                comment.setContent(content);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm+:ss");
                String date = sdf.format(System.currentTimeMillis());
                comment.setTime(date);
                comment.setD_id(cd.getD_id());
                comment.setU_id(customer.getU_id());
                SaveCommentThread saveCommentThread = new SaveCommentThread(handler,comment);
                saveCommentThread.start();
            }
        });

        //给文章点赞
        like = findViewById(R.id.likeView);
        /**
         * 这个控件在handler中用like.setHasLike()方法就会报错;
         * 只能先设置默认为点赞状态，如果是没点赞的就调用callonclick方法
         * 取消点赞，如果动态点赞为0的，就设置为1，避免出错
         */
        if(cd.getTotal_like()==0){
            like.setLikeCount(1);
        }else {
            like.setLikeCount(cd.getTotal_like());
        }
        like.setHasLike(true);

        GetLikelThread getLikelThread = new GetLikelThread(handler,cd.getD_id(),customer.getU_id());
        getLikelThread.start();

        like.setOnLikeListeners(new LikeView.OnLikeListeners() {
            @Override
            public void like(boolean isCancel) {
                //isCancel
                //如果设置了like_canCancel为false，则isCancel可以不管，此时表示likeview被点击了
                //如果设置了like_canCancel为true,表示可以取消点赞，那么isCancel为true时，表示取消点赞，为false时，表示点赞
                if(isCancel){
                    //取消点赞
                    String sql ="delete from liked where d_id='"+cd.getD_id()+"' and u_id='"+customer.getU_id()+"'";
                    MysqlUtil mysqlUtil = new MysqlUtil(sql);
                    mysqlUtil.excute();
                    sql = "update dynamic set total_like = total_like-1 where d_id='"+cd.getD_id()+"'";
                    mysqlUtil.setSql(sql);
                    mysqlUtil.excute();
                }else{
                    //点赞
                    /*try{*/
                        String sql ="insert into liked value('"+cd.getD_id()+"','"+customer.getU_id()+"')";
                        MysqlUtil mysqlUtil = new MysqlUtil(sql);
                        mysqlUtil.excute();
                        sql = "update dynamic set total_like = total_like+1 where d_id='"+cd.getD_id()+"'";
                        mysqlUtil.setSql(sql);
                        mysqlUtil.excute();
                    /*}catch(Exception e){
                        Toast.makeText(this,"你已经点过赞了")
                    }*/
                }
            }
        });


        /**
         * 监听商城链接的Button
         */
        Button button = (Button) findViewById(R.id.shopping);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /**
                 * 调用去对应商品的子线程
                 */
                Get_goods_id gdi = new Get_goods_id(handler, cd.getD_id());
                gdi.start();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.community_topmenu,menu);

        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                Bundle bundle =new Bundle();
                String category = cd.getCategory();
                bundle.putString("egtitle",category);
                String name = "";
                if(category.equals("fabric")){
                    name = "布艺";
                }else if(category.equals("leather")){
                    name ="皮艺";
                }else if(category.equals("paper")){
                    name = "纸艺";
                }else if(category.equals("weave")){
                    name ="编织";
                }else if(category.equals("ornaments")){
                    name ="饰品";
                }else if(category.equals("embroidery")){
                    name ="刺绣";
                }
                bundle.putString("name",name);
                Intent intent = new Intent();
                intent.setClass(Community_fullActivity.this,Community_all.class);
                intent.putExtra("title",bundle);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    /**
     *  解决scrollview中嵌套listview只显示一行的问题
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        // 获取ListView对应的Adapter
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
            Log.e("hhhhhh",totalHeight+"");
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }
}
