package com.example.manual.Mall.avtivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.adapter.GoodsAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Serializable;
import java.util.List;

public class MallChannelListActivity extends AppCompatActivity {

    private List<GoodsEntity> goodsList;
    private ListView mall_goods_listview;
    private GoodsAdapter adapter;
    private final int LOAD_SUCCESS = 1;
    private final int LOAD_ERROR = 0;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case LOAD_SUCCESS:
                    adapter = new GoodsAdapter(goodsList, MallChannelListActivity.this);
                    mall_goods_listview.setAdapter(adapter);
                    mall_goods_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Bundle bundle = new Bundle();
                            // 获取商品id
                            GoodsEntity goods = goodsList.get(position);
                            /*String imgPath = getResources().getString(R.string.server_projectpath)
                                    + goods.getGoods_coverPic();*/
                            /*goods.setGoods_coverPic(imgPath);*/
                            bundle.putSerializable("goods", goods);
                            bundle.putString("goods_id", goods.getGoods_id());
                            Intent intent = new Intent(MallChannelListActivity.this, MallGoodsDetailActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }
                    });
                    break;
                case LOAD_ERROR:
                    Toast.makeText(MallChannelListActivity.this, "加载失败", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_goods_list);

        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("商品评论");

        Bundle bundle = getIntent().getExtras();
        String channel_name = bundle.getString("channel_name");
        final int category = bundle.getInt("channel_id");

        mall_goods_listview = findViewById(R.id.mall_goods_listview);
        //2. 分线程, 联网请求
        //启动分线程请求服务器动态加载数据并显示
        new Thread(){
            @Override
            public void run() {
                try {
                    String path = getResources().getString(R.string.server_projectpath) + "GoodsListServlet?category=" + category;
                    //String path = "http://10.86.2.15:8080/manual_app1/GoodsListServlet?category=" + category;
                    String responseJosn = GetDataFromService.resquestJson(path);
                    goodsList = new Gson().fromJson(responseJosn, new TypeToken<List<GoodsEntity>>(){}.getType());
                    handler.sendEmptyMessage(LOAD_SUCCESS);
                } catch (Exception e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(LOAD_ERROR);
                }
            }
        }.start();
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
