package com.example.manual.Mine.activity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.example.manual.Mine.GetDataThread.GetFanDetailThread;
import com.example.manual.Mine.adapter.FanAdapter;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

import entity.Customer;

public class MyFanActivity extends AppCompatActivity {
    Customer customer;
   /* List<Customer> listitem;
    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what==333){
                Bundle data = msg.getData();
                String detail = data.getString("fan_detail");
                Log.e("sss",detail);
                Gson gson = new Gson();
                listitem = gson.fromJson(detail, new TypeToken<List<Customer>>() {}.getType());
                if(listitem==null){
                    listitem = new ArrayList<>();
                }
                ListView myfollow = findViewById(R.id.myfollow);
                FanAdapter fanAdapter = new FanAdapter(listitem,MyFanActivity.this);
                myfollow.setAdapter(fanAdapter);
                //解决scrollview中嵌套listview只显示一行的问题
                setListViewHeightBasedOnChildren(myfollow);
            }
        }
    };*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myself_myfan_detail);


        //请求服务器获取数据
        /*String u_id = getIntent().getStringExtra("u_id");
        String path = getString((R.string.server_projectpath))+"findFanDetail.action?u_id="+u_id;
        GetFanDetailThread getFanDetailThread = new GetFanDetailThread(handler,path);
        getFanDetailThread.start();*/
        SharedPreferences sharedPreferences = getSharedPreferences("customer",MODE_PRIVATE);
        String data = sharedPreferences.getString("customerJson","");
        Gson gson = new Gson();
        customer = gson.fromJson(data,Customer.class);

        ListView myfollow = findViewById(R.id.myfollow);
        FanAdapter fanAdapter = new FanAdapter(customer.getFanList(),MyFanActivity.this);
        myfollow.setAdapter(fanAdapter);
        //解决scrollview中嵌套listview只显示一行的问题
        setListViewHeightBasedOnChildren(myfollow);
        //请求服务器的路径

    }

    /**
     *  解决scrollview中嵌套listview只显示一行的问题
     * @param listView
     */
    public void setListViewHeightBasedOnChildren(ListView listView) {
        // 获取ListView对应的Adapter
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int totalHeight = 0;
        for (int i = 0, len = listAdapter.getCount(); i < len; i++) {
            // listAdapter.getCount()返回数据项的数目
            View listItem = listAdapter.getView(i, null, listView);
            // 计算子项View 的宽高
            listItem.measure(0, 0);
            // 统计所有子项的总高度
            totalHeight += listItem.getMeasuredHeight();
            Log.e("hhhhhh",totalHeight+"");
        }

        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        // listView.getDividerHeight()获取子项间分隔符占用的高度
        // params.height最后得到整个ListView完整显示需要的高度
        listView.setLayoutParams(params);
    }
}
