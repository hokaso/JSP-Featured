package com.example.manual.Mine;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.R;

import entity.Customer;

import tool.RegisterThread;

public class RegisterActivity extends AppCompatActivity {

    @SuppressLint("HandlerLeak")
    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 111){
                Toast.makeText(getApplicationContext(),"注册成功",Toast.LENGTH_SHORT).show();

                Intent intent = new Intent();
                intent.setClass(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myself_register);

        Button button = findViewById(R.id.register);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText et1 = findViewById(R.id.username);
                EditText et2 = findViewById(R.id.password);
                String username = et1.getText().toString();
                String password = et2.getText().toString();
                /* 校验 */

                /* 封装成customer */
                Customer customer = new Customer();
                customer.setU_id(System.currentTimeMillis()+"");
                customer.setPhonenumber(username);
                customer.setPassword(password);
                new RegisterThread(customer,handler).start();

                customer.setPhonenumber(username);
                customer.setPassword(password);
            }
        });

    }
}
