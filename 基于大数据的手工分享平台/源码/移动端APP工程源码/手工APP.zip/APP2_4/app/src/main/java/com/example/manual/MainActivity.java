package com.example.manual;


import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.view.MenuItem;

import com.example.manual.Chat.Chat_List_Fragment;
import com.example.manual.Community.CommunityFragment;
import com.example.manual.Home.Home_List_Fragment;
import com.example.manual.Mall.avtivity.MallHomeFragment;
import com.example.manual.Mine.MyFragment;

public class MainActivity extends AppCompatActivity {

    Fragment f = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fragment,new Home_List_Fragment());
        ft.commit();
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction  ft = fm.beginTransaction();


            switch (item.getItemId()) {
                case R.id.navigation_home:
                    f = new Home_List_Fragment();
                    break;
                case R.id.navigation_message:
                    f = new Chat_List_Fragment();
                    break;
                case R.id.navigation_community:
                    f = new CommunityFragment();
                    break;
                case R.id.navigation_shop:
                    f = new MallHomeFragment();
                    break;
                case R.id.navigation_myself:
                    f = new MyFragment();
                    break;
                    default:
                        break;
            }
            ft.replace(R.id.fragment,f);
            ft.commit();
            return true;
        }
    };

}
