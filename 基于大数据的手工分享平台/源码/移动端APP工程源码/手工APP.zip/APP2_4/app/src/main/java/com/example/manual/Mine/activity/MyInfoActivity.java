package com.example.manual.Mine.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.manual.R;
import com.google.gson.Gson;

import entity.Customer;

public class MyInfoActivity extends AppCompatActivity implements View.OnClickListener {

    private Button ib_personalinfo;
    //private Button my_consignee_address;
    private Button modify_psw;
    //private Button modify_phone;
    private Button about_us;
    private Button btn_exit;
    private Customer customer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myself_info_settings);
        ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setTitle("设置");
        supportActionBar.setDisplayHomeAsUpEnabled(true);
        customer = getCustomer();

        initView();

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ib_personalinfo:
                Intent info = new Intent(MyInfoActivity.this, MyInfoModifyActivity.class);
                startActivity(info);
                break;
            /*case R.id.my_consignee_address:
                break;*/
            case R.id.modify_pwd:
                Intent pwd = new Intent(MyInfoActivity.this, MyModifyPwdActivity.class);
                startActivity(pwd);
                break;
            /*case R.id.modify_phone:
                break;*/
            case R.id.about_us:
                Intent aboutUs = new Intent(MyInfoActivity.this, MyAboutUstActivity.class);
                startActivity(aboutUs);
                break;
            /*case R.id.btn_exit:
                clearSharedPreferences();
                *//*Intent login = new Intent(this, LoginActivity.class);
                startActivity(login);*//*
                finish();
                break;*/
        }
    }

    private void clearSharedPreferences() {
        if (customer == null) {
            Toast.makeText(this, "您还没有登录", Toast.LENGTH_SHORT).show();
            return;
        } else {
            SharedPreferences sp = getSharedPreferences("customer", MODE_PRIVATE);
            //String customerJson = new Gson().toJson(customer);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString("customerJson", null);
            editor.commit();

            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
        }
    }

    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);

        //Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            // Toast.makeText(this, "您还没有登录", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    /**
     * 初始化视图
     */
    private void initView() {
        ib_personalinfo = findViewById(R.id.ib_personalinfo);
        //my_consignee_address = findViewById(R.id.my_consignee_address);
        modify_psw = findViewById(R.id.modify_pwd);
        //modify_phone = findViewById(R.id.modify_phone);
        about_us = findViewById(R.id.about_us);
        //btn_exit = findViewById(R.id.btn_exit);

        ib_personalinfo.setOnClickListener(this);
        //my_consignee_address.setOnClickListener(this);
        modify_psw.setOnClickListener(this);
        //modify_phone.setOnClickListener(this);
        about_us.setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            case R.id.search:

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
