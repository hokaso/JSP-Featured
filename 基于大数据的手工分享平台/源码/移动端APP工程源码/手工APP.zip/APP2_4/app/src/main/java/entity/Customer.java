package entity;

import java.io.Serializable;
import java.util.List;

public class Customer implements Serializable {

	private String u_id;

	private String name;

	private String headPicPath;

	private String phonenumber;

	private String password;

	private String address;

	private String gender;

	private String location;

	private String signature;
	private List<Dynamic> dynamicList;
	private List<Customer> followList;
	private List<Customer> fanList;
	private String order_consigneeAddress;
	private int cancellationCount;

	@Override
	public String toString() {
		return "Customer [u_id=" + u_id + ", name=" + name + ", headPicPath=" + headPicPath + ", phonenumber="
				+ phonenumber + ", password=" + password + ", address=" + address + ", gender=" + gender + ", location="
				+ location + ", signature=" + signature + ", order_consigneeAddress=" + order_consigneeAddress
				+ ", cancellationCount=" + cancellationCount + "]";
	}

	public String getOrder_consigneeAddress() {
		return order_consigneeAddress;
	}

	public void setOrder_consigneeAddress(String order_consigneeAddress) {
		this.order_consigneeAddress = order_consigneeAddress;
	}

	public int getCancellationCount() {
		return cancellationCount;
	}

	public void setCancellationCount(int cancellationCount) {
		this.cancellationCount = cancellationCount;
	}

	public List<Dynamic> getDynamicList() {
		return dynamicList;
	}

	public void setDynamicList(List<Dynamic> dynamicList) {
		this.dynamicList = dynamicList;
	}

	public List<Customer> getFollowList() {
		return followList;
	}

	public void setFollowList(List<Customer> followList) {
		this.followList = followList;
	}

	public List<Customer> getFanList() {
		return fanList;
	}

	public void setFanList(List<Customer> fanList) {
		this.fanList = fanList;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public String getHeadPicPath() {
		return headPicPath;
	}

	public void setHeadPicPath(String headPicPath) {
		this.headPicPath = headPicPath;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber == null ? null : phonenumber.trim();
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password == null ? null : password.trim();
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address == null ? null : address.trim();
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender == null ? null : gender.trim();
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location == null ? null : location.trim();
	}

	public String getSignature() {
		return signature;
	}

	public void setSignature(String signature) {
		this.signature = signature == null ? null : signature.trim();
	}
}