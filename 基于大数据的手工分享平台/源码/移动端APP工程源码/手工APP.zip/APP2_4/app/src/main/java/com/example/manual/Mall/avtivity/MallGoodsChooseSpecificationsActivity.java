package com.example.manual.Mall.avtivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.CartEntity;
import com.example.manual.Mall.Bean.CartItemEntity;
import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.Bean.GoodsSpecs;
import com.example.manual.Mall.Bean.OrderEntity;
import com.example.manual.Mall.Bean.OrderItemEntity;
import com.example.manual.Mall.adapter.SpecsAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.R;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import entity.Customer;

public class MallGoodsChooseSpecificationsActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView tv_specs;
    private GridView gv_specs;
    private Button add_to_cart;
    private Button buy_now;
    private ImageView iv_specs;
    private TextView tv_stock;
    private TextView tv_price;
    private TextView tv_specs_selected;
    private TextView tv_count;
    private ImageView btn_sub;
    private ImageView btn_add;

    private List<GoodsSpecs> goodsSpecsList;
    private String selected = "";   // 用于记录选中的规格内容
    boolean flag = false;   // 用于标志有没有选中grid中的item
    private int selectedPos = -1;   // 记录当前被选中的item的位置
    private ImageLoad imageLoad;
    private SpecsAdapter adapter;
    private String goods_id;
    private String buttonType;
    private String specs_id;
    private final int LOAD_SUCCESS = 1;
    private final int LOAD_ERROR = 0;
    private GoodsEntity goodsEntity;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case LOAD_SUCCESS:
                    if (goodsEntity != null && goodsEntity.getGoodsSpecs() != null) {
                        if (goodsEntity.getGoodsSpecs().size() > 0) {
                            setView();
                        }
                    }
                    break;
                case LOAD_ERROR:
                    Toast.makeText(MallGoodsChooseSpecificationsActivity.this, "加载失败", Toast.LENGTH_LONG).show();
                    break;
                case 200:
                    Toast.makeText(MallGoodsChooseSpecificationsActivity.this, "添加成功", Toast.LENGTH_LONG).show();
                    break;
                case 500:
                    Bundle bd = msg.getData();
                    String error_msg = bd.getString("error_msg");
                    if (error_msg.equals("over stock")) {
                        Toast.makeText(MallGoodsChooseSpecificationsActivity.this, "以超过库存数(含已在购物车的数目)", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(MallGoodsChooseSpecificationsActivity.this, "添加失败", Toast.LENGTH_LONG).show();
                    }
                    break;
            }
        }

        /**
         * 设置相关的视图
         */
        private void setView() {
            goodsSpecsList = goodsEntity.getGoodsSpecs();
            adapter = new SpecsAdapter(MallGoodsChooseSpecificationsActivity.this, goodsSpecsList);
            gv_specs.setAdapter(adapter);
            gv_specs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    GoodsSpecs specs = goodsSpecsList.get(position);
                    tv_stock.setText("库存: " + specs.getSpecs_stock());
                    tv_price.setText("￥ " + specs.getSpecs_price());
                    String imgPath = getResources().getString(R.string.server_projectpath) + specs.getSpecs_img();
                    imageLoad.loadImage(iv_specs, imgPath);
                    selectedPos = position;
                    if(specs.getSpecs_stock() > 0) {
                        selected = specs.getSpecs_attrs();
                        flag = true;
                        tv_specs_selected.setText(specs.getSpecs_attrs());
                        specs_id = specs.getSpecs_id();
                    } else {
                        selected = "";
                        //selectedPos = -1;
                        tv_count.setText("0");
                        flag = false;
                    }
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_goods_choose_specifications);

        final ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("规格选择");

        Bundle bundle = getIntent().getExtras();
        buttonType = bundle.getString("buttonType");

        initView();

        imageLoad = new ImageLoad(this);

        GoodsEntity goods = (GoodsEntity) bundle.getSerializable("goods");
        goods_id = goods.getGoods_id();
        imageLoad.loadImage(iv_specs, goods.getGoods_coverPic());
        // 获取商品信息
        getGoods(goods_id);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.buy_now :
                buyNow();
                break;
            case R.id.add_to_cart:
                addToCar();
                break;              // 添加到购物车
            case R.id.btn_add:
                goodsCountAdd();    // 添加数量
                break;
            case R.id.btn_sub:
                goodsCountSub();    // 减少数量
                break;
        }
    }

    private void buyNow() {
        int count = Integer.parseInt(tv_count.getText().toString());
        if (selected == "" && selectedPos != -1) {
            Toast.makeText(this, "请选择正确的规格", Toast.LENGTH_SHORT).show();
        } else if(selected == "" && selectedPos == -1) {
            Toast.makeText(this, "请选择规格规格", Toast.LENGTH_SHORT).show();
        } else if (count < 1) {
            Toast.makeText(this, "数量不能为0", Toast.LENGTH_SHORT).show();
        } else {
            GoodsSpecs specs = goodsSpecsList.get(selectedPos);

            List<CartItemEntity> items = new ArrayList<CartItemEntity>();
            CartItemEntity cartItem = new CartItemEntity();
            cartItem.setSpecs(specs);
            cartItem.setGoods(goodsEntity);
            count = Integer.parseInt(tv_count.getText().toString());
            cartItem.setCart_item_count(count);
            items.add(cartItem);

            Bundle bOrder = new Bundle();
            String cartItemListJson = new Gson().toJson(items);
            bOrder.putString("cartItemListJson", cartItemListJson);
            Intent intent = new Intent(this, MallConfirmOrderActivity.class);
            intent.putExtras(bOrder);
            startActivity(intent);
        }
    }

    /**
     * 商品添加到购物车
     */
    private void addToCar() {
        int count = Integer.parseInt(tv_count.getText().toString());// 获取数量显示文本框的数值
        if (flag == false) {
            Toast.makeText(this, "请选择正确的规格", Toast.LENGTH_LONG).show();
        } else {
            GoodsSpecs specs = goodsSpecsList.get(selectedPos); // 获取当前被选中的规格
            if (count < 1) {
                Toast.makeText(this, "数量不能为0", Toast.LENGTH_LONG).show();
            } else if(count > specs.getSpecs_stock()) {
                Toast.makeText(this, "数量超出库存", Toast.LENGTH_LONG).show();
            } else {
                createCart(count, specs);
            }
        }
    }


    /**
     * 创建购物车
     * @param count
     * @param specs
     */
    private void createCart(int count, GoodsSpecs specs) {
        CartItemEntity item = new CartItemEntity();
        CartEntity cart = new CartEntity();
        item.setGoods(goodsEntity);   // 保存商品
        item.setSpecs(specs);         // 保存商品的规格
        item.setCart_item_count(count);   // 保存条目数量
        cart.setCartItem(item);
        Customer customer = getCustomer();
        cart.setCustomer(customer);
        cart.setGoods(goodsEntity);

        final String json = new Gson().toJson(cart);
        final String path = getResources().getString(R.string.server_projectpath) + "cartAdd.action";

        new Thread(new Runnable() {
            @Override
            public void run() {
                SaveDataToServer.sendJsonToServer(json, path, handler);
            }
        }){}.start();
    }

    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);
        //Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return null;
        }
    }

    /**
     * 减少数量
     */
    private void goodsCountSub() {
        if(selectedPos != -1) {
            GoodsSpecs specs = goodsSpecsList.get(selectedPos); // 获取当前被选中的规格
            int stock = specs.getSpecs_stock(); // 获取该规格库存数
            if (stock == 0) {   // 如果该规格库存数为0，不能添加，并且把数量显示置0，并提示操作失败
                tv_count.setText("0");
                Toast.makeText(this, "该规格库存为0", Toast.LENGTH_LONG).show();
            } else {
                int count = Integer.parseInt(tv_count.getText().toString());// 获取数量显示文本框的数值
                if (count <= 1) {
                    return;
                } else {
                    count -= 1;
                    tv_count.setText(count + "");
                }
            }
        }
    }

    /**
     * 往购物车中添加数量
     */
    private void goodsCountAdd() {
        if(selectedPos != -1){
            GoodsSpecs specs = goodsSpecsList.get(selectedPos); // 获取当前被选中的规格
            int stock = specs.getSpecs_stock(); // 获取该规格库存数
            if (stock == 0) {   // 如果该规格库存数为0，不能添加，并且把数量显示置0，并提示操作失败
                tv_count.setText(0+"");
                Toast.makeText(this, "添加失败,该规格库存为0", Toast.LENGTH_LONG).show();
            } else {
                int count = Integer.parseInt(tv_count.getText().toString());// 获取数量显示文本框的数值
                if (stock < count + 1) {    // 限制最大数量为库存数
                    tv_count.setText(stock + "");
                    Toast.makeText(this, "添加失败,当前达到库存最大数量", Toast.LENGTH_LONG).show();
                } else {
                    count += 1;
                    tv_count.setText(count + "");
                }
            }
        }
    }

    /**
     * 获取商品信息
     * @param goods_id
     */
    private void getGoods(final String goods_id) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath) +
                        "getGodosSpecs.action?goods_id=" + goods_id;
                //String path = "http://10.86.2.15:8080/ssm01/getGodosSpecs.action?goods_id=" + goods_id;
                try {
                    String responseJosn = GetDataFromService.resquestJson(path);
                    //GoodsEntity goods = new Gson().fromJson(responseJosn, GoodsEntity.class);
                    //Log.e("json----", responseJosn);
                    goodsEntity = new Gson().fromJson(responseJosn, GoodsEntity.class);

                    handler.sendEmptyMessage(LOAD_SUCCESS);
                } catch (IOException e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(LOAD_ERROR);
                }
            }
        }).start();
    }

    /**
     * 初始化组件
     */
    private void initView() {
        iv_specs = findViewById(R.id.iv_specs);
        tv_specs = findViewById(R.id.tv_specs);
        gv_specs = findViewById(R.id.gv_specs);

        tv_stock = findViewById(R.id.tv_stock);
        tv_price = findViewById(R.id.tv_price);
        tv_specs_selected = findViewById(R.id.tv_specs_selected);
        btn_sub = findViewById(R.id.btn_sub);
        tv_count = findViewById(R.id.tv_count);
        btn_add = findViewById(R.id.btn_add);
        buy_now = findViewById(R.id.buy_now);
        add_to_cart = findViewById(R.id.add_to_cart);

        if (buttonType.equals("detail_add2cart")) {
            buy_now.setVisibility(View.GONE);
            add_to_cart.setOnClickListener(this);
        } else if(buttonType.equals("detail_buy")) {
            add_to_cart.setVisibility(View.GONE);
            buy_now.setOnClickListener(this);
        } else {
            buy_now.setOnClickListener(this);
            add_to_cart.setOnClickListener(this);
        }

        btn_sub.setOnClickListener(this);
        tv_count.setOnClickListener(this);
        btn_add.setOnClickListener(this);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
