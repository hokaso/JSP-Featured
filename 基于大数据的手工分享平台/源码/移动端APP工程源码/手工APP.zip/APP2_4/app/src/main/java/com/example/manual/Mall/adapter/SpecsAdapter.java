package com.example.manual.Mall.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.manual.Mall.Bean.GoodsSpecs;
import com.example.manual.R;

import java.util.List;

public class SpecsAdapter extends BaseAdapter {

    private Context context;
    private List<GoodsSpecs> list;
    public SpecsAdapter() {

    }

    public SpecsAdapter(Context context, List<GoodsSpecs> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.goods_item_specs, null);
        }
        TextView tv = convertView.findViewById(R.id.tv_specs_item);

        GoodsSpecs specs = list.get(position);
        tv.setText(specs.getSpecs_attrs());

        if (specs.getSpecs_stock() == 0) {
            convertView.setClickable(false);
            //convertView.setBackgroundResource(R.color.tv_specs_unclick);
            tv.setTextColor(R.color.tv_specs_unclick);
        }

        return convertView;
    }
}
