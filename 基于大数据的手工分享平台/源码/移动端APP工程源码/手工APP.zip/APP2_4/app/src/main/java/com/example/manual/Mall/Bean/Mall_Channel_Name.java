package com.example.manual.Mall.Bean;

public class Mall_Channel_Name {

    /**编织*/
    public static String NAME_WEAVE = "编织";
    /**纸艺*/
    public static String NAME_PAPER = "纸艺";
    /**饰品*/
    public static String NAME_ORNAMENTS = "饰品";
    /**皮艺*/
    public static String NAME_LEATHER = "皮艺";
    /**布艺*/
    public static String NAME_FABRIC = "布艺";
    /**刺绣*/
    public static String NAME_EMBROIDERY = "刺绣";


    /**木艺*/
//    public static String NAME_WOODEN = "木艺";
    /**雕刻*/
//    public static String NAME_CARVING = "雕刻";
    /**模型*/
//    public static String NAME_MODEL = "模型";
    /**玉石*/
//    public static String NAME_JADE = "玉石";
    /**印染*/
//    public static String NAME_PRINT_DYEING = "印染";
    /**陶瓷*/
//    public static String NAME_CERAMICS = "陶瓷";
    /**其他*/
//    public static String NAME_OTHER = "其他";
}
