package tool;




import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Customer;

public class RegisterThread extends Thread {

    Customer customer;
    Handler handler;

    public RegisterThread(Customer customer,Handler handler){
        this.customer = customer;
        this.handler = handler;
    }

    @Override
    public void run() {

        try {
            Connection connection = JDBCutils.getConnection();
            String sql = "insert into customer(u_id,phonenumber,password) values (?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,customer.getU_id());
            preparedStatement.setString(2,customer.getPhonenumber());
            preparedStatement.setString(3,customer.getPassword());
            preparedStatement.executeUpdate();
            String sql1 ="insert into favorite(u_id) values('"+customer.getU_id()+"')";
            Log.i("sql1111",sql1);
            MysqlUtil mysqlUtil = new MysqlUtil(sql1);
            mysqlUtil.excute();
            Message message = new Message();
            message.what = 111;
            handler.sendMessage(message);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
}
