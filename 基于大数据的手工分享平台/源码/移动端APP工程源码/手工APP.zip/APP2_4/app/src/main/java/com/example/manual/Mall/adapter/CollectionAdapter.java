package com.example.manual.Mall.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.manual.Mall.Bean.CartItemEntity;
import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.Bean.MallCollection;
import com.example.manual.Mall.avtivity.MallGoodsDetailActivity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CollectionAdapter  extends BaseAdapter {

    private List<MallCollection> collectionList;
    private Context context;
    private ImageLoad imageLoad;
    private Map<Integer,Boolean> checkBoxMap=new HashMap<>();
    private int trueCount = 0;
    private SparseBooleanArray isSelected;
    private Handler handler;

    public CollectionAdapter(List<MallCollection> collectionList, Context context) {
        this.collectionList = collectionList;
        this.context = context;
        imageLoad = new ImageLoad(context);
        isSelected = new SparseBooleanArray();
        initSparseBooleanArray();
    }

    public CollectionAdapter(List<MallCollection> itemList, Context context, Handler handler) {
        this.collectionList = itemList;
        this.context = context;
        this.handler = handler;
        imageLoad = new ImageLoad(context);
        isSelected = new SparseBooleanArray();
        initSparseBooleanArray();
    }

    /**
     * 初始化数据
     */
    private void initSparseBooleanArray() {
        for (int i = 0; i < collectionList.size(); i++) {
            getIsSelected().put(i, false);
        }
    }

    @Override
    public int getCount() {
        return collectionList.size();
    }

    @Override
    public Object getItem(int position) {
        return collectionList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_collection, null);
        }

        CheckBox checkbox = convertView.findViewById(R.id.checkbox);
        ImageView iv_goodsPic = convertView.findViewById(R.id.iv_goodsPic);
        TextView tv_goods_name = convertView.findViewById(R.id.tv_goods_name);
        TextView tv_goods_describe = convertView.findViewById(R.id.tv_goods_describe);
        TextView tv_tips_state = convertView.findViewById(R.id.tv_tips_state);
        TextView tv_goods_price = convertView.findViewById(R.id.tv_goods_price);

        MallCollection collection = collectionList.get(position);
        GoodsEntity goods = collection.getGoods();
        tv_goods_name.setText(goods.getGoods_name());
        tv_goods_describe.setText(goods.getGoods_describe());
        if (goods.getGoods_state() == 1) {
            tv_tips_state.setVisibility(View.GONE);
        } else {
            tv_tips_state.setVisibility(View.VISIBLE);
        }

        String imgPath = context.getResources().getString(R.string.server_projectpath)
                + goods.getGoods_coverPic();
        imageLoad.loadImage(iv_goodsPic, imgPath);
        checkbox.setChecked(isSelected.get(position));
        tv_goods_price.setText("￥" + goods.getGoods_price());

        LinearLayout ll_name = convertView.findViewById(R.id.ll_name);
        ll_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                turnToGoodDetail(position);
            }
        });
        iv_goodsPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                turnToGoodDetail(position);
            }
        });

        // 设置checkbox视图监听事件以及给checkBoxMap赋值
        setCheckbox(checkbox, position);

        return convertView;
    }

    /**
     * 跳转至商品详细页面
     * @param position
     */
    private void turnToGoodDetail(int position) {
        GoodsEntity goods = collectionList.get(position).getGoods();
        Bundle gb = new Bundle();
        gb.putSerializable("goods", (Serializable) goods);
        gb.putString("goods_id", goods.getGoods_id());
        /*gb.putString("goods_id", goods.getGoods_id());
        gb.putDouble("goods_price", goods.getGoods_price());

        String imgPath = context.getResources().getString(R.string.server_projectpath)
                + goods.getGoods_coverPic();
        //String imgPath = goods.getGoods_coverPic();
        gb.putString("goods_coverPic", imgPath);

        gb.putString("goods_name", goods.getGoods_name());
        gb.putString("goods_describe", goods.getGoods_describe());*/
        Intent intent = new Intent(context, MallGoodsDetailActivity.class);
        intent.putExtras(gb);
        context.startActivity(intent);
    }

    /**
     * 设置checkbox视图监听事件以及给checkBoxMap赋值
     * @param checkbox
     * @param position
     */
    private void setCheckbox(final CheckBox checkbox, final int position) {
        checkbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkbox.isChecked()){
                    checkBoxMap.put(position,true);
                    trueCount ++;
                }else {
                    checkBoxMap.remove(position);
                    if(trueCount > 0) {
                        trueCount --;
                    }
                }
                calCheckedItem();
            }
        });

        if(checkBoxMap!=null&&checkBoxMap.containsKey(position)){
            checkbox.setChecked(true);
        }else {
            checkbox.setChecked(false);
        }
    }

    /**
     * 计算已选中的item
     */
    private void calCheckedItem() {
        //Toast.makeText(context, money+"", Toast.LENGTH_SHORT).show();
        boolean allSelected = false;
        if (trueCount == collectionList.size()) {
            allSelected = true;
        }
        Bundle bundle = new Bundle();
        bundle.putBoolean("allSelected", allSelected);
        Message message = new Message();
        message.setData(bundle);
        message.what = 1;
        handler.sendMessage(message);
    }

    /**
     * 删除已选中的item
     * @param items
     * @param nos
     */
    public void deleteArray(List<MallCollection> items, List<Integer> nos) {
        //Log.e("flag-----", "2112121221");
        collectionList.removeAll(items);
        for (Integer i : nos) {
            checkBoxMap.remove(i);
            isSelected.delete(i);
        }
        this.notifyDataSetChanged();
    }

    ////////////////////////////////////////////////////
    public List<MallCollection> getCollectionList() {
        return collectionList;
    }

    public void setCollectionList(List<MallCollection> collectionList) {
        this.collectionList = collectionList;
    }

    public Map<Integer, Boolean> getCheckBoxMap() {
        return checkBoxMap;
    }

    public void setCheckBoxMap(Map<Integer, Boolean> checkBoxMap) {
        this.checkBoxMap = checkBoxMap;
    }

    public SparseBooleanArray getIsSelected() {
        return isSelected;
    }

    public void setIsSelected(SparseBooleanArray isSelected) {
        this.isSelected = isSelected;
    }
}
