package com.example.manual.Chat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.manual.R;
import com.google.gson.Gson;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import entity.Customer;

public class Chat_List_Fragment extends Fragment {

    private String u_id;//自己的ID

    //通过Get_Friend更新聊天列表
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            ListView listView = null;
            switch (msg.what){
                case 0x002:
                    if(getActivity() == null) break;
                    else {
                        listView = getActivity().findViewById(R.id.Chat_list_listview);
                        Bundle bundle = msg.getData();
                        List<ConcurrentHashMap<String, Object>> listitem =
                                (List<ConcurrentHashMap<String, Object>>) bundle.getSerializable("listitem");
                        /*加载头像的adapter版本*/
                        SimpleAdapter listAdapter = new SimpleAdapter(getActivity(), listitem, R.layout.chat_list_fragment_item,
                                new String[]{"icon", "name", "t_id"},
                                new int[]{R.id.chat_list_item_imageview,  R.id.chat_list_item_textview,  R.id.chat_list_item_textview2});
                        /*不加载头像的adapter版本*/
//                        SimpleAdapter listAdapter = new SimpleAdapter(getActivity(), listitem, R.layout.chat_list_fragment_item,
//                                new String[]{"t_id"},
//                                new int[]{R.id.chat_list_item_textview});

//                        /*实现ViewBinder()这个接口*/
//                        listAdapter.setViewBinder(new SimpleAdapter.ViewBinder() {
//                            @Override
//                            public boolean setViewValue(View view, Object data,
//                                                        String textRepresentation) {
//                                // TODO Auto-generated method stub
//                                if(view instanceof ImageView && data instanceof Bitmap){
//                                    ImageView i = (ImageView)view;
//                                    i.setImageBitmap((Bitmap) data);
//                                    return true;
//                                }
//                                return false;
//                            }
//                        });
                        listView.setAdapter(listAdapter);
//                        /*动态更新ListView   无用*/
//                        listAdapter.notifyDataSetChanged();
                    }
                    break;
                default:
                    break;
            }

        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //获取自己的ID
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson","");
        Gson gson = new Gson();
        Customer customer = gson.fromJson(customerJson, Customer.class);
        u_id = customer.getU_id(); //赋值自己的ID
        
        
        //启动一个子线程，刷新一次聊天列表
        Get_Friend gf = new Get_Friend(handler, u_id);
        gf.start();


        View view = inflater.inflate(R.layout.chat_list_fragment,null);
        ListView listView=view.findViewById(R.id.Chat_list_listview);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Map<String, Object> map= (Map<String, Object>) parent.getItemAtPosition(position);
                String t_id=map.get("t_id").toString();
                Intent intent = new Intent(getContext(), Chat.class);
                Bundle bundle=new Bundle();
                bundle.putCharSequence("t_id",t_id);
                intent.putExtras(bundle);
                startActivity(intent); //启动Activity
            }
        });
        return view;
    }
}