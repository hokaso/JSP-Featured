package com.example.manual.Chat;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.manual.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import tool.JDBCutils;

public class Get_Friend extends Thread{

    private Handler handler;
    private String u_id;
    private String t_id;
    private String server_IP = "http://47.102.155.206:8080/ssm01";

    //h负责传输数据
    //在数据库中搜索涉及u（u_id)的聊天记录
    public Get_Friend(Handler h, String u) {
        this.handler = h;
        this.u_id = u;
    }

    @Override
    public void run() {
        System.out.println("******************Here is Get_Friend *************************");
        Statement stmt=null;
        Connection conn=null;
        try {
            //1.注册驱动程序，2.获取连接对象
            conn = JDBCutils.getConnection();
            //3.创建Statement
            stmt = conn.createStatement();
            //4.准备sql
            String sql = "select * from message where u_id = '"+u_id+"' or t_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            ResultSet rs = stmt.executeQuery(sql);


            ArrayList<ConcurrentHashMap<String, Object>> listitem = new ArrayList<>();

            Set hashSet = new HashSet<HashMap<String,String>>();
            //获取各种动态类型的数据
            while(rs.next()) {
                hashSet.add(rs.getString("u_id"));
                hashSet.add(rs.getString("t_id"));
            }
            hashSet.remove(u_id); //消除搜索到的自己的ID
            for(Object value: hashSet) {
                ConcurrentHashMap<String, Object> CHmap = new ConcurrentHashMap<>();

                sql = "select name from customer where u_id = '"+value+"';";
                rs = stmt.executeQuery(sql);
                String name = null;
                while(rs.next()) {
                    name = rs.getString("name");
                }

                /**
                 * local image
                 */
                CHmap.put("icon", R.mipmap.image01);
                /**
                 * web image. for the server speed is too slow,
                 * we stopped to get image from internet
                 */
//                String sql001 = "SELECT headPicPath FROM customer WHERE u_id = "+value;
//                System.out.println(sql001);
//                ResultSet rs001 = stmt.executeQuery(sql001);
//                String headPicPath = null;
//                while (rs001.next()) {
//                    headPicPath = rs001.getString("headPicPath");
//                }
////                System.out.println("**********************value = "+ value + " headPicPath = "+headPicPath);
//                headPicPath = server_IP+"/"+headPicPath;
////                System.out.println("**********************headPicPath = "+headPicPath);
//                System.out.println("**********************returnBitmap(headPicPath) = "+returnBitmap(headPicPath));
////                CHmap.put("icon", returnBitmap(headPicPath).compress(Bitmap.CompressFormat.JPEG, 80, new ByteArrayOutputStream()));
                CHmap.put("name", name);
                CHmap.put("t_id", value);
                listitem.add(CHmap);
            }
            Bundle bundle = new Bundle();
            Message message = new Message();
            bundle.putSerializable("listitem", listitem);
            message.what=0x002;
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    //    Android 根据网络图片URL转Bitmap对象
    private Bitmap returnBitmap(String url){
        URL fileUrl=null;
        Bitmap bitmap=null;
        try{
            fileUrl=new URL(url);
        }catch(MalformedURLException e){
            e.printStackTrace();
        }
        try{
            HttpURLConnection conn=(HttpURLConnection)fileUrl
                    .openConnection();
            conn.setDoInput(true);
            conn.connect();
            InputStream is=conn.getInputStream();
            bitmap= BitmapFactory.decodeStream(is);
            is.close();
        }catch(IOException e){
            e.printStackTrace();
        }
        return bitmap;
    }

}
