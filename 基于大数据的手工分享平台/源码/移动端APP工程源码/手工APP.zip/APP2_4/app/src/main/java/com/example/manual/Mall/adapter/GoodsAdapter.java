package com.example.manual.Mall.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.util.List;

public class GoodsAdapter extends BaseAdapter {

    private List<GoodsEntity> data;
    private Context context;
    private ImageLoad imageLoad;

    public GoodsAdapter() {
    }

    public GoodsAdapter(Context context) {
        this.context = context;
        imageLoad = new ImageLoad(context);
    }


    public GoodsAdapter(List<GoodsEntity> data, Context context) {
        this.data = data;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    public List<GoodsEntity> getData() {
        return data;
    }
    public void setData(List<GoodsEntity> data) {
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_goods_list, null);
        }

        //获取当前对象
        GoodsEntity goods = data.get(position);

        // 获取子view
        ImageView goodsCover = convertView.findViewById(R.id.mall_goods_pic);
        TextView name = convertView.findViewById(R.id.mall_goods_name);
        TextView price = convertView.findViewById(R.id.mall_goods_price);
        //TextView sales_volume = convertView.findViewById(R.id.mall_goods_sales_volume);

        name.setText(goods.getGoods_name());
        price.setText(goods.getGoods_price());
        //sales_volume.setText(goods.getGoods_sales_volume());
        String imagePath = context.getResources().getString(R.string.server_projectpath) + goods.getGoods_coverPic();

        // 动态加载图片
        imageLoad.loadImage(goodsCover, imagePath);

        return convertView;
    }
}
