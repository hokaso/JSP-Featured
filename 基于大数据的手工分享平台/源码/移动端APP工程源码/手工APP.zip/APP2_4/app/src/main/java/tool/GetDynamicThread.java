package tool;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class GetDynamicThread extends Thread {

    private Handler handler ;
    private String type;
    private String title = null;
    private String category;


    Connection connection = null;
    /* 传入两个参数，第一个是用于通信的handler，第二个是动态类型 */
    public GetDynamicThread(Handler h, String type, String category){
        this.handler = h ;
        this.type = type;
        this.category = category;
    }
    @Override
    public void run() {
        String sql ="";
        if(type.equals("lastestpub")){
            sql = "SELECT * FROM DYNAMIC LEFT JOIN customer ON  dynamic.`u_id` = customer.`u_id` \n" +
                    "LEFT JOIN liked ON liked.`d_id`=dynamic.`d_id` WHERE category = '"+category+"'\n" +
                    "ORDER BY dynamic.`release_date` DESC";
            if(title!=null){
                sql += "and title like '%"+title+"%'";
            }
        }
        if(type.equals("lastestresp")){
            sql = "SELECT * FROM DYNAMIC LEFT JOIN customer ON  dynamic.`u_id` = customer.`u_id` \n" +
                    "LEFT JOIN COMMENT ON `comment`.`d_id`=dynamic.`d_id` WHERE category = '"+category+"'\n" +
                    "ORDER BY dynamic.`release_date` DESC";

            if(title!=null){
                sql += "and title like '%"+title+"%'";
            }
        }
        if(type.equals("host")){
            sql = " select dynamic.*,customer.* from dynamic,customer where" +
                    " dynamic.`type` = '" + type + "' and dynamic.`u_id`= customer.`u_id` " +
                    "and category = '"+category+"' ";
            if(title!=null){
                sql += "and title like '%"+title+"%'";
            }
        }
/*
        String sql = " select dynamic.*,customer.* from dynamic,customer where" +
                " dynamic.`type` = '" + type + "' and dynamic.`u_id`= customer.`u_id` " +
                "and category = '"+category+"' ";
        if(title!=null){
            sql += "and title like '%"+title+"%'";
        }*/
        Log.i("sql",sql);
        try {
            ArrayList<Map<String,Object>> listitem = getData(sql);
            Bundle bundle = new Bundle();
            Message message=new Message();
            bundle.putSerializable("listitem",listitem);
            if(type.equals("lastestresp")){
                message.what = 0;
            }else if(type.equals("lastestpub")){
                message.what = 1;
            }else if(type.equals("host")){
                message.what = 2;
            }
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public ArrayList<Map<String, Object>> getData(String sql) throws SQLException, ClassNotFoundException {
        connection = JDBCutils.getConnection();
        Statement statment = connection.createStatement();
        ResultSet rs = statment.executeQuery(sql);
        int i = 0;
        String[] username = new String[128];
        String[] title = new String[128];
        String[] count = new String[128];
        String[] time = new String[128];
        String[] content = new String[128];
        String[] d_id = new String[128];
        String[] u_id = new String[128];
        ArrayList<Map<String, Object>> listitem = new ArrayList<Map<String, Object>>();
        //获取各种类型的动态数据
        String check = "";
        while (rs.next()) {
            username[i] = rs.getString("name");
            title[i] = rs.getString("title");
            time[i] = rs.getString("release_date");
            content[i] = rs.getString("content");
            d_id[i] = rs.getString("d_id");
            u_id[i] = rs.getString("u_id");
            Log.i("c",content[i]);
            sql = "select count(*) from comment where d_id = '"+rs.getString("d_id")+"'";
            Statement statment2 = connection.createStatement();
            ResultSet resultSet = statment2.executeQuery(sql);
            resultSet.next();
            //获取评论数
            int comment = Integer.parseInt(resultSet.getString(1));
            //获取点赞数
            sql = "select count(*) from liked where d_id = '"+rs.getString("d_id")+"'";
            Statement statment3 = connection.createStatement();
            ResultSet resultSet2 = statment3.executeQuery(sql);
            resultSet2.next();
            int like = Integer.parseInt(resultSet2.getString(1));
            count[i] = "评论："+comment+" 点赞："+like+"";
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("username", username[i]);
            map.put("title", title[i]);
            map.put("count", count[i]);
            map.put("release_date" , time[i]);
            map.put("content",content[i]);
            map.put("d_id",d_id[i]);
            map.put("u_id", u_id[i]);
            i++;
            //没条动态只添加一次
            Log.i("id",check);
            if(!check.contains(d_id[i-1])){
                check +=d_id[i-1]+",";
                listitem.add(map);
            }
        }

        return listitem;
    }

 /*---------------------------------------------------*/

    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
