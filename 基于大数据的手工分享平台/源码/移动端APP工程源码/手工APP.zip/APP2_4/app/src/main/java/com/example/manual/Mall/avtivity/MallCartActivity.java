package com.example.manual.Mall.avtivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.CartEntity;
import com.example.manual.Mall.Bean.CartItemEntity;
import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.adapter.CartAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.R;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entity.Customer;

public class MallCartActivity extends AppCompatActivity implements View.OnClickListener {

    private ListView lv_cart;
    private TextView tv_empty_tips;
    private TextView tv_total;
    private CheckBox cb_allSelected;
    private Button btn_settlement;
    private Button btn_delete;

    private List<CartItemEntity> itemList;
    private Customer customer;
    private CartAdapter adapter;
    private CartEntity cart;
    private final int FOUND_CART = 111;
    private final int EMPTY_CART = 101;
    private final int ERROR = 505;
    private final int UPLOAD_SUCCESS = 200;
    private final int UPLOAD_ERROR = 500;
    private Map<Integer,Boolean> checkBoxMap = new HashMap<>();

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case FOUND_CART:
                    Bundle bundle = msg.getData();
                    cart = (CartEntity) bundle.getSerializable("cart");
                    itemList = cart.getCartItemList();
                    if (itemList.size() > 0) {
                        setView(itemList);
                    } else {
                        setTv_empty_tips("购物车为空");
                    }
                    break;
                case EMPTY_CART:
                    setTv_empty_tips("购物车为空");
                    break;
                case ERROR:
                    setTv_empty_tips("加载失败");
                    break;
                case UPLOAD_SUCCESS:
                    Toast.makeText(MallCartActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                    break;
            }
        }

        private void setView(final List<CartItemEntity> itemList) {
            Handler hd = new Handler(){
                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                        case 1:
                            Bundle bd = msg.getData();
                            boolean allSelected = bd.getBoolean("allSelected");
                            double total = bd.getDouble("total");
                            tv_total.setText(total+"");
                            if (allSelected == true) {
                                cb_allSelected.setChecked(true);
                            } else {
                                cb_allSelected.setChecked(false);
                            }
                            break;
                        case 10086:
                            double tt = 0;
                            Map<Integer,Boolean> map = new HashMap<>();
                            map = adapter.getCheckBoxMap();
                            for (Integer i : map.keySet()) {
                                if (map.get(i)) {
                                    tt += itemList.get(i).getCart_item_count()*itemList.get(i).getSpecs().getSpecs_price();
                                }
                            }
                            tv_total.setText(tt + "");
                            break;
                    }
                }
            };
            adapter = new CartAdapter(itemList, MallCartActivity.this, hd);
            tv_total.setText("0");
            lv_cart.setAdapter(adapter);
        }

        /**
         * 设置加载tv_empty_tips（提示视图）
         * @param tips
         */
        private void setTv_empty_tips(String tips) {
            lv_cart.setVisibility(View.GONE);
            tv_empty_tips = findViewById(R.id.empty_tips);
            tv_empty_tips.setVisibility(View.VISIBLE);
            tv_empty_tips.setText(tips);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_cart);
        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("购物车");
        // 获取当前使用的用户
        Bundle bundle = getIntent().getExtras();
        customer = (Customer) bundle.getSerializable("customer");
        // 从数据库中获取数据
        getCartFromSever();
        // 初始化视图
        initView();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cb_allSelected:// 全选
                setCb_allSelected();
                break;
            case R.id.btn_settlement:// 结算
                setBtn_settlement();
                break;
            case R.id.btn_delete:// 删除
                setBtn_delete();
                break;
        }
    }

    /**
     * 设置“结算视图”
     */
    private void setBtn_settlement() {
        Map<Integer,Boolean> map = new HashMap<>();
        map = adapter.getCheckBoxMap();
        List<CartItemEntity> list = new ArrayList<CartItemEntity>();
        List<Integer> noList = new ArrayList<Integer>();
        int count = 0;
        for (Integer i : map.keySet()) {
            if (map.get(i)) {
                GoodsEntity goods = itemList.get(i).getGoods();
                if (goods.getGoods_state() == 0) {  // 判断是否已经下架
                    Toast.makeText(MallCartActivity.this, goods.getGoods_name() +
                            "已下架", Toast.LENGTH_SHORT).show();
                    return;
                }
                list.add(itemList.get(i));
                noList.add(i);
                count++;
            }
        }
        if (count < 1) {
            Toast.makeText(this, "请选择要购买的商品", Toast.LENGTH_SHORT).show();
        } else {
            Bundle bOrder = new Bundle();
            String cartItemListJson = new Gson().toJson(list);
            bOrder.putString("cartItemListJson", cartItemListJson);
            Intent intent = new Intent(this, MallConfirmOrderActivity.class);
            intent.putExtras(bOrder);
            startActivity(intent);
            finish();
        }
    }

    /**
     * 设置“删除按键”
     */
    private void setBtn_delete() {
        Map<Integer,Boolean> map = new HashMap<>();
        map = adapter.getCheckBoxMap();
        List<CartItemEntity> list = new ArrayList<CartItemEntity>();
        List<Integer> noList = new ArrayList<Integer>();
        int count = 0;
        for (Integer i : map.keySet()) {
            //Log.e("i----", i+"");
            if (map.get(i)) {
                //Log.e("ttt----", i+"");
                list.add(itemList.get(i));
                noList.add(i);
                count++;
            }
        }

        if (count > 0) {
            adapter.deleteArray(list, noList);
            final String json = new Gson().toJson(list);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String path = getResources().getString(R.string.server_projectpath) +
                        "deleteCartItem.action";
                    /*String path = "http://10.86.2.15:8080/ssm01/" +
                            "deleteCartItem.action";*/
                    SaveDataToServer.sendJsonToServer(json, path, handler);
                }
            }).start();

            adapter.notifyDataSetChanged();
            if (cb_allSelected.isChecked()) {
                cb_allSelected.setChecked(false);
            }

        } else {
            Toast.makeText(this, "请选择要操作的内容", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 设置“全选视图”
     */
    private void setCb_allSelected() {

        BigDecimal btotal = new BigDecimal("0");
        SparseBooleanArray selectArray = new SparseBooleanArray();
        if (cb_allSelected.isChecked()){
            for (int i = 0; i < itemList.size(); i++) {
                selectArray.put(i, true);
                adapter.getCheckBoxMap().put(i, true);
                BigDecimal count = new BigDecimal(itemList.get(i).getCart_item_count() + "");
                BigDecimal price = new BigDecimal(itemList.get(i).getSpecs().getSpecs_price() + "");
                BigDecimal subTotal = count.multiply(price);
                btotal = btotal.add(subTotal);
            }
            adapter.setIsSelected(selectArray);
            adapter.notifyDataSetChanged();
        } else {
            for (int i = 0; i < itemList.size(); i++) {
                selectArray.put(i, false);
                adapter.getCheckBoxMap().remove(i);
            }
            adapter.setIsSelected(selectArray);
            adapter.notifyDataSetChanged();
        }
        tv_total.setText("" + btotal);

    }

    /**
     * 初始化视图
     */
    private void initView() {
        lv_cart = findViewById(R.id.lv_cart);
        tv_total = findViewById(R.id.tv_total);
        cb_allSelected = findViewById(R.id.cb_allSelected);
        btn_settlement = findViewById(R.id.btn_settlement);
        btn_delete = findViewById(R.id.btn_delete);

        cb_allSelected.setOnClickListener(this);
        btn_settlement.setOnClickListener(this);
        btn_delete.setOnClickListener(this);
    }

    /**
     * 从数据库中获取数据
     */
    private void getCartFromSever() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath) +
                        "findCartByUid.action?u_id=" + customer.getU_id();
                /*String path = "http://10.86.2.15:8080/ssm01/findCartByUid.action?u_id=" + customer.getU_id();*/
                try {
                    String json = GetDataFromService.resquestJson(path);
                    CartEntity cartEntity = new Gson().fromJson(json, CartEntity.class);
                    if(cartEntity != null) {
                        Bundle bd = new Bundle();
                        bd.putSerializable("cart", (Serializable) cartEntity);
                        Message message = new Message();
                        message.what = FOUND_CART;
                        message.setData(bd);
                        handler.sendMessage(message);
                    } else {
                        handler.sendEmptyMessage(EMPTY_CART);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(ERROR);
                }
            }
        }).start();
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
