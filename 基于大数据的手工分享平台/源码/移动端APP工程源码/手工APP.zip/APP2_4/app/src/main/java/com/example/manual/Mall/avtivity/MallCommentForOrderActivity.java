package com.example.manual.Mall.avtivity;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.GoodsCommentEntity;
import com.example.manual.Mall.Bean.OrderEntity;
import com.example.manual.Mall.Bean.OrderItemEntity;
import com.example.manual.Mall.adapter.CommentForGoodsAdapter;
import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.R;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import tool.FormatUtil;

public class MallCommentForOrderActivity extends AppCompatActivity {

    private ListView lv_comment_list;
    private Button btn_comment;

    private OrderEntity order;
    private List<OrderItemEntity> itemList;
    private CommentForGoodsAdapter adapter;
    private List<GoodsCommentEntity> comments;
    private final int UPLOAD_SUCCESS = 200;
    private final int UPLOAD_ERROR = 500;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case UPLOAD_SUCCESS:
                    Toast.makeText(MallCommentForOrderActivity.this, "评论成功", Toast.LENGTH_SHORT).show();
                    break;
                case UPLOAD_ERROR:
                    Toast.makeText(MallCommentForOrderActivity.this, "评论失败", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_comment_for_order);

        lv_comment_list = findViewById(R.id.lv_comment_list);
        btn_comment = findViewById(R.id.btn_comment);
        comments = new ArrayList<>();

        Bundle bundle = getIntent().getExtras();
        order = (OrderEntity) bundle.getSerializable("order");
        itemList = order.getItemList();
        adapter = new CommentForGoodsAdapter(order.getOrder_id(), itemList, this);
        lv_comment_list.setAdapter(adapter);
    }

    public void publish_comment(View view) {
        //Toast.makeText(this, "sdsd", Toast.LENGTH_SHORT).show();
        comments = CommentForGoodsAdapter.getComments();
        List<GoodsCommentEntity> commentList = new ArrayList<>();
        int count = 0;
        for (GoodsCommentEntity comment : comments) {
            String content = comment.getGoods_comment_content();
            if (content != null) {
                if (content.trim().equals("")) {
                    continue;
                } else {
                    comment.setGoods_comment_time(FormatUtil.getNowTime());
                    commentList.add(comment);
                    count++;
                }
            }
        }

        if (count < 1) {
            Toast.makeText(this, "至少选择一个商品", Toast.LENGTH_SHORT).show();
            return;
        }

        final String json = new Gson().toJson(commentList);

        final String path = getResources().getString(R.string.server_projectpath) +
                "addGoodsComment.action";
        /*final String path = "http://10.86.2.15:8080/ssm01/" +
                "addGoodsComment.action";*/
        new Thread(new Runnable() {
            @Override
            public void run() {
                SaveDataToServer.sendJsonToServer(json, path, handler);
            }
        }).start();
        finish();
    }
}
