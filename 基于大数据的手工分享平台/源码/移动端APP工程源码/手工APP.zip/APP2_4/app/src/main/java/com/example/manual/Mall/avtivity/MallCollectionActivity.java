package com.example.manual.Mall.avtivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.CartItemEntity;
import com.example.manual.Mall.Bean.MallCollection;
import com.example.manual.Mall.adapter.CollectionAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entity.Customer;

public class MallCollectionActivity extends AppCompatActivity implements View.OnClickListener {

    private ListView lv_collection;
    private TextView tv_empty_tips;
    private CheckBox cb_allSelected;
    private Button btn_settlement;
    private Button btn_delete;

    private List<MallCollection> collectionList;
    private Customer customer;
    private final int LOAD_SUCCESS = 1111;
    private final int FOUND_COLLECTION = 111;
    private final int EMPTY_COLLECTION = 101;
    private final int UPLOAD_SUCCESS = 200;
    private final int ERROR = 505;
    private CollectionAdapter adapter;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case LOAD_SUCCESS:
                    Bundle bundle = msg.getData();
                    collectionList = (List<MallCollection>) bundle.getSerializable("collectionList");
                    setView(collectionList);
                    break;
                case UPLOAD_SUCCESS:
                    Toast.makeText(MallCollectionActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                    break;
                case EMPTY_COLLECTION:
                    setTv_empty_tips("收藏夹为空");
                    break;
                case ERROR:
                    setTv_empty_tips("加载失败");
                    break;
            }
        }

        private void setView(List<MallCollection> collectionList) {
            Handler hd = new Handler(){
                @Override
                public void handleMessage(Message msg) {
                    switch (msg.what) {
                        case 1:
                            Bundle bd = msg.getData();
                            boolean allSelected = bd.getBoolean("allSelected");
                            if (allSelected == true) {
                                cb_allSelected.setChecked(true);
                            } else {
                                cb_allSelected.setChecked(false);
                            }
                            break;
                    }
                }
            };
            adapter = new CollectionAdapter(collectionList, MallCollectionActivity.this, hd);
            lv_collection.setAdapter(adapter);
        }

        /**
         * 设置加载tv_empty_tips（提示视图）
         * @param tips
         */
        private void setTv_empty_tips(String tips) {
            lv_collection.setVisibility(View.GONE);
            tv_empty_tips = findViewById(R.id.empty_tips);
            tv_empty_tips.setVisibility(View.VISIBLE);
            tv_empty_tips.setText(tips);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_collection);
        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("收藏夹");

        // 初始化视图
        initView();
        customer = getCustomer();
        getCollectionListFromServer();
    }

    /**
     * 从服务器获取数据
     */
    private void getCollectionListFromServer() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath) +
                        "findCollectionByUid.action?u_id=" + customer.getU_id();
                /*String path = "http://10.86.2.15:8080/ssm01/findCollectionByUid.action?u_id=" + customer.getU_id();*/
                try {
                    String json = GetDataFromService.resquestJson(path);
                    List<MallCollection> list = new Gson().fromJson(json, new TypeToken<List<MallCollection>>(){}.getType());
                    if (list.size() > 0) {
                        Bundle bd = new Bundle();
                        bd.putSerializable("collectionList", (Serializable) list);
                        Message message = new Message();
                        message.what = LOAD_SUCCESS;
                        message.setData(bd);
                        handler.sendMessage(message);
                    } else {
                        handler.sendEmptyMessage(EMPTY_COLLECTION);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(ERROR);
                }

            }
        }).start();
    }

    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);
        //Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return null;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.cb_allSelected:// 全选
                setCb_allSelected();
                break;
            case R.id.btn_delete:// 删除
                setBtn_delete();
                break;
        }
    }

    /**
     * 设置“删除按键”
     */
    private void setBtn_delete() {
        Map<Integer,Boolean> map = new HashMap<>();
        map = adapter.getCheckBoxMap();
        List<MallCollection> list = new ArrayList<MallCollection>();
        List<Integer> noList = new ArrayList<Integer>();
        int count = 0;
        for (Integer i : map.keySet()) {
            //Log.e("i----", i+"");
            if (map.get(i)) {
                //Log.e("ttt----", i+"");
                list.add(collectionList.get(i));
                noList.add(i);
                count++;
            }
        }

        if (count > 0) {
            adapter.deleteArray(list, noList);
            final String json = new Gson().toJson(list);
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String path = getResources().getString(R.string.server_projectpath) +
                        "deleteCollection.action";
                    /*String path = "http://10.86.2.15:8080/ssm01/" +
                            "deleteCollection.action";*/
                    SaveDataToServer.sendJsonToServer(json, path, handler);
                }
            }).start();
            adapter.notifyDataSetChanged();
            if (cb_allSelected.isChecked()) {
                cb_allSelected.setChecked(false);
            }
        } else {
            Toast.makeText(this, "请选择要操作的内容", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 设置“全选视图”
     */
    private void setCb_allSelected() {
        SparseBooleanArray selectArray = new SparseBooleanArray();
        if (cb_allSelected.isChecked()){
            for (int i = 0; i < collectionList.size(); i++) {
                selectArray.put(i, true);
                adapter.getCheckBoxMap().put(i, true);
            }
            adapter.setIsSelected(selectArray);
            adapter.notifyDataSetChanged();
        } else {
            for (int i = 0; i < collectionList.size(); i++) {
                selectArray.put(i, false);
                adapter.getCheckBoxMap().remove(i);
            }
            adapter.setIsSelected(selectArray);
            adapter.notifyDataSetChanged();
        }
    }

    /**
     * 初始化视图
     */
    private void initView() {
        lv_collection = findViewById(R.id.lv_collection);
        cb_allSelected = findViewById(R.id.cb_allSelected);
        btn_delete = findViewById(R.id.btn_delete);

        cb_allSelected.setOnClickListener(this);
        btn_delete.setOnClickListener(this);
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
