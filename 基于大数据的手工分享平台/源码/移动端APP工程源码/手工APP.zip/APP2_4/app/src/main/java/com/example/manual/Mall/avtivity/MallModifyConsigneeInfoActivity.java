package com.example.manual.Mall.avtivity;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.manual.R;

public class MallModifyConsigneeInfoActivity extends AppCompatActivity {

    Button btn_confirm_modify;
    EditText et_consigneeName;
    EditText et_consigneePhone;
    EditText et_consigneeAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_modify_consignee_info);
        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        //actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("修改收货信息");

        Bundle bundle = getIntent().getExtras();
        initAndSetView(bundle); // 初始化视图并给其设置值

        btn_confirm_modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String consigneeName = et_consigneeName.getText().toString();
                String consigneePhone = et_consigneePhone.getText().toString();
                String consigneeAddress = et_consigneeAddress.getText().toString();

                //保存一个结果
                int resultCode = 3;
                //准备一个带额外数据的intent对象
                Intent data = new Intent();
                Bundle bu = new Bundle();
                bu.putString("consigneeName", consigneeName);
                bu.putString("consigneePhone", consigneePhone);
                bu.putString("consigneeAddress", consigneeAddress);
                data.putExtras(bu);
                setResult(resultCode, data);
                finish();
            }
        });
    }

    /**
     * 初始化视图并给其设置值
     * @param bundle
     */
    private void initAndSetView(Bundle bundle) {
        et_consigneeName = findViewById(R.id.et_consigneeName);
        et_consigneePhone = findViewById(R.id.et_consigneePhone);
        et_consigneeAddress = findViewById(R.id.et_consigneeAddress);
        btn_confirm_modify = findViewById(R.id.btn_confirm_modify);

        et_consigneeName.setText(bundle.getString("consigneeName"));
        et_consigneePhone.setText(bundle.getString("consigneePhone"));
        et_consigneeAddress.setText(bundle.getString("consigneePhone"));
    }
}
