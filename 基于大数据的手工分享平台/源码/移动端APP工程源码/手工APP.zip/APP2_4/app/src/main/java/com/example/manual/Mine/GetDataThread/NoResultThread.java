package com.example.manual.Mine.GetDataThread;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import tool.JDBCutils;

public class NoResultThread extends Thread {
    String sql;
    public NoResultThread(String sql){
        this.sql = sql;
    }

    @Override
    public void run() {
        Connection connection = null;
        try {
            connection = JDBCutils.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.execute();

        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }
}
