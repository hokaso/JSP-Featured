package tool;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import entity.Comment;

public class SaveCommentThread extends Thread {

    Handler handler ;
    Comment comment;
    public SaveCommentThread(Handler handler, Comment comment){
        this.handler = handler;
        this.comment = comment;
    }

    @Override
    public void run() {

        try {
            Connection connection = JDBCutils.getConnection();
            String sql = "insert into comment values(?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,comment.getC_id());
            preparedStatement.setString(2,comment.getD_id());
            preparedStatement.setString(3,comment.getU_id());
            preparedStatement.setString(4,comment.getContent());
            preparedStatement.setString(5,comment.getTime());
            preparedStatement.execute();
            Log.i("sssssssssssssssssssss",sql);
            Message message = new Message();
            message.what = 222;
            handler.sendMessage(message);


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
}
