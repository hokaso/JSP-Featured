package com.example.manual.Mall.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.example.manual.Mall.Bean.GoodsCommentImageEntity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.util.List;

public class GoodsCommentImageAdapter extends BaseAdapter {

    private List<Bitmap> bitmaps;
    private Context context;
    private List<GoodsCommentImageEntity> urls;
    private ImageLoad imageLoad;

    public GoodsCommentImageAdapter(List<GoodsCommentImageEntity> urls, Context context) {
        this.urls = urls;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    @Override
    public int getCount() {
        return urls.size();
    }

    @Override
    public Object getItem(int position) {
        return urls.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            convertView = View.inflate(context, R.layout.item_imageview, null);
        }

        ImageView imageView = convertView.findViewById(R.id.item_imgerview);
        //String imgPath = context.getResources().getString(R.string.server_projectpath) + urls.get(position).getImg_path();
        String imgPath = urls.get(position).getImg_path();
        imageLoad.loadImage(imageView, imgPath);

        return convertView;
    }
}
