package com.example.manual.Mall.avtivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TabHost;

import com.example.manual.Mall.Bean.GoodsCommentEntity;
import com.example.manual.Mall.adapter.GoodsCommentAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

public class MallGoodsCommentActivity extends AppCompatActivity {

    private final int ALL = 0;
    private final int PRAISE = 1;
    private final int NEUTRAL = 2;
    private final int NEGATIVE = 3;

    private GoodsCommentAdapter adapter;
    // private Bundle bundle;
    private String goods_id;
    private int degree;
    private List<GoodsCommentEntity> commentList;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            ListView listView  = findViewById(R.id.all_comment);
            /*switch (msg.what) {
                case ALL:
                    listView = findViewById(R.id.all_comment);
                break;
                case PRAISE:
                    listView = findViewById(R.id.praise_comment);
                    break;
                case NEUTRAL:
                    listView = findViewById(R.id.neutral_comment);
                    break;
                case NEGATIVE:
                    listView = findViewById(R.id.negative_comment);
                    break;
            }*/
            Bundle bd = msg.getData();
            commentList = (List<GoodsCommentEntity>) bd.getSerializable("comment_list");
            adapter = new GoodsCommentAdapter(commentList, MallGoodsCommentActivity.this);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    GoodsCommentEntity comment = commentList.get(position);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("commentEntity", (Serializable) comment);
                    Intent intent = new Intent(MallGoodsCommentActivity.this, MallGoodsCommentDetailActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            });
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_goods_comment);
        Bundle bundle = getIntent().getExtras();
        goods_id = bundle.getString("goods_id");
        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("评论");

        /*TabHost tabhost = findViewById(R.id.goods_comment_tabhost);
        tabhost.setup();*/

        /*//添加选项
        tabhost.addTab(tabhost.newTabSpec("all_comment")
                .setIndicator("全部")
                .setContent(R.id.all_comment)
        );
        //添加选项
        tabhost.addTab(tabhost.newTabSpec("praise_comment")
                .setIndicator("好评")
                .setContent(R.id.praise_comment)
        );
        //添加选项
        tabhost.addTab(tabhost.newTabSpec("neutral_comment")
                .setIndicator("中评")
                .setContent(R.id.neutral_comment)
        );
        //添加选项
        tabhost.addTab(tabhost.newTabSpec("negative_comment")
                .setIndicator("差评")
                .setContent(R.id.negative_comment)
        );
*/
        /**
         * 设置选项卡点击监听
         */
        /*tabhost.setOnTabChangedListener(this);*/

        ListView allLV = findViewById(R.id.all_comment);
        /*ListView praiseLV = findViewById(R.id.praise_comment);
        ListView neutralLV = findViewById(R.id.neutral_comment);
        ListView negativeLV = findViewById(R.id.negative_comment);*/
/*
        allLV.setOnItemClickListener(this);
        praiseLV.setOnItemClickListener(this);
        neutralLV.setOnItemClickListener(this);
        negativeLV.setOnItemClickListener(this);*/

        /**
         * 默认显示全部评论
         */
        getComment(handler, goods_id);
    }

    /*@Override
    public void onTabChanged(String tabId) {
        if(tabId.equals("all_comment")){
            degree = 0;
            getComment(handler, goods_id, degree);
        }
        if(tabId.equals("praise_comment")){
            degree = 1;
            getComment(handler, goods_id, degree);
        }
        if(tabId.equals("neutral_comment")){
            degree = 2;
            getComment(handler, goods_id, degree);
        }
        if(tabId.equals("negative_comment")) {
            degree = 3;
            getComment(handler, goods_id, degree);
        }
    }*/

    /**
     * 启动分线程获取评论信息
     * @param handler
     */
    private void getComment(final Handler handler, final String goods_id) {
        new Thread(){
            @Override
            public void run() {String path = getResources().getString(R.string.server_projectpath) +
                    "loadGoodsComment.action?goods_id=" + goods_id;
                try {
                    List<GoodsCommentEntity> list;

                    // String path = "http://10.86.2.15:8080/ssm01/loadGoodsComment.action?goods_id=" + goods_id;
                    String responseJson = GetDataFromService.resquestJson(path);
                    list =  new Gson().fromJson(responseJson, new TypeToken<List<GoodsCommentEntity>>(){}.getType());
                    Message message = new Message();
                    Bundle bp = new Bundle();
                    bp.putSerializable("comment_list", (Serializable) list);
                    message.setData(bp);
                    message.what = degree;
                    handler.sendMessage(message);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    /*@Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        GoodsCommentEntity comment = commentList.get(position);
        Bundle bundle = new Bundle();
        bundle.putSerializable("commentEntity", (Serializable) comment);
        Intent intent = new Intent(MallGoodsCommentActivity.this, MallGoodsCommentDetailActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }*/

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
