package com.example.manual.Mall.avtivity;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.OrderEntity;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.R;

import java.io.IOException;

public class MallOrderPayActivity extends AppCompatActivity {

    private Button btn_pay_order;
    private TextView tv_money;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 100:
                    Toast.makeText(MallOrderPayActivity.this, "付款成功", Toast.LENGTH_SHORT).show();
                    finish();
                    break;
                case 99:
                    Toast.makeText(MallOrderPayActivity.this, "付款失败", Toast.LENGTH_SHORT).show();
                    break;
                case 59:
                    Toast.makeText(MallOrderPayActivity.this, "操作失败", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_order_pay);
        btn_pay_order = findViewById(R.id.btn_pay_order);
        tv_money = findViewById(R.id.tv_money);

        Bundle bundle = getIntent().getExtras();
        double total = bundle.getDouble("total");
        final String order_id = bundle.getString("order_id");
        tv_money.setText("合计：" + total);

        btn_pay_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateOrderState(order_id, OrderEntity.STATE_UNDELIVER);
            }
        });
    }

    private void updateOrderState(String order_id, String state) {
        final String path = getResources().getString(R.string.server_projectpath) +
                "updateOrderState.action?order_id=" + order_id + "&order_state=" + state;
        /*final String path = "http://10.86.2.15:8080/ssm01/" +
                "updateOrderState.action?order_id=" + order_id + "&order_state=" + state;*/
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String res = GetDataFromService.resquestJson(path);
                    if (res.equals("success")) {
                        handler.sendEmptyMessage(100);
                    } else {
                        handler.sendEmptyMessage(99);
                    }
                } catch (IOException e) {
                    handler.sendEmptyMessage(59);
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
