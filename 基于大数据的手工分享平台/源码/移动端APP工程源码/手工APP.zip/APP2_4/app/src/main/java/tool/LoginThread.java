package tool;


import android.os.Bundle;
import android.os.Message;
import android.os.Handler;
import android.util.Log;

import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import entity.Customer;

public class LoginThread extends Thread {
    Connection connection = null;
    Customer customer = null;
    Handler handler = null;
    public LoginThread(Customer customer, Handler handler){
        this.customer = customer;
        this.handler = handler;
    }

    @Override
    public void run() {

        try {
            URL url = new URL("http://47.102.155.206:8080/ssm01/login.action");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            Gson gson = new Gson();
            String json = gson.toJson(customer);
            urlConnection.setRequestMethod("POST");
            urlConnection.setDoOutput(true);
            urlConnection.setDoInput(true);
            urlConnection.connect();
            OutputStream outputStream = urlConnection.getOutputStream();
            outputStream.write(json.getBytes());
            int code = urlConnection.getResponseCode();
            Log.i("code",code+"");
            InputStream is = urlConnection.getInputStream();
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len = -1;
            while ((len = is.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }
            baos.close();
            is.close();
            urlConnection.disconnect();
            String str = "";
            str = baos.toString();
            if(!str.equals("")){
                customer  = gson.fromJson(str,Customer.class);
                System.out.println(customer);
                Bundle bundle = new Bundle();
                bundle.putSerializable("customer",customer);
                Message message = new Message();
                message.setData(bundle);
                message.what = 111;
                handler.sendMessage(message);
            }else{
                //登录失败
                Message message = new Message();
                message.what = 000;
                handler.sendMessage(message);
            }



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        /*try{
            connection = JDBCutils.getConnection();
            String sql = "select * from customer where phonenumber = ? and password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,customer.getPhonenumber());
            preparedStatement.setString(2,customer.getPassword());
            ResultSet resultSet = preparedStatement.executeQuery();
            ResultSetMetaData metaData = resultSet.getMetaData();
            int colcount = metaData.getColumnCount();
            resultSet.last();
            int rowcount = resultSet.getRow();
            Log.i("c",rowcount+"");
            if(rowcount > 0){
                //登录成功
                //封装数据到customer对象中
                resultSet.beforeFirst();
                while(resultSet.next()){
                    for (int i = 0 ;i<rowcount;i++){
                        customer.setU_id(resultSet.getString("u_id"));
                        customer.setName(resultSet.getString("name"));
                        customer.setHead(resultSet.getString("head"));
                        customer.setPhonenumber(resultSet.getString("phonenumber"));
                        customer.setPassword(resultSet.getString("password"));
                        customer.setAddress(resultSet.getString("address"));
                        customer.setGender(resultSet.getString("gender"));
                        customer.setLocation(resultSet.getString("location"));
                        customer.setSignature(resultSet.getString("signature"));
                    }

                }
                Bundle bundle = new Bundle();
                bundle.putSerializable("customer",customer);
                Message message = new Message();
                message.setData(bundle);
                message.what = 111;
                handler.sendMessage(message);

            }else{
                //登录失败
                Message message = new Message();
                message.what = 000;
                handler.sendMessage(message);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
*/
    }
}
