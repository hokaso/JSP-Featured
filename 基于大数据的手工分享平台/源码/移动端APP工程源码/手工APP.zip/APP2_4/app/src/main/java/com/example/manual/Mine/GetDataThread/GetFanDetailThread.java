package com.example.manual.Mine.GetDataThread;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.manual.Mall.netUtil.GetDataFromService;

import java.io.IOException;
import java.sql.Connection;

public class GetFanDetailThread extends Thread {

    private Handler handler;

    Connection connection = null;
    String path ;
    /* 传入两个参数，第一个是用于通信的handler，第二个是动态类型 */
    public GetFanDetailThread(Handler h, String path) {
        this.handler = h;
        this.path = path;
    }

    @Override
    public void run() {
        try {
            //请求服务器，返回一个List集合的json串
            String data = GetDataFromService.resquestJson(path);
            Message message = handler.obtainMessage();
            message.what=333;
            Bundle bundle = new Bundle();
            bundle.putString("fan_detail",data);
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}