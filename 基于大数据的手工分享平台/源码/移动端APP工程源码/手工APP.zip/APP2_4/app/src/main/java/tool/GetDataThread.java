package tool;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.example.manual.Mall.netUtil.GetDataFromService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entity.Dynamic;

public class GetDataThread extends Thread {

    private Handler handler ;
    private String type;
    private String title = null;
    private String category;


    Connection connection = null;
    /* 传入两个参数，第一个是用于通信的handler，第二个是动态类型 */
    public GetDataThread(Handler h,String type,String category){
        this.handler = h ;
        this.type = type;
        this.category = category;
    }
    @Override
    public void run() {

        /*String sql = " select dynamic.*,customer.`name`,customer.`headPicPath` from dynamic,customer where" +
                " dynamic.`type` = '" + type + "' and dynamic.`u_id`= customer.`u_id` " +
                "and category = '"+category+"' ";
        if(title!=null){
            sql += "and title like '%"+title+"%'";
        }*/
        //1、第一步拿到服务器的地址URL

        try {
            String url = "http://47.102.155.206:8080/ssm01/findCommuityDynamic.action?type="+type+"&category="+category;
            /*String url = "http://10.86.2.72:8080/ssm01/findCommuityDynamic.action?type="+type+"&category="+category;*/
            System.out.println(url);
            String data = GetDataFromService.resquestJson(url);
            System.out.println(data);
            Gson gson = new Gson();
            ArrayList<Map<String,Object>> listitem = gson.fromJson(data,new TypeToken<List<Map<String,Object>>>() {}.getType());
            Bundle bundle = new Bundle();
            Message message=new Message();
            bundle.putSerializable("listitem",listitem);
            if(type.equals("latestresp")){
                message.what = 0;
            }else if(type.equals("latestpub")){
                message.what = 1;
            }else if(type.equals("host")){
                message.what = 2;
            }
            message.setData(bundle);
            handler.sendMessage(message);
        } catch (Exception e) {
        }

    }

 /*---------------------------------------------------*/

    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
