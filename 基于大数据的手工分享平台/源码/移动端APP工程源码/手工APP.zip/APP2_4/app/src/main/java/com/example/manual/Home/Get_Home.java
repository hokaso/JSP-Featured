package com.example.manual.Home;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import tool.JDBCutils;

public class Get_Home extends Thread{

    private Handler handler;
    private String u_id;
    private String t_id;

    //h负责传输数据
    //在数据库中搜索涉及u（u_id)的聊天记录
    public Get_Home(Handler h, String u) {
        this.handler = h;
        this.u_id = u;
    }

    @Override
    public void run() {
        System.out.println("******************Here is Get_Home*************************");
        Statement stmt=null;
        Connection conn=null;
        try {
            //1.注册驱动程序，2.获取连接对象
            conn = JDBCutils.getConnection();
            //3.创建Statement
            stmt = conn.createStatement();

            int[] column_num = new int[1000];

            int i = 0;
            int max_num = 0;
            String max_category = null;



            //4.准备sql，获取favorite的列名对应数据
            String sql ="select weave from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("weave");
                if(column_num[i] > max_num) {
                    max_num = column_num[i];
                    max_category = "weave";
                }
                i++;
            }

            //4.准备sql，获取favorite的列名对应数据
            sql ="select paper from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("paper");
                if(column_num[i] > max_num) {
                    max_num = column_num[i];
                    max_category = "paper";
                }
                i++;
            }

            //4.准备sql，获取favorite的列名对应数据
            sql ="select ornaments from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("ornaments");
                if(column_num[i] > max_num) {
                    max_num = column_num[i];
                    max_category = "ornaments";
                }
                i++;
            }

            //4.准备sql，获取favorite的列名对应数据
            sql ="select leather from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("leather");
                if(column_num[i] > max_num) {
                    max_num = column_num[i];
                    max_category = "leather";
                }
                i++;
            }

            //4.准备sql，获取favorite的列名对应数据
            sql ="select fabric from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("fabric");
                if(column_num[i] > max_num) {
                    max_num = column_num[i];
                    max_category = "fabric";
                }
                i++;
            }

            //4.准备sql，获取favorite的列名对应数据
            sql ="select embroidery from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("embroidery");
                if(column_num[i] > max_num) {
                    max_num = column_num[i];
                    max_category = "embroidery";
                }
                i++;
            }

            //4.准备sql，获取favorite的列名对应数据
            sql ="select others from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("others");
                if(column_num[i] > max_num) {
                    max_num = column_num[i];
                    max_category = "others";
                }
                i++;
            }

            //4.准备sql，获取favorite的列名对应数据
            sql ="select pri_total_like from favorite where u_id = '"+u_id+"'";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);
            if (rs.next()) {
                column_num[i] = rs.getInt("pri_total_like");
                i++;
            }

            System.out.println("column_num.length = "+column_num.length);
            System.out.println("max_num = "+max_num);
            System.out.println("max_category = "+max_category);

            for(int ii=0; ii<i; ++ii) {
                System.out.println("ii = "+ii+" , column_num[ii] = "+column_num[ii]);
            }

            String[] username = new String[1000];
            String[] title = new String[1000];
            String[] count = new String[1000];
            String[] time = new String[1000];
            String[] content = new String[1000];
            String[] u_id1 = new String[1000];
            String[] d_id = new String[1000];
            String[] headpic = new String[1000];
            String[] type = new String[1000];
            String[] category = new String[1000];


            int category_num = (int) ((Math.random()*49 + 1)%7+1);
            sql = "select goods_category.`ca_name` from goods_category "+
                    "where goods_category.`ca_id` = '"+category_num+"'";
            rs = stmt.executeQuery(sql);
            String mul_category = null;
            while(rs.next()) {
                mul_category = rs.getString("ca_name");
            }




            //获取dynamic表的信息
            /*sql ="select dynamic.*,customer.name,customer.headPicPath from dynamic,customer where category = '"+max_category+"' "+
                "order by total_like+total_benefit desc";*/
//            sql = " select dynamic.*,customer.`name`,customer.`headPicPath` from dynamic,customer where " +
//                    "dynamic.`u_id`= customer.`u_id` " +
//                    "and category = '"+max_category+"' ";
            sql = " SELECT dynamic.*,customer.`name`,customer.`headPicPath` FROM DYNAMIC,customer WHERE" +
                    " dynamic.`u_id`= customer.`u_id` AND (dynamic.category = '"+max_category+"' OR dynamic.category =  '"+mul_category+"')" +
                    " ORDER BY total_like+total_benefit DESC LIMIT 0,5";
            System.out.println(sql);
            //5.发送sql语句，执行sql语句,得到返回结果
            rs = stmt.executeQuery(sql);


            ArrayList<Map<String, Object>> listitem = new ArrayList<>();
                while (rs.next()) {
                    username[i] = rs.getString("name");
                    title[i] = rs.getString("title");
                    time[i] = rs.getString("release_date");
                    content[i] = rs.getString("content");
                    u_id1[i] = rs.getString("u_id");
                    d_id[i] = rs.getString("d_id");
                    headpic[i] = rs.getString("headPicPath");
                   /* type[i] = rs.getString("type");*/
                    category[i] = rs.getString("category");
                    sql = "select count(*) from comment where d_id = '"+rs.getString("d_id")+"'";
                    Statement statment2 = conn.createStatement();
                    ResultSet resultSet = statment2.executeQuery(sql);
                    resultSet.next();
                    //获取评论数
                    int comment = Integer.parseInt(resultSet.getString(1));
                    //获取点赞数
                    sql = "select count(*) from liked where d_id = '"+rs.getString("d_id")+"'";
                    Statement statment3 = conn.createStatement();
                    ResultSet resultSet2 = statment3.executeQuery(sql);
                    resultSet2.next();
                    int like = Integer.parseInt(resultSet2.getString(1));
                    sql = "update dynamic set total_comment="+comment+",total_like="+like+" where d_id = '"+rs.getString("d_id")+"'";
                    Statement statment4 = conn.createStatement();
                    statment4.execute(sql);
                    count[i] = "评论："+comment+" 点赞："+like+"";
                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("username", username[i]);
                    map.put("title", title[i]);
                    map.put("count", count[i]);
                    map.put("release_date" , time[i]);
                    map.put("content" , content[i]);
                    map.put("d_id",d_id[i]);
                    map.put("u_id",u_id1[i]);
                    map.put("headpic",headpic[i]);
                   /* map.put("type",type[i]);*/
                    map.put("category",category[i]);
                    map.put("total_like",like);
                    map.put("total_comment",comment);
                    i++;
                    listitem.add(map);
                }
                Message message = handler.obtainMessage();
                Bundle bundle = new Bundle();
                bundle.putSerializable("listitem",listitem);
                message.what=0x003;
                message.setData(bundle);
                handler.sendMessage(message);

            } catch (SQLException e1) {
            e1.printStackTrace();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }

    }
}
