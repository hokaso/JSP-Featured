package tool;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import com.example.manual.R;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class Save_PictureThread extends Thread {

    Handler mhandler = null;
    Bitmap bitmap;
    Context context;
    String type;//保存的是什么图片，用户头像或。。
    String u_id;

    /**
     *
     * @param handler 传数据
     * @param bitmap 要保存的图片
     * @param context 上下文
     * @param type 保存的是什么图片，用户头像或是动态图片
     * @param u_id 用户的id
     */
    public Save_PictureThread(Handler handler, Bitmap bitmap, Context context,String type,String u_id){
        mhandler = handler;
        this.bitmap = bitmap;
        this.context = context;
        this.type = type;
        this.u_id = u_id;
    }

    @Override
    public void run() {


        //将图片转为字节数组
        ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos1);
        byte[] datas = baos1.toByteArray();
        try {
            baos1.close();
            System.out.println("fffffff");
            URL url = new URL(context.getString(R.string.server_projectpath)+"savePicture.action?type="+type+"&uid="+u_id);
          /*  URL url = new URL("http://10.86.2.72:8080/ssm01/"+"savePicture.action?type="+type+"&uid="+u_id);*/
            HttpURLConnection  connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setRequestMethod("POST");
            connection.connect();
            //将图片发送到服务器上保存
            OutputStream os = connection.getOutputStream();
            os.write(datas);
            int responseCode = connection.getResponseCode();
            if(responseCode==200){
                //返回服务器上保存图片的路径
                InputStream is = connection.getInputStream();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buffer = new byte[1024];
                int len = -1;
                while ((len = is.read(buffer)) != -1) {
                    baos.write(buffer, 0, len);
                }
                baos.close();
                is.close();
                //返回服务器上保存图片的路径
                String picpath = baos.toString();
                Message message = mhandler.obtainMessage();
                Bundle bundle = new Bundle();
                bundle.putString("picpath",picpath);
                message.what = 111;
                message.setData(bundle);
                mhandler.sendMessage(message);

            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
