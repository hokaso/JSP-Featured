package com.example.manual.Mall.avtivity;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.OrderEntity;
import com.example.manual.Mall.adapter.OrderListAdapter;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import entity.Customer;

public class MallOrderActivity extends AppCompatActivity {

    private ListView lv_myorder;
    private TextView empty_order;
    private Customer customer;
    private List<OrderEntity> orderList;
    private OrderListAdapter adapter;

    private final int FOUND_ORDERS = 121;
    private final int EMPTY_ORDER = 122;
    private final int FOUND_ERROR = 123;

    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case FOUND_ORDERS:
                    Bundle b = msg.getData();
                    orderList = (List<OrderEntity>) b.getSerializable("orderList");
                    String json = b.getString("json");
                    // Log.e("-----------orderList = ", orderList.toString());
                    //adapter = new OrderListAdapter(MallOrderActivity.this, orderList, handler);
                    adapter = new OrderListAdapter(MallOrderActivity.this, json, handler, customer);
                    lv_myorder.setAdapter(adapter);
                    break;
                case EMPTY_ORDER:
                    lv_myorder.setVisibility(View.GONE);
                    empty_order.setVisibility(View.VISIBLE);
                    empty_order.setText("暂无订单记录");
                    break;
                case FOUND_ERROR:
                    lv_myorder.setVisibility(View.GONE);
                    empty_order.setVisibility(View.VISIBLE);
                    empty_order.setText("加载失败");
                    break;
                case 22:
                    Bundle bp = msg.getData();
                    int position = bp.getInt("position");
                    orderList.get(position).setOrder_state(OrderEntity.STATE_UNDELIVER);
                    adapter.notifyDataSetChanged();
                    finish();
                    break;
                case 100:
                    adapter.notifyDataSetChanged();
                    //finish();
                    break;
                case 99:
                    Toast.makeText(MallOrderActivity.this, "取消失败", Toast.LENGTH_SHORT).show();
                    break;
                case 59:
                    Toast.makeText(MallOrderActivity.this, "操作失败，未知错误", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_order);
        ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("我的订单");
        // 获取当前用户
        customer = getCustomer();
        lv_myorder = findViewById(R.id.lv_myorder);
        empty_order = findViewById(R.id.empty_order);

        getDatafromServer();
    }

    /**
     * 从服务器获取数据
     */
    private void getDatafromServer() {
        final String path = getResources().getString(R.string.server_projectpath) +
                "findOrdersByUid.action?u_id=" + customer.getU_id();
       /* final String path = "http://10.86.2.15:8080/ssm01/" +
                "findOrdersByUid.action?u_id=" + customer.getU_id();*/
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String json = GetDataFromService.resquestJson(path);
                    List<OrderEntity> list = new Gson().fromJson(json, new TypeToken<List<OrderEntity>>(){}.getType());
                    //Log.e("-----------json = ", json);
                    if (list.size() > 0) {
                        //Log.e("-----------list = ", list.toString());
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("orderList", (Serializable) list);
                        bundle.putString("json", json);
                        Message message = new Message();
                        message.what = FOUND_ORDERS;
                        message.setData(bundle);
                        handler.sendMessage(message);
                    } else {
                        handler.sendEmptyMessage(EMPTY_ORDER);
                    }
                } catch (IOException e) {
                    handler.sendEmptyMessage(FOUND_ERROR);
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * 获取用户
     * @return
     */
    private Customer getCustomer(){
        SharedPreferences sharedPreferences = getSharedPreferences("customer", MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);

        // Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            return null;
        }
    }

    /**
     * ActionBar返回
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
