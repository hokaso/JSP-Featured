package tool;

import com.example.manual.Mine.GetDataThread.NoResultThread;

public class MysqlUtil {

    String sql;

    /**
     * 对数据库进行无需数据返回的操作
     * @param sql
     */
    public MysqlUtil(String sql){
        this.sql=sql;
    }
    public void excute() {

        NoResultThread noResultThread = new NoResultThread(sql);
        noResultThread.start();

    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }
}
