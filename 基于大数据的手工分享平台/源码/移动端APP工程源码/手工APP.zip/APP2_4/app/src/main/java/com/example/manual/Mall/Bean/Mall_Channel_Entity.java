package com.example.manual.Mall.Bean;

import android.graphics.drawable.Drawable;

public class Mall_Channel_Entity {

    private int id;
    private String name;
    private Drawable image;
    private String imageResource;

    public Mall_Channel_Entity() {
    }




    public Mall_Channel_Entity(int id, String name, Drawable image) {
        this.id = id;
        this.name = name;
        this.image = image;
    }

    public Mall_Channel_Entity(int id, String name, Drawable image, String imageResource) {
        this.id = id;
        this.name = name;
        this.image = image;
        this.imageResource = imageResource;
    }

    public Mall_Channel_Entity(int id, String name, String imageResource) {
        this.id = id;
        this.name = name;
        this.imageResource = imageResource;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Drawable getImage() {
        return image;
    }

    public void setImage(Drawable image) {
        this.image = image;
    }

    public String getImageResource(int a1) {
        return imageResource;
    }

    public void setImageResource(String imageResource) {
        this.imageResource = imageResource;
    }

    @Override
    public String toString() {
        return "Mall_Channel_Entity{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", image=" + image +
                ", imageResource='" + imageResource + '\'' +
                '}';
    }
}
