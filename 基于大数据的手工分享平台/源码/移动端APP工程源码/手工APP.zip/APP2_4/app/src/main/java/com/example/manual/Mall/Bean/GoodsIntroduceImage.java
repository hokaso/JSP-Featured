package com.example.manual.Mall.Bean;

public class GoodsIntroduceImage {

	private String img_path;
	private int img_order;
	public GoodsIntroduceImage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public GoodsIntroduceImage(String img_path, int img_order) {
		super();
		this.img_path = img_path;
		this.img_order = img_order;
	}
	public String getImg_path() {
		return img_path;
	}
	public void setImg_path(String img_path) {
		this.img_path = img_path;
	}
	public int getImg_order() {
		return img_order;
	}
	public void setImg_order(int img_order) {
		this.img_order = img_order;
	}
	@Override
	public String toString() {
		return "GoodsIntroduceImage [img_path=" + img_path + ", img_order=" + img_order + "]";
	}

}
