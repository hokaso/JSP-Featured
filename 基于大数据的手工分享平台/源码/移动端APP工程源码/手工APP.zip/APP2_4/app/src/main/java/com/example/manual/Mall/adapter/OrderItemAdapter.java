package com.example.manual.Mall.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.manual.Mall.Bean.OrderItemEntity;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.R;

import java.util.List;

public class OrderItemAdapter extends BaseAdapter {

    private List<OrderItemEntity> itemList;
    private Context context;
    private ImageLoad imageLoad;

    public OrderItemAdapter(List<OrderItemEntity> itemList, Context context) {
        this.itemList = itemList;
        this.context = context;
        imageLoad = new ImageLoad(context);
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(context, R.layout.mall_item_orders, null);
        }
        ImageView iv_goodsPic = convertView.findViewById(R.id.iv_goodsPic);
        TextView tv_goods_name = convertView.findViewById(R.id.tv_goods_name);
        TextView tv_goods_describe = convertView.findViewById(R.id.tv_goods_describe);
        TextView tv_goods_price = convertView.findViewById(R.id.tv_goods_price);
        TextView tv_goods_specs = convertView.findViewById(R.id.tv_goods_specs);
        TextView tv_count = convertView.findViewById(R.id.tv_count);

        OrderItemEntity item = itemList.get(position);
        tv_count.setText("数量: " + item.getOrder_item_count() + "");
        tv_goods_price.setText("小计: ￥" + item.getItem_price());
        tv_goods_describe.setText(item.getGoods().getGoods_describe());
        tv_goods_name.setText(item.getGoods().getGoods_name());
        tv_goods_specs.setText(item.getSpecs().getSpecs_attrs());
        String imgPath = context.getResources().getString(R.string.server_projectpath)
                + item.getSpecs().getSpecs_img();

        imageLoad.loadImage(iv_goodsPic, imgPath);

        return convertView;
    }
}
