package com.example.manual.Chat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.R;
import com.google.gson.Gson;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import entity.Customer;

public class Chat extends AppCompatActivity {
    public static final String IP_ADDR = "47.102.155.206";//服务器地址
    public static final int PORT = 4405;//服务器端口号

    private TextView edittext;
    private String u_id; //自己的ID
    private String t_id; //选定的聊天对象的ID
    private String ss = "";


    //通过Get_Message更新两人聊天信息
    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            ListView listView = null;
            switch (msg.what){
                case 0x001:
                    listView = findViewById(R.id.Chat_listview);
                    break;
                default:
                    break;
            }
            Bundle bundle = msg.getData();
            List<ConcurrentHashMap<String, Object>> listitem =
                    (List<ConcurrentHashMap<String, Object>>) bundle.getSerializable("listitem");
            SimpleAdapter adapter = new SimpleAdapter(getApplicationContext(), listitem, R.layout.chat_item,
                    new String[]{"u_id","t_id","time","context"},
                    new int[]{R.id.u_id, R.id.t_id, R.id.message_time, R.id.message_context});
            listView.setAdapter(adapter);
        }
    };


    //每隔1秒刷新一次聊天消息界面
    private int TIME = 1000; //每隔1s执行一次.
    Handler handler001 = new Handler();
    Runnable runnable001 = new Runnable() {
        @Override
        public void run() {
            Get_Message gmsg = new Get_Message(handler, u_id, t_id);
            gmsg.start();
            handler001.postDelayed(this, TIME);
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat);

        edittext = (TextView) findViewById(R.id.sendText001);
        Button send001 = (Button)findViewById(R.id.send001);
        send001.setOnClickListener(new MyonclickListener());

        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        t_id=bundle.getString("t_id");

        //获取自己的ID
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson","");
        Gson gson = new Gson();
        Customer customer = gson.fromJson(customerJson, Customer.class);
        u_id = customer.getU_id();


        // 设置返回按钮
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //显示向左的箭头图标
        getSupportActionBar().setTitle(bundle.getString("t_id")); //显示聊天对象名字

        //启动一个子线程，显示已发送的聊天信息
        handler001.post(runnable001);
//        handler001.postDelayed(runnable001, TIME);

    }


    private class MyonclickListener implements OnClickListener {
        @Override
        public void onClick(View v) {
            // TODO Auto-generated method stub
            //启动一个子线程，显示已发送的聊天信息
            Get_Message gmsg = new Get_Message(handler, u_id, t_id);
            gmsg.start();
            //获取editText控件的数据
            final String my_string = edittext.getText().toString();
            //清空editText里面的内容
            edittext.setText("");
            //判断有无输入
            if (TextUtils.isEmpty(my_string)) {
                //在手机上输出
                //Toast.LENGTH_SHORT:函数功能为显示时间短
                //Toast.LENGTH_LONG :显示时间长
                Toast.makeText(Chat.this, "没有数据输入", Toast.LENGTH_LONG).show();
            } else {
//                Toast.makeText(Chat2.this, "数据为:" + my_string, Toast.LENGTH_SHORT).show();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        System.out.println("客户端启动...");
                        Socket socket = null;
                        try {
                            //创建一个流套接字并将其连接到指定主机上的指定端口号
                            socket = new Socket(IP_ADDR, PORT);
                            //读取服务器端数据
                            DataInputStream input = new DataInputStream(socket.getInputStream());
                            //向服务器端发送数据
                            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
                            out.writeUTF(u_id);
                            out.writeUTF(t_id);
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");// HH:mm:ss
                            Date date = new Date(System.currentTimeMillis());// 获取当前时间
                            out.writeUTF(simpleDateFormat.format(date));
                            out.writeUTF(my_string);
                            String ret = input.readUTF();
                            System.out.println("服务器端返回过来的是: " + ret);
                            out.close();
                            input.close();
                        } catch (Exception e) {
                            System.out.println("客户端异常:" + e.getMessage());
                            e.printStackTrace();
                        } finally {
                            if (socket != null) {
                                try {
                                    socket.close();
                                } catch (IOException e) {
                                    socket = null;
                                    System.out.println("客户端 finally 异常:" + e.getMessage());
                                }
                            }
                        }
                    }
                }).start();
            }
        }
    }


    //ActionBar上面的返回按钮事件
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {//处理ActionBar事件
        switch (item.getItemId()) {
            case android.R.id.home: //返回键id
                handler001.removeCallbacks(runnable001);
                this.finish();
                return false;
            case R.id.search:
                Log.i("search","5555");
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    //监听Back按键，关闭刷新聊天信息的线程
    public void onBackPressed() {
        handler001.removeCallbacks(runnable001);    //结束刷新聊天信息的线程
        super.onBackPressed();
        System.out.println("进行了Back操作");
    }
}