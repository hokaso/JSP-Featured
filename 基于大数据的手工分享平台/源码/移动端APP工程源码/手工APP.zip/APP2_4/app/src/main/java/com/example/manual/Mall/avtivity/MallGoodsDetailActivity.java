package com.example.manual.Mall.avtivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.manual.Mall.Bean.GoodsEntity;
import com.example.manual.Mall.Bean.GoodsIntroduceImage;
import com.example.manual.Mall.Bean.MallCollection;
import com.example.manual.Mall.netUtil.GetDataFromService;
import com.example.manual.Mall.netUtil.ImageLoad;
import com.example.manual.Mall.netUtil.SaveDataToServer;
import com.example.manual.Mine.activity.LoginActivity;
import com.example.manual.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import entity.Customer;

public class MallGoodsDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private LinearLayout ll_goods_introduce_image;
    private Button detail_customrer_service;
    private Button detail_add2collection;
    private Button detail_add2cart;
    private Button detail_buy;

    private Button detail_goods_comment;
    private LinearLayout detail_goods_specifications;
    private ImageView detail_goods_cover;
    private TextView detail_goods_price;
    private TextView detail_goods_name;
    private TextView tv_goods_describe;

    private List<GoodsIntroduceImage> list = null;
    private Bundle bundle;
    private String goods_id;
    private final int LOAD_SUCCESS = 1;
    private final int LOAD_ERROR = 0;
    private static final int LOAD_EMPTY = 2;
    private final int UPLOAD_ERROR = 500;
    private final int UPLOAD_SUCCESS = 200;
    private final int FOUND_GOODS = 1122;
    private final int NOT_FOUND_GOODS = 2222;
    private List<Map<String, String>> listItems;
    private String imgPath;
    private Map<String, Bitmap> cacheMap = new HashMap<String, Bitmap>();
    private List<Bitmap> imageList;
    private GoodsEntity goods;
    private ImageLoad imageLoad;

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case LOAD_SUCCESS:
                    addImageView(imageList, ll_goods_introduce_image);
                    break;
                case LOAD_EMPTY:
                    break;
                case LOAD_ERROR:
                    Toast.makeText(MallGoodsDetailActivity.this, "加载失败", Toast.LENGTH_SHORT).show();
                    break;
                case UPLOAD_SUCCESS:
                    Toast.makeText(MallGoodsDetailActivity.this, "收藏成功", Toast.LENGTH_SHORT).show();
                    break;
                case UPLOAD_ERROR:
                    Bundle b = msg.getData();
                    String res = b.getString("error_msg");
                    if (res.equals("existed")) {
                        Toast.makeText(MallGoodsDetailActivity.this, "已在收藏夹", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MallGoodsDetailActivity.this, "收藏失败", Toast.LENGTH_SHORT).show();
                    }
                    break;
                case FOUND_GOODS:
                    Bundle gb = msg.getData();
                    goods = (GoodsEntity) gb.getSerializable("goods");
                    if (goods != null) {
                        setView();
                    } else {
                       Toast.makeText(MallGoodsDetailActivity.this, "加载失败", Toast.LENGTH_SHORT);
                    }
                    break;
                default:
                    break;
            }
        }

        private void setView() {
            String imgPath = getResources().getString(R.string.server_projectpath) + goods.getGoods_coverPic();
            // String imgPath = "http://10.86.2.15:8080/ssm01/" + goods.getGoods_coverPic();
            detail_goods_name.setText(goods.getGoods_name());
            detail_goods_price.setText(goods.getGoods_price() + "");
            tv_goods_describe.setText(goods.getGoods_describe());
            imageLoad.loadImage(detail_goods_cover, imgPath);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mall_goods_detail);
        bundle = getIntent().getExtras();
        imageLoad = new ImageLoad(MallGoodsDetailActivity.this);
        initView();

        goods_id = bundle.getString("goods_id");
        //goods = (GoodsEntity) bundle.getSerializable("goods");
        getGoodsFromServer(goods_id);


        // String coverPicPath = (String) bundle.get("goods_coverPic");
        final ActionBar actionBar = getSupportActionBar();
        // 设置返回按钮
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("商品详情");
        // 初始化视图

        getIntroImg(imageLoad);

    }

    /**
     * 从服务器获取数据
     * @param goods_id
     */
    private void getGoodsFromServer(final String goods_id) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath) +
                "findGoodsById.action?goods_id=" + goods_id;
                /*String path = "http://10.86.2.15:8080/ssm01/" +
                        "findGoodsById.action?goods_id=" + goods_id;*/
                try {
                    String json = GetDataFromService.resquestJson(path);

                    //GoodsEntity g = new Gson().fromJson(json, GoodsEntity.class);
                    goods = new Gson().fromJson(json, GoodsEntity.class);

                    if (goods != null) {
                        Bundle bGodos = new Bundle();
                        bGodos.putSerializable("goods", goods);
                        Message mGoods = new Message();
                        mGoods.setData(bGodos);
                        mGoods.what = FOUND_GOODS;
                        handler.sendMessage(mGoods);
                    } else {
                        handler.sendEmptyMessage(NOT_FOUND_GOODS);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    /**
     * 获取商品介绍的图片
     * @param imageLoad
     */
    private void getIntroImg(final ImageLoad imageLoad) {
        // 分线程，联网请求加载
        new Thread(){
            @Override
            public void run() {
                try {
                    String path = getResources().getString(R.string.server_projectpath) +
                            "getTroduceImage.action?goods_id=" + goods_id;

                    String responseJosn = GetDataFromService.resquestJson(path);
                    list = new Gson().fromJson(responseJosn, new TypeToken<List<GoodsIntroduceImage>>(){}.getType());
                    if (list != null) {
                        imageList = new ArrayList<Bitmap>();
                        for(GoodsIntroduceImage img : list) {
                            imgPath = getResources().getString(R.string.server_projectpath) + img.getImg_path();
                            Bitmap bmp = (Bitmap) imageLoad.loadImage(imgPath);
                            imageList.add(bmp);
                        }
                        handler.sendEmptyMessage(LOAD_SUCCESS);
                    }
                    //detail_lv_goods_introduce.setAdapter(adapter);
                } catch (IOException e) {
                    e.printStackTrace();
                    handler.sendEmptyMessage(LOAD_ERROR);
                }
            }
        }.start();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.detail_goods_specifications:  // 请选择款式
                turnToSelectSpecs("detail_goods_specifications");
                break;
            case R.id.detail_goods_comment: // 商品评论
                Intent comment = new Intent(MallGoodsDetailActivity.this, MallGoodsCommentActivity.class);
                comment.putExtras(bundle);
                startActivity(comment);
                break;
            case R.id.detail_add2collection:    // 收藏
                addToCollectionInServer();
                break;
            case R.id.detail_add2cart:  // 加入购物车
                turnToSelectSpecs("detail_add2cart");
                break;
            case R.id.detail_buy:   // 立即购买
                turnToSelectSpecs("detail_buy");
                break;
            case R.id.detail_customrer_service:     // 客服
                Toast.makeText(this, "客服", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    /**
     *保存到数据库收藏夹
     */
    private void addToCollectionInServer() {
        MallCollection collection = new MallCollection();
        GoodsEntity goods = new GoodsEntity();
        goods.setGoods_id(goods_id);
        Customer customer = getCustomer();
        collection.setCustomer(customer);
        collection.setGoods(goods);

        final String json = new Gson().toJson(collection);

        new Thread(new Runnable() {
            @Override
            public void run() {
                String path = getResources().getString(R.string.server_projectpath) +
                        "addToGoodsCollection.action";
                //String path = "http://10.86.2.15:8080/ssm01/addToGoodsCollection.action";
                SaveDataToServer.sendJsonToServer(json, path, handler);
            }
        }).start();
    }

    /**
     * 获取用户信息
     * @return
     */
    private Customer getCustomer() {
        //创建一个customer.xml存储数据，并设置为私人模式
        SharedPreferences sharedPreferences = getSharedPreferences("customer", Context.MODE_PRIVATE);
        String customerJson = sharedPreferences.getString("customerJson", null);

        //Log.e("customerJson----", customerJson);

        if (customerJson != null) {
            Customer customer = new Gson().fromJson(customerJson, Customer.class);
            return customer;
        } else {
            Intent login = new Intent(this, LoginActivity.class);
            startActivity(login);
            return null;
        }
    }

    /**
     * 跳转至规格选择
     * @param buttonType
     */
    private void turnToSelectSpecs(String buttonType){
        Intent specifications = new Intent(MallGoodsDetailActivity.this,
                MallGoodsChooseSpecificationsActivity.class);
        Bundle sp = new Bundle();
        // GoodsEntity goods = (GoodsEntity) bundle.getSerializable("goods");
        sp.putSerializable("goods", goods);
        //sp.putString("goods_coverPic", (String) goods.getGoods_coverPic());
        sp.putString("buttonType", buttonType);
        specifications.putExtras(sp);
        startActivity(specifications);
    }

    /**
     * 动态添加ImageView视图
     * @param imageList
     * @param ll_goods_introduce_image
     */
    private void addImageView(List<Bitmap> imageList, LinearLayout ll_goods_introduce_image) {
        for(Bitmap bitmap : imageList) {
            ImageView imageView = new ImageView(this);
            imageView.setLayoutParams(new ActionBar.LayoutParams(ActionBar.LayoutParams.WRAP_CONTENT,
                    ActionBar.LayoutParams.WRAP_CONTENT));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            imageView.setImageBitmap(bitmap);
            ll_goods_introduce_image.addView(imageView);
        }
    }

    /**
     * 初始化视图
     */
    private void initView() {
        detail_customrer_service = findViewById(R.id.detail_customrer_service);
        detail_customrer_service.setOnClickListener(this);
        detail_add2collection = findViewById(R.id.detail_add2collection);
        detail_add2collection.setOnClickListener(this);
        detail_goods_comment = findViewById(R.id.detail_goods_comment);
        detail_goods_comment.setOnClickListener(this);
        detail_goods_specifications = findViewById(R.id.detail_goods_specifications);
        detail_goods_specifications.setOnClickListener(this);
        detail_add2cart = findViewById(R.id.detail_add2cart);
        detail_add2cart.setOnClickListener(this);
        detail_buy = findViewById(R.id.detail_buy);
        detail_buy.setOnClickListener(this);

        detail_goods_cover = findViewById(R.id.detail_goods_cover);
        detail_goods_price = findViewById(R.id.detail_goods_price);
        detail_goods_name = findViewById(R.id.detail_goods_name);
        tv_goods_describe = findViewById(R.id.tv_goods_describe);
        ll_goods_introduce_image = findViewById(R.id.ll_goods_introduce_image);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:   //返回键的id
                this.finish();
                return false;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
